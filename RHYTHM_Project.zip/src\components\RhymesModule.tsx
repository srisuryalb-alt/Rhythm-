import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { RhymeItem } from '../types';
import { audioEngine } from '../utils/audioEngine';
import { speechEngine } from '../utils/speechEngine';
import { 
  Music, 
  Sparkles, 
  Play, 
  Pause, 
  RotateCcw, 
  PlusCircle, 
  Gamepad2, 
  CheckCircle2, 
  Volume2, 
  Smile, 
  HelpCircle, 
  ArrowLeft, 
  Star,
  Award,
  Zap,
  Mic,
  Palette,
  VolumeX
} from 'lucide-react';

export const RhymesModule: React.FC = () => {
  const { rhymesList, addCustomRhyme, addCredits } = useApp();
  
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [activeRhyme, setActiveRhyme] = useState<RhymeItem | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [activeLineIndex, setActiveLineIndex] = useState<number>(-1);
  const [isSlowMode, setIsSlowMode] = useState(false);
  const [viewMode, setViewMode] = useState<'browse' | 'player' | 'creator' | 'game'>('browse');

  // Creator state
  const [creatorTopic, setCreatorTopic] = useState('');
  const [creatorAge, setCreatorAge] = useState('4 - 8 yrs');
  const [creatorMood, setCreatorMood] = useState('Playful');
  const [creatorStyle, setCreatorStyle] = useState<'Playful' | 'Calm' | 'Energetic' | 'Folk-inspired' | 'Classical-inspired'>('Playful');
  const [isCreating, setIsCreating] = useState(false);

  // Game state
  const [gameStep, setGameStep] = useState(0);
  const [selectedGameAnswer, setSelectedGameAnswer] = useState<number | null>(null);
  const [gameScore, setGameScore] = useState(0);

  const categories = [
    { name: 'All', icon: '✨' },
    { name: 'Alphabet', icon: '🌈' },
    { name: 'Numbers', icon: '🔢' },
    { name: 'Colors', icon: '🎨' },
    { name: 'Animals', icon: '🐶' },
    { name: 'Nature', icon: '🌱' },
    { name: 'Educational', icon: '📚' },
    { name: 'Memory', icon: '🧠' },
    { name: 'Original', icon: '✨' },
  ];

  const rhymeGameQuestions = [
    {
      prompt: "The sun is bright and high in sight,\nThe stars come out to shine at ___",
      options: ["Night", "Noon", "Water", "Tree"],
      correct: 0,
      rhymeExplanation: "Night rhymes with bright & sight!"
    },
    {
      prompt: "Two little birds upon a tree,\nSinging sweet songs for you and ___",
      options: ["Three", "Me", "Sea", "Free"],
      correct: 1,
      rhymeExplanation: "Me rhymes with tree!"
    },
    {
      prompt: "The little puppy likes to bark,\nAnd run and play inside the ___",
      options: ["Park", "Sky", "Lake", "Shoe"],
      correct: 0,
      rhymeExplanation: "Park rhymes with bark!"
    },
    {
      prompt: "Rainbow in the sky so high,\nColors dancing as clouds drift ___",
      options: ["Down", "By", "Far", "Slow"],
      correct: 1,
      rhymeExplanation: "By rhymes with high & sky!"
    }
  ];

  const filteredRhymes = selectedCategory === 'All' 
    ? rhymesList 
    : rhymesList.filter(r => r.category === selectedCategory || (selectedCategory === 'Original' && r.isOriginal));

  // Sing & Play Rhyme Line-by-line
  const handlePlayRhyme = async (rhyme: RhymeItem, slow = false) => {
    setIsPlaying(true);
    setIsSlowMode(slow);
    const speed = slow ? 0.75 : 0.95;

    for (let i = 0; i < rhyme.lyrics.length; i++) {
      setActiveLineIndex(i);
      // Play background bell chime
      audioEngine.playTone(rhyme.audioNotes ? rhyme.audioNotes[i % rhyme.audioNotes.length] : 329.63, 0.4, 'bell');
      
      // Speak line with melody cadence
      speechEngine.speak(rhyme.lyrics[i], {
        rate: speed,
        pitch: 1.15,
        onEnd: () => {}
      });

      await new Promise(res => setTimeout(res, slow ? 3400 : 2500));
    }

    setActiveLineIndex(-1);
    setIsPlaying(false);
    addCredits(10, `Completed singing "${rhyme.title}"!`);
  };

  const handleStopRhyme = () => {
    speechEngine.stop();
    setIsPlaying(false);
    setActiveLineIndex(-1);
  };

  // AI Rhyme Creator Submit
  const handleCreateRhyme = () => {
    if (!creatorTopic.trim()) return;
    setIsCreating(true);

    setTimeout(() => {
      const newRhyme: RhymeItem = {
        id: `custom-${Date.now()}`,
        title: `${creatorTopic} Adventure Rhyme`,
        category: 'Original',
        ageGroup: creatorAge,
        difficulty: 'Playful',
        duration: '1:15',
        lyrics: [
          `Look at the ${creatorTopic}, shining so bright!`,
          `Twirling and dancing with happy delight!`,
          `Colors and rhythm in harmony flow,`,
          `Learning together is how we all grow!`
        ],
        audioNotes: [261.63, 293.66, 349.23, 392.00, 523.25],
        bpm: 110,
        description: `Original AI rhyme generated for topic: ${creatorTopic} (${creatorStyle} style).`,
        icon: '✨',
        isOriginal: true
      };

      addCustomRhyme(newRhyme);
      setIsCreating(false);
      setActiveRhyme(newRhyme);
      setViewMode('player');
    }, 1200);
  };

  return (
    <div className="space-y-8 animate-fadeIn max-w-6xl mx-auto pb-12">
      
      {/* Top Banner */}
      <div className="glass-panel p-6 sm:p-7 rounded-3xl border border-pink-500/30 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-pink-900/50 border border-pink-500/40 text-pink-300 text-xs font-bold mb-2">
            <Music className="w-3.5 h-3.5" />
            <span>CHILD-FRIENDLY RHYMES STATION</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white">
            Which rhyme would you like to learn?
          </h1>
          <p className="text-xs sm:text-sm text-pink-200/80 mt-1 max-w-xl">
            Learn and remember educational & original rhymes through music, rhythm, repetition, and playful interaction.
          </p>
        </div>

        {/* Quick Mode Switches */}
        <div className="flex items-center gap-2.5">
          <button
            onClick={() => setViewMode('creator')}
            className="px-4 py-2.5 rounded-2xl text-xs font-bold bg-gradient-to-r from-pink-600 to-purple-600 text-white shadow-lg shadow-pink-900/40 hover:scale-105 active:scale-95 transition-all flex items-center gap-2"
          >
            <PlusCircle className="w-4 h-4" />
            <span>Create My Own Rhyme</span>
          </button>

          <button
            onClick={() => { setViewMode('game'); setGameStep(0); setSelectedGameAnswer(null); }}
            className="px-4 py-2.5 rounded-2xl text-xs font-bold bg-amber-500/20 text-amber-300 border border-amber-400/40 hover:bg-amber-500/30 transition-all flex items-center gap-2"
          >
            <Gamepad2 className="w-4 h-4" />
            <span>Rhyme Game</span>
          </button>
        </div>
      </div>

      {/* ================= VIEW: INTERACTIVE RHYME PLAYER ================= */}
      {viewMode === 'player' && activeRhyme && (
        <div className="glass-panel p-6 sm:p-8 rounded-3xl border border-pink-400/40 space-y-6 shadow-2xl relative overflow-hidden">
          
          <button
            onClick={() => { handleStopRhyme(); setViewMode('browse'); }}
            className="inline-flex items-center gap-2 text-xs font-bold text-pink-300 hover:text-white transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back to All Rhymes</span>
          </button>

          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-purple-900/40">
            <div className="flex items-center gap-3">
              <span className="text-4xl p-3 bg-pink-950/60 rounded-2xl border border-pink-700/40">
                {activeRhyme.icon}
              </span>
              <div>
                <h2 className="text-xl sm:text-2xl font-black text-white">{activeRhyme.title}</h2>
                <div className="flex items-center gap-2 mt-1 text-xs text-pink-300/80">
                  <span>{activeRhyme.category}</span> • <span>{activeRhyme.ageGroup}</span> • <span>{activeRhyme.difficulty}</span>
                </div>
              </div>
            </div>

            {/* Play/Stop Controls */}
            <div className="flex items-center gap-2">
              {isPlaying ? (
                <button
                  onClick={handleStopRhyme}
                  className="px-5 py-2.5 rounded-xl text-xs font-bold bg-red-600 text-white hover:bg-red-500 transition-all flex items-center gap-2"
                >
                  <Pause className="w-4 h-4" />
                  <span>Stop Singing</span>
                </button>
              ) : (
                <button
                  onClick={() => handlePlayRhyme(activeRhyme, false)}
                  className="px-6 py-2.5 rounded-xl text-xs font-bold bg-gradient-to-r from-pink-500 to-purple-600 text-white shadow-lg shadow-pink-900/50 hover:scale-105 transition-all flex items-center gap-2"
                >
                  <Play className="w-4 h-4 fill-white" />
                  <span>Play Rhyme</span>
                </button>
              )}
            </div>
          </div>

          {/* Line-by-Line Animated Karaoke Lyrics */}
          <div className="space-y-3 py-4">
            {activeRhyme.lyrics.map((line, idx) => {
              const isCurrent = activeLineIndex === idx;
              return (
                <div
                  key={idx}
                  onClick={() => {
                    speechEngine.speak(line, { pitch: 1.2 });
                    audioEngine.playTone(329.63 + idx * 30, 0.4, 'bell');
                  }}
                  className={`
                    p-4 rounded-2xl border text-sm sm:text-lg font-bold transition-all duration-300 cursor-pointer flex items-center justify-between
                    ${isCurrent 
                      ? 'bg-gradient-to-r from-pink-600/40 via-purple-600/40 to-amber-500/30 border-pink-400 text-white scale-[1.02] shadow-lg shadow-pink-950/80 ring-2 ring-pink-400/50' 
                      : 'bg-purple-950/30 border-purple-900/30 text-purple-200/80 hover:bg-purple-900/40'}
                  `}
                >
                  <div className="flex items-center gap-3">
                    <span className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-black ${
                      isCurrent ? 'bg-pink-400 text-slate-950' : 'bg-purple-900/60 text-purple-300'
                    }`}>
                      {idx + 1}
                    </span>
                    <span>{line}</span>
                  </div>

                  <Volume2 className={`w-4 h-4 ${isCurrent ? 'text-amber-300 animate-bounce' : 'text-purple-400/40'}`} />
                </div>
              );
            })}
          </div>

          {/* 6 Interactive Action Buttons */}
          <div className="pt-4 border-t border-purple-900/40 flex flex-wrap gap-2.5">
            <button
              onClick={() => handlePlayRhyme(activeRhyme, false)}
              className="px-4 py-2 rounded-xl text-xs font-bold bg-pink-900/40 border border-pink-600/40 text-pink-200 hover:bg-pink-800/40 flex items-center gap-1.5"
            >
              <Play className="w-3.5 h-3.5 fill-pink-200" />
              <span>Play Rhyme</span>
            </button>
            <button
              onClick={() => handlePlayRhyme(activeRhyme, false)}
              className="px-4 py-2 rounded-xl text-xs font-bold bg-purple-900/40 border border-purple-600/40 text-purple-200 hover:bg-purple-800/40 flex items-center gap-1.5"
            >
              <Mic className="w-3.5 h-3.5 text-amber-300" />
              <span>Sing With AI</span>
            </button>
            <button
              onClick={() => handlePlayRhyme(activeRhyme, false)}
              className="px-4 py-2 rounded-xl text-xs font-bold bg-purple-900/40 border border-purple-600/40 text-purple-200 hover:bg-purple-800/40 flex items-center gap-1.5"
            >
              <RotateCcw className="w-3.5 h-3.5 text-cyan-300" />
              <span>Repeat</span>
            </button>
            <button
              onClick={() => handlePlayRhyme(activeRhyme, true)}
              className="px-4 py-2 rounded-xl text-xs font-bold bg-teal-900/40 border border-teal-600/40 text-teal-200 hover:bg-teal-800/40 flex items-center gap-1.5"
            >
              <Smile className="w-3.5 h-3.5 text-teal-300" />
              <span>Slow Version</span>
            </button>
            <button
              onClick={() => speechEngine.speak("This rhyme uses simple words and repetitive patterns to build phonics and memory!", { rate: 0.9 })}
              className="px-4 py-2 rounded-xl text-xs font-bold bg-indigo-900/40 border border-indigo-600/40 text-indigo-200 hover:bg-indigo-800/40 flex items-center gap-1.5"
            >
              <Zap className="w-3.5 h-3.5 text-amber-300" />
              <span>Easy Version</span>
            </button>
            <button
              onClick={() => { setViewMode('game'); }}
              className="px-4 py-2 rounded-xl text-xs font-bold bg-amber-900/40 border border-amber-500/40 text-amber-200 hover:bg-amber-800/40 flex items-center gap-1.5"
            >
              <HelpCircle className="w-3.5 h-3.5 text-amber-300" />
              <span>Quiz Me</span>
            </button>
          </div>
        </div>
      )}

      {/* ================= VIEW: RHYME CREATOR ================= */}
      {viewMode === 'creator' && (
        <div className="glass-panel p-6 sm:p-8 rounded-3xl border border-pink-500/40 space-y-6 shadow-2xl">
          <button
            onClick={() => setViewMode('browse')}
            className="inline-flex items-center gap-2 text-xs font-bold text-pink-300 hover:text-white transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back to Browse</span>
          </button>

          <div className="text-center max-w-xl mx-auto space-y-2">
            <div className="inline-flex p-3 bg-pink-500/20 text-pink-400 rounded-2xl">
              <Sparkles className="w-6 h-6 animate-spin" style={{ animationDuration: '6s' }} />
            </div>
            <h2 className="text-2xl font-black text-white">Create My Own Rhyme</h2>
            <p className="text-xs text-purple-200/80">
              Type or speak a topic. RHYTHM AI will compose a brand new, original educational rhyme!
            </p>
          </div>

          <div className="max-w-xl mx-auto space-y-4">
            <div>
              <label className="block text-xs font-bold text-pink-200 mb-1">
                What topic should the rhyme be about?
              </label>
              <input
                type="text"
                value={creatorTopic}
                onChange={e => setCreatorTopic(e.target.value)}
                placeholder="e.g. Planets, Dinosaurs, Sharing Toys, Rainforest Animals..."
                className="w-full bg-[#120724] border border-purple-800/50 rounded-2xl px-4 py-3 text-sm text-white placeholder-purple-400/40 focus:outline-none focus:border-pink-400 transition-all"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-purple-200 mb-1">Age Group</label>
                <select
                  value={creatorAge}
                  onChange={e => setCreatorAge(e.target.value)}
                  className="w-full bg-[#120724] border border-purple-800/50 rounded-xl px-3 py-2.5 text-xs text-white focus:outline-none focus:border-pink-400"
                >
                  <option>3 - 5 yrs (Toddler)</option>
                  <option>5 - 8 yrs (Primary)</option>
                  <option>8 - 12 yrs (Elementary)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-purple-200 mb-1">Musical Style</label>
                <select
                  value={creatorStyle}
                  onChange={e => setCreatorStyle(e.target.value as any)}
                  className="w-full bg-[#120724] border border-purple-800/50 rounded-xl px-3 py-2.5 text-xs text-white focus:outline-none focus:border-pink-400"
                >
                  <option>Playful</option>
                  <option>Calm</option>
                  <option>Energetic</option>
                  <option>Folk-inspired</option>
                  <option>Classical-inspired</option>
                </select>
              </div>
            </div>

            <button
              onClick={handleCreateRhyme}
              disabled={!creatorTopic.trim() || isCreating}
              className="w-full py-3.5 rounded-2xl text-xs sm:text-sm font-bold bg-gradient-to-r from-pink-600 via-purple-600 to-amber-500 text-white shadow-xl shadow-pink-900/50 hover:opacity-95 disabled:opacity-40 transition-all flex items-center justify-center gap-2"
            >
              <Sparkles className="w-4 h-4" />
              <span>{isCreating ? 'Composing Original Rhyme with AI...' : 'Generate Original Rhyme (+25 Credits)'}</span>
            </button>
          </div>
        </div>
      )}

      {/* ================= VIEW: "COMPLETE THE RHYME" GAME ================= */}
      {viewMode === 'game' && (
        <div className="glass-panel p-6 sm:p-8 rounded-3xl border border-amber-400/40 space-y-6 shadow-2xl">
          <div className="flex items-center justify-between pb-4 border-b border-purple-900/40">
            <button
              onClick={() => setViewMode('browse')}
              className="inline-flex items-center gap-2 text-xs font-bold text-purple-300 hover:text-white transition-colors"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Back to Rhymes</span>
            </button>

            <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-amber-400/20 text-amber-300 border border-amber-400/30 text-xs font-bold">
              <Award className="w-4 h-4" />
              <span>Score: {gameScore} pts</span>
            </div>
          </div>

          <div className="max-w-xl mx-auto space-y-6 text-center">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-900/50 text-amber-300 text-xs font-bold">
              <Gamepad2 className="w-4 h-4" />
              <span>Question {gameStep + 1} of {rhymeGameQuestions.length}</span>
            </div>

            <h2 className="text-xl sm:text-2xl font-extrabold text-white leading-relaxed whitespace-pre-line">
              "{rhymeGameQuestions[gameStep].prompt}"
            </h2>

            {/* Options Grid */}
            <div className="grid grid-cols-2 gap-3 pt-2">
              {rhymeGameQuestions[gameStep].options.map((opt, oIdx) => {
                const isSelected = selectedGameAnswer === oIdx;
                const isCorrect = oIdx === rhymeGameQuestions[gameStep].correct;
                return (
                  <button
                    key={oIdx}
                    onClick={() => {
                      setSelectedGameAnswer(oIdx);
                      if (isCorrect) {
                        setGameScore(s => s + 10);
                        addCredits(10, 'Solved Rhyme Puzzle!');
                        audioEngine.playTone(523.25, 0.4, 'bell');
                      } else {
                        audioEngine.playTone(220, 0.4, 'carnatic');
                      }
                    }}
                    className={`py-4 px-3 rounded-2xl text-sm font-bold border transition-all ${
                      selectedGameAnswer !== null
                        ? isCorrect
                          ? 'bg-emerald-600/30 border-emerald-400 text-emerald-200 scale-105 shadow-lg shadow-emerald-950/60'
                          : isSelected
                            ? 'bg-red-600/30 border-red-400 text-red-200'
                            : 'bg-purple-950/40 border-purple-900/40 opacity-40'
                        : 'bg-[#140728] border-purple-800/40 text-white hover:border-amber-400 hover:scale-[1.02]'
                    }`}
                  >
                    {String.fromCharCode(65 + oIdx)}. {opt}
                  </button>
                );
              })}
            </div>

            {selectedGameAnswer !== null && (
              <div className="p-4 rounded-2xl bg-purple-900/40 border border-purple-700/40 space-y-3 animate-fadeIn">
                <div className="text-sm font-extrabold text-amber-300">
                  {selectedGameAnswer === rhymeGameQuestions[gameStep].correct 
                    ? 'Correct! 🎉 Excellent Rhyme Sense!' 
                    : 'Almost! Listen to the ending sound!'}
                </div>
                <p className="text-xs text-purple-200">
                  {rhymeGameQuestions[gameStep].rhymeExplanation}
                </p>

                <button
                  onClick={() => {
                    setSelectedGameAnswer(null);
                    if (gameStep < rhymeGameQuestions.length - 1) {
                      setGameStep(gameStep + 1);
                    } else {
                      setGameStep(0);
                    }
                  }}
                  className="px-6 py-2 rounded-xl text-xs font-bold bg-amber-400 text-slate-950 hover:bg-amber-300 transition-colors"
                >
                  {gameStep < rhymeGameQuestions.length - 1 ? 'Next Rhyme Question ➔' : 'Restart Game'}
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ================= VIEW: BROWSE RHYMES (MAIN) ================= */}
      {viewMode === 'browse' && (
        <>
          {/* Category Filter Pills */}
          <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
            {categories.map((cat) => (
              <button
                key={cat.name}
                onClick={() => setSelectedCategory(cat.name)}
                className={`px-4 py-2 rounded-2xl text-xs font-bold whitespace-nowrap transition-all border flex items-center gap-1.5 ${
                  selectedCategory === cat.name
                    ? 'bg-gradient-to-r from-pink-600 to-purple-600 text-white border-pink-400 shadow-md shadow-pink-900/40'
                    : 'bg-purple-950/40 border-purple-900/40 text-purple-200 hover:border-purple-600'
                }`}
              >
                <span>{cat.icon}</span>
                <span>{cat.name}</span>
              </button>
            ))}
          </div>

          {/* Rhymes Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {filteredRhymes.map((rhyme) => (
              <div
                key={rhyme.id}
                className="glass-panel p-5 sm:p-6 rounded-3xl border border-pink-900/30 hover:border-pink-400/60 transition-all flex flex-col justify-between group hover:shadow-xl hover:shadow-pink-950/50"
              >
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-3xl p-2 bg-pink-950/60 rounded-2xl border border-pink-800/40 group-hover:scale-110 transition-transform">
                      {rhyme.icon}
                    </span>
                    <div className="flex items-center gap-1.5">
                      {rhyme.isOriginal && (
                        <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-400/20 text-amber-300 font-bold border border-amber-400/30">
                          Original
                        </span>
                      )}
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-purple-900/60 text-purple-300 font-semibold border border-purple-700/40">
                        {rhyme.difficulty}
                      </span>
                    </div>
                  </div>

                  <h3 className="text-base font-bold text-white group-hover:text-pink-300 transition-colors">
                    {rhyme.title}
                  </h3>
                  <p className="text-xs text-purple-200/70 mt-1.5 leading-relaxed line-clamp-2">
                    {rhyme.description}
                  </p>

                  <div className="mt-4 flex items-center justify-between text-[11px] text-purple-300/60">
                    <span>Age: {rhyme.ageGroup}</span>
                    <span>Duration: {rhyme.duration}</span>
                  </div>
                </div>

                <div className="mt-5 pt-3 border-t border-purple-900/40 flex items-center gap-2">
                  <button
                    onClick={() => {
                      setActiveRhyme(rhyme);
                      setViewMode('player');
                    }}
                    className="flex-1 py-2.5 px-4 rounded-xl text-xs font-bold bg-gradient-to-r from-pink-600 to-purple-600 text-white hover:opacity-95 flex items-center justify-center gap-1.5 shadow-md shadow-pink-900/30 transition-all"
                  >
                    <Play className="w-3.5 h-3.5 fill-white" />
                    <span>Play & Learn</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </>
      )}

    </div>
  );
};
