import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { audioEngine } from '../utils/audioEngine';
import { 
  Sparkles, 
  Play, 
  BookOpen, 
  Music, 
  Trophy, 
  GraduationCap, 
  Headphones, 
  Wand2, 
  ArrowRight, 
  CheckCircle2, 
  Volume2, 
  Mic, 
  Zap, 
  Radio, 
  ShieldCheck, 
  Award,
  Users,
  Compass
} from 'lucide-react';

export const LandingPage: React.FC = () => {
  const { setIsAuthModalOpen, setAuthMode, setCurrentView, setActiveTab } = useApp();
  const [activeSwara, setActiveSwara] = useState<string | null>(null);
  const [isPlayingMelody, setIsPlayingMelody] = useState(false);

  const swaras = ['S', 'R2', 'G3', 'M1', 'P', 'D2', 'N3', 'S^'];
  const swaraLabels = ['Sa', 'Ri', 'Ga', 'Ma', 'Pa', 'Dha', 'Ni', 'Sȧ'];

  const playSwaraTone = (swara: string) => {
    setActiveSwara(swara);
    audioEngine.playTone(swara, 0.7, 'carnatic');
    setTimeout(() => setActiveSwara(null), 500);
  };

  const handlePlaySampleMelody = async () => {
    if (isPlayingMelody) return;
    setIsPlayingMelody(true);
    const demo = ['S', 'R2', 'G3', 'M1', 'P', 'D2', 'N3', 'S^', 'S^', 'N3', 'D2', 'P', 'M1', 'G3', 'R2', 'S'];
    for (const note of demo) {
      setActiveSwara(note);
      audioEngine.playTone(note, 0.35, 'carnatic');
      await new Promise(r => setTimeout(r, 360));
    }
    setActiveSwara(null);
    setIsPlayingMelody(false);
  };

  return (
    <div className="min-h-screen bg-[#0a0314] text-slate-100 overflow-x-hidden relative">
      
      {/* Background Animated Glows & Shapes */}
      <div className="absolute top-20 left-1/2 -translate-x-1/2 w-[600px] h-[350px] bg-gradient-to-tr from-purple-700/25 via-indigo-600/20 to-amber-400/15 rounded-full blur-[140px] pointer-events-none" />
      <div className="absolute top-[800px] -left-40 w-96 h-96 bg-purple-600/15 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute top-[1400px] -right-40 w-96 h-96 bg-amber-500/15 rounded-full blur-[120px] pointer-events-none" />

      {/* Hero Section */}
      <section className="relative pt-20 pb-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto flex flex-col items-center text-center">
        
        {/* Startup Pill */}
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full glass-panel border border-purple-500/40 text-amber-300 text-xs font-bold mb-8 shadow-lg shadow-purple-950/50 hover:scale-105 transition-transform cursor-default">
          <Sparkles className="w-4 h-4 text-amber-400 animate-spin" style={{ animationDuration: '4s' }} />
          <span>Next-Gen AI Music & Educational Ecosystem</span>
        </div>

        {/* Hero Heading */}
        <h1 className="text-4xl sm:text-6xl lg:text-7xl font-extrabold tracking-tight text-white max-w-5xl leading-[1.15]">
          Your Voice.{' '}
          <span className="bg-gradient-to-r from-purple-400 via-amber-300 to-amber-500 bg-clip-text text-transparent">
            Your Style.
          </span>{' '}
          Your Journey.
        </h1>

        {/* Subheading */}
        <p className="mt-6 text-base sm:text-xl text-purple-200/80 max-w-3xl leading-relaxed font-normal">
          Learn music, discover rhymes, prepare for competitions, attend AI-powered music classes, and explore your creativity with your personal AI music companion.
        </p>

        {/* Action Buttons */}
        <div className="mt-9 flex flex-col sm:flex-row items-center gap-4 w-full sm:w-auto">
          <button
            onClick={() => {
              setAuthMode('signup');
              setIsAuthModalOpen(true);
            }}
            className="w-full sm:w-auto px-8 py-4 rounded-2xl text-sm font-bold bg-gradient-to-r from-purple-600 via-indigo-600 to-amber-500 text-white shadow-xl shadow-purple-900/60 hover:opacity-95 hover:scale-105 active:scale-95 transition-all flex items-center justify-center gap-2.5 group"
          >
            <span>Get Started</span>
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </button>

          <button
            onClick={() => {
              setCurrentView('dashboard');
              setActiveTab('home');
            }}
            className="w-full sm:w-auto px-8 py-4 rounded-2xl text-sm font-semibold glass-panel border border-purple-500/40 text-purple-200 hover:text-white hover:bg-purple-900/40 hover:border-purple-400 transition-all flex items-center justify-center gap-2"
          >
            <Compass className="w-4 h-4 text-amber-400" />
            <span>Explore RHYTHM</span>
          </button>
        </div>

        {/* Visualizer & Interactive Swara Synthesizer preview */}
        <div className="mt-16 w-full max-w-4xl glass-panel rounded-3xl p-6 sm:p-8 border border-purple-500/30 shadow-2xl relative">
          
          {/* Top Bar with Live Audio Visualizer waves */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pb-6 border-b border-purple-900/40">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-purple-900/60 border border-purple-700/50 flex items-center justify-center text-amber-400">
                <Radio className="w-5 h-5 animate-pulse" />
              </div>
              <div className="text-left">
                <div className="text-xs font-bold text-slate-200 uppercase tracking-wider">
                  Interactive AI Sound Engine
                </div>
                <div className="text-xs text-purple-300/70">
                  Click any swara or play the Carnatic Mayamalavagowla scale
                </div>
              </div>
            </div>

            <button
              onClick={handlePlaySampleMelody}
              disabled={isPlayingMelody}
              className="px-4 py-2 rounded-xl text-xs font-bold bg-amber-500/20 text-amber-300 border border-amber-400/40 hover:bg-amber-500/30 flex items-center gap-2 transition-all disabled:opacity-50"
            >
              <Play className="w-3.5 h-3.5 fill-amber-300" />
              <span>{isPlayingMelody ? 'Playing Swara Arohana...' : 'Play Scale Demo'}</span>
            </button>
          </div>

          {/* Interactive Piano/Swara Keyboard */}
          <div className="mt-6">
            <div className="grid grid-cols-4 sm:grid-cols-8 gap-2.5">
              {swaras.map((sw, i) => {
                const isHit = activeSwara === sw;
                return (
                  <button
                    key={sw}
                    onClick={() => playSwaraTone(sw)}
                    className={`
                      relative group py-5 px-2 rounded-2xl border flex flex-col items-center justify-center gap-1 transition-all duration-200
                      ${isHit 
                        ? 'bg-gradient-to-b from-amber-400 to-amber-600 text-slate-950 font-black border-amber-300 scale-95 shadow-lg shadow-amber-500/50' 
                        : 'bg-[#140827] border-purple-800/40 text-white hover:border-purple-400 hover:bg-purple-900/30'}
                    `}
                  >
                    <span className="text-base sm:text-lg font-bold">
                      {swaraLabels[i]}
                    </span>
                    <span className="text-[10px] text-purple-300/70 group-hover:text-amber-200">
                      {sw}
                    </span>
                    <div className={`w-1.5 h-1.5 rounded-full ${isHit ? 'bg-slate-950' : 'bg-purple-500/40'}`} />
                  </button>
                );
              })}
            </div>
          </div>

          {/* Sound Wave Animation Visual */}
          <div className="mt-6 flex items-center justify-center gap-1.5 h-10 px-4 bg-purple-950/40 rounded-xl border border-purple-900/30 overflow-hidden">
            {[40, 75, 30, 90, 60, 100, 45, 80, 25, 95, 70, 50, 85, 35, 90, 65, 40, 80, 55, 95, 30, 70].map((h, i) => (
              <div
                key={i}
                className="w-1.5 bg-gradient-to-t from-purple-500 to-amber-400 rounded-full animate-wave"
                style={{
                  height: `${h}%`,
                  animationDelay: `${(i * 0.08) % 1.2}s`,
                  animationDuration: isPlayingMelody ? '0.6s' : '1.8s'
                }}
              />
            ))}
          </div>
        </div>
      </section>

      {/* 5 Core Pillars Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="text-center mb-12 space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-900/40 text-purple-300 text-xs font-bold border border-purple-700/40">
            <span>THE 5 SEPARATED EXPERIENCES</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white">
            Designed for Every Musical Need
          </h2>
          <p className="text-xs sm:text-sm text-purple-200/70 max-w-xl mx-auto">
            Each module is tailored to distinct pedagogical goals, from mnemonic memorization to competitive vocal grading.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          
          {/* 1. Learning */}
          <div 
            onClick={() => { setCurrentView('dashboard'); setActiveTab('learning'); }}
            className="glass-panel p-6 rounded-3xl border border-purple-800/40 hover:border-blue-400/60 transition-all cursor-pointer group hover:-translate-y-1"
          >
            <div className="w-12 h-12 rounded-2xl bg-blue-500/15 border border-blue-400/30 flex items-center justify-center text-blue-400 mb-4 group-hover:scale-110 transition-transform">
              <BookOpen className="w-6 h-6" />
            </div>
            <div className="flex items-center justify-between mb-1">
              <h3 className="text-lg font-bold text-white group-hover:text-blue-300 transition-colors">AI Learning</h3>
              <span className="text-[10px] px-2 py-0.5 rounded bg-blue-900/50 text-blue-300 font-semibold">Educational</span>
            </div>
            <p className="text-xs text-purple-200/80 leading-relaxed">
              Convert school poems, formulas, and history into original songs. Focuses purely on <strong>memorization + comprehension</strong> with zero pitch pressure.
            </p>
          </div>

          {/* 2. Rhymes */}
          <div 
            onClick={() => { setCurrentView('dashboard'); setActiveTab('rhymes'); }}
            className="glass-panel p-6 rounded-3xl border border-purple-800/40 hover:border-pink-400/60 transition-all cursor-pointer group hover:-translate-y-1"
          >
            <div className="w-12 h-12 rounded-2xl bg-pink-500/15 border border-pink-400/30 flex items-center justify-center text-pink-400 mb-4 group-hover:scale-110 transition-transform">
              <Music className="w-6 h-6" />
            </div>
            <div className="flex items-center justify-between mb-1">
              <h3 className="text-lg font-bold text-white group-hover:text-pink-300 transition-colors">Children's Rhymes</h3>
              <span className="text-[10px] px-2 py-0.5 rounded bg-pink-900/50 text-pink-300 font-semibold">Ages 3-12</span>
            </div>
            <p className="text-xs text-purple-200/80 leading-relaxed">
              Joyful rhymes across 8 categories, interactive rhyme creation engine, and "Complete the Rhyme" puzzle games.
            </p>
          </div>

          {/* 3. Competition */}
          <div 
            onClick={() => { setCurrentView('dashboard'); setActiveTab('competition'); }}
            className="glass-panel p-6 rounded-3xl border border-purple-800/40 hover:border-amber-400/60 transition-all cursor-pointer group hover:-translate-y-1"
          >
            <div className="w-12 h-12 rounded-2xl bg-amber-500/15 border border-amber-400/30 flex items-center justify-center text-amber-400 mb-4 group-hover:scale-110 transition-transform">
              <Trophy className="w-6 h-6" />
            </div>
            <div className="flex items-center justify-between mb-1">
              <h3 className="text-lg font-bold text-white group-hover:text-amber-300 transition-colors">Music Competition</h3>
              <span className="text-[10px] px-2 py-0.5 rounded bg-amber-900/50 text-amber-300 font-semibold">Pitch AI</span>
            </div>
            <p className="text-xs text-purple-200/80 leading-relaxed">
              Target date countdown roadmap, real-time vocal pitch graph, Shruti accuracy, and stability evaluation.
            </p>
          </div>

          {/* 4. Music Class */}
          <div 
            onClick={() => { setCurrentView('dashboard'); setActiveTab('class'); }}
            className="glass-panel p-6 rounded-3xl border border-purple-800/40 hover:border-emerald-400/60 transition-all cursor-pointer group hover:-translate-y-1"
          >
            <div className="w-12 h-12 rounded-2xl bg-emerald-500/15 border border-emerald-400/30 flex items-center justify-center text-emerald-400 mb-4 group-hover:scale-110 transition-transform">
              <GraduationCap className="w-6 h-6" />
            </div>
            <div className="flex items-center justify-between mb-1">
              <h3 className="text-lg font-bold text-white group-hover:text-emerald-300 transition-colors">AI Music Class</h3>
              <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-900/50 text-emerald-300 font-semibold">Live Guided</span>
            </div>
            <p className="text-xs text-purple-200/80 leading-relaxed">
              Personalized weekly class calendar (1-7 days) in Carnatic & Folk styles with 4-panel live singing feedback.
            </p>
          </div>

          {/* 5. Entertainment */}
          <div 
            onClick={() => { setCurrentView('dashboard'); setActiveTab('entertainment'); }}
            className="glass-panel p-6 rounded-3xl border border-purple-800/40 hover:border-cyan-400/60 transition-all cursor-pointer group hover:-translate-y-1"
          >
            <div className="w-12 h-12 rounded-2xl bg-cyan-500/15 border border-cyan-400/30 flex items-center justify-center text-cyan-400 mb-4 group-hover:scale-110 transition-transform">
              <Headphones className="w-6 h-6" />
            </div>
            <div className="flex items-center justify-between mb-1">
              <h3 className="text-lg font-bold text-white group-hover:text-cyan-300 transition-colors">Entertainment</h3>
              <span className="text-[10px] px-2 py-0.5 rounded bg-cyan-900/50 text-cyan-300 font-semibold">Music Chat</span>
            </div>
            <p className="text-xs text-purple-200/80 leading-relaxed">
              Talk music with AI, explore songs conceptually, play Rhythm Tapper games, and test knowledge with music trivia.
            </p>
          </div>

          {/* 6. Innovation Studio */}
          <div 
            onClick={() => { setCurrentView('dashboard'); setActiveTab('innovation'); }}
            className="glass-panel p-6 rounded-3xl border border-purple-800/40 hover:border-purple-400/60 transition-all cursor-pointer group hover:-translate-y-1"
          >
            <div className="w-12 h-12 rounded-2xl bg-purple-500/15 border border-purple-400/30 flex items-center justify-center text-purple-300 mb-4 group-hover:scale-110 transition-transform">
              <Wand2 className="w-6 h-6" />
            </div>
            <div className="flex items-center justify-between mb-1">
              <h3 className="text-lg font-bold text-white group-hover:text-purple-200 transition-colors">Innovation Studio</h3>
              <span className="text-[10px] px-2 py-0.5 rounded bg-purple-900/50 text-amber-300 font-semibold">Cross-Genre</span>
            </div>
            <p className="text-xs text-purple-200/80 leading-relaxed">
              Transform original exercises across Carnatic, Folk, and Contemporary styles with live AI singing feedback.
            </p>
          </div>
        </div>
      </section>

      {/* Startup Mission & Vision Callout */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 max-w-5xl mx-auto">
        <div className="relative rounded-3xl p-8 sm:p-12 glass-panel border border-amber-400/30 overflow-hidden shadow-2xl">
          <div className="absolute -right-20 -top-20 w-64 h-64 bg-amber-500/15 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute -left-20 -bottom-20 w-64 h-64 bg-purple-600/20 rounded-full blur-3xl pointer-events-none" />

          <div className="relative z-10 text-center space-y-6">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-400/20 text-amber-300 border border-amber-400/30 text-xs font-bold">
              <Award className="w-4 h-4" />
              <span>COLLEGE INNOVATION & STARTUP VISION</span>
            </div>

            <h3 className="text-2xl sm:text-3xl font-extrabold text-white leading-relaxed">
              "RHYTHM is more than a music-learning app.
              <br />
              <span className="text-transparent bg-gradient-to-r from-amber-200 via-purple-300 to-white bg-clip-text">
                It is an AI-powered music companion that adapts to why you came to music — whether you want to learn, memorize through rhymes, prepare for a competition, attend a music class, explore new musical styles, or simply enjoy music."
              </span>
            </h3>

            <div className="pt-4 flex flex-col sm:flex-row items-center justify-center gap-4">
              <button
                onClick={() => {
                  setAuthMode('signup');
                  setIsAuthModalOpen(true);
                }}
                className="px-8 py-4 rounded-2xl text-sm font-extrabold bg-gradient-to-r from-purple-600 via-indigo-600 to-amber-500 text-white shadow-xl shadow-purple-900/60 hover:scale-105 transition-transform"
              >
                Start Your Musical Journey
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-purple-950/60 py-8 px-4 text-center text-xs text-purple-300/60">
        <p>© 2026 RHYTHM — AI-Powered Music and Learning Prototype. Built for Innovation & Startup Showcase.</p>
      </footer>
    </div>
  );
};
