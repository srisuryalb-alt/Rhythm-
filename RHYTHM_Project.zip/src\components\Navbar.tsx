import React from 'react';
import { useApp } from '../context/AppContext';
import { audioEngine } from '../utils/audioEngine';
import { 
  Sparkles, 
  Flame, 
  Coins, 
  Volume2, 
  VolumeX, 
  User as UserIcon, 
  Menu, 
  Compass, 
  Music2,
  Mic2
} from 'lucide-react';

interface NavbarProps {
  onToggleMobileMenu?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onToggleMobileMenu }) => {
  const { 
    currentView, 
    setCurrentView, 
    setIsAuthModalOpen, 
    setAuthMode, 
    user, 
    isTanpuraActive, 
    setIsTanpuraActive,
    activeTab,
    setActiveTab,
    creditNotification
  } = useApp();

  const handleTanpuraToggle = () => {
    const active = audioEngine.toggleTanpura(261.63, (playing) => {
      setIsTanpuraActive(playing);
    });
    setIsTanpuraActive(active);
  };

  return (
    <header className="sticky top-0 z-40 w-full glass-panel border-b border-purple-900/40 px-4 lg:px-8 py-3.5 transition-all">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        
        {/* Brand Logo */}
        <div className="flex items-center gap-3">
          {currentView === 'dashboard' && (
            <button 
              onClick={onToggleMobileMenu}
              className="lg:hidden p-2 text-slate-300 hover:text-white rounded-lg hover:bg-purple-950/50"
              aria-label="Toggle Navigation"
            >
              <Menu className="w-5 h-5" />
            </button>
          )}

          <div 
            onClick={() => setCurrentView(currentView === 'landing' ? 'landing' : 'dashboard')}
            className="flex items-center gap-2.5 cursor-pointer group"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-purple-700 via-indigo-600 to-amber-400 p-[2px] shadow-lg shadow-purple-900/30 group-hover:scale-105 transition-transform">
              <div className="w-full h-full bg-[#0e061a] rounded-[10px] flex items-center justify-center">
                <Music2 className="w-5 h-5 text-amber-400 animate-pulse-slow" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-extrabold text-xl tracking-wider bg-gradient-to-r from-purple-300 via-amber-200 to-white bg-clip-text text-transparent">
                  RHYTHM
                </span>
                <span className="text-[10px] uppercase font-bold tracking-widest px-1.5 py-0.5 rounded bg-purple-900/60 text-amber-300 border border-purple-500/30">
                  AI MVP
                </span>
              </div>
              <p className="text-[10.5px] text-purple-300/70 hidden sm:block font-medium">
                Your Voice. Your Style. Your Journey.
              </p>
            </div>
          </div>
        </div>

        {/* Global Controls & Gamification */}
        <div className="flex items-center gap-2.5 sm:gap-4">
          {/* Tanpura Drone Studio Button */}
          <button
            onClick={handleTanpuraToggle}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold transition-all border ${
              isTanpuraActive 
                ? 'bg-amber-500/20 text-amber-300 border-amber-400/50 shadow-lg shadow-amber-500/20 animate-pulse' 
                : 'bg-purple-950/40 text-purple-300 border-purple-800/40 hover:bg-purple-900/40'
            }`}
            title={isTanpuraActive ? "Tanpura Drone Active (C4 Sa/Pa)" : "Start Tanpura Drone"}
          >
            {isTanpuraActive ? <Volume2 className="w-3.5 h-3.5 text-amber-400" /> : <VolumeX className="w-3.5 h-3.5 text-purple-400" />}
            <span className="hidden md:inline">Tanpura Drone</span>
            <span className="text-[10px] px-1 bg-purple-900/60 rounded text-amber-300">C4</span>
          </button>

          {currentView === 'dashboard' ? (
            <>
              {/* Streak Badge */}
              <div 
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-gradient-to-r from-orange-500/20 to-amber-500/20 border border-orange-500/30 text-orange-300 text-xs font-bold"
                title={`${user.streak} Day Learning Streak!`}
              >
                <Flame className="w-4 h-4 text-orange-400 fill-orange-400" />
                <span>{user.streak}d</span>
              </div>

              {/* Credits Counter */}
              <div 
                onClick={() => setActiveTab('credits')}
                className="cursor-pointer flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-gradient-to-r from-purple-600/20 to-indigo-600/20 border border-purple-500/40 text-purple-200 text-xs font-bold hover:border-amber-400/50 transition-colors"
                title="RHYTHM Credits - Click to view rewards"
              >
                <Coins className="w-4 h-4 text-amber-400" />
                <span>{user.credits}</span>
                <span className="hidden sm:inline text-purple-400 text-[10px]">pts</span>
              </div>

              {/* Profile Avatar Button */}
              <button
                onClick={() => setActiveTab('profile')}
                className="flex items-center gap-2 p-1 pl-2 pr-3 rounded-full bg-purple-950/60 border border-purple-700/40 hover:border-purple-400 transition-colors"
              >
                <div className="w-7 h-7 rounded-full bg-gradient-to-tr from-purple-500 to-amber-400 flex items-center justify-center font-bold text-xs text-slate-900">
                  {user.name.charAt(0)}
                </div>
                <span className="text-xs font-medium text-slate-200 hidden md:inline max-w-[90px] truncate">
                  {user.name.split(' ')[0]}
                </span>
              </button>
            </>
          ) : (
            <div className="flex items-center gap-2 sm:gap-3">
              <button
                onClick={() => {
                  setAuthMode('login');
                  setIsAuthModalOpen(true);
                }}
                className="px-3.5 py-1.5 text-xs font-semibold text-purple-200 hover:text-white transition-colors"
              >
                Login
              </button>
              <button
                onClick={() => {
                  setAuthMode('signup');
                  setIsAuthModalOpen(true);
                }}
                className="px-4 py-1.5 rounded-full text-xs font-bold bg-gradient-to-r from-purple-600 via-indigo-600 to-amber-500 text-white shadow-lg shadow-purple-900/40 hover:opacity-95 transition-opacity"
              >
                Get Started
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Credit Notification Toast */}
      {creditNotification && (
        <div className="fixed bottom-6 right-6 z-50 flex items-center gap-3 p-4 rounded-2xl bg-gradient-to-r from-purple-900 via-indigo-900 to-purple-950 border border-amber-400/50 shadow-2xl shadow-purple-950/80 animate-bounce">
          <div className="w-10 h-10 rounded-xl bg-amber-400/20 flex items-center justify-center text-amber-400">
            <Coins className="w-6 h-6" />
          </div>
          <div>
            <div className="text-sm font-bold text-amber-300">
              +{creditNotification.amount} RHYTHM Credits! 🎉
            </div>
            <div className="text-xs text-slate-300">
              {creditNotification.reason}
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
