import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { audioEngine } from '../utils/audioEngine';
import { speechEngine } from '../utils/speechEngine';
import { 
  Wand2, 
  Sparkles, 
  ArrowDown, 
  Play, 
  RotateCcw, 
  Mic, 
  MicOff, 
  Award, 
  CheckCircle2, 
  Zap, 
  Layers, 
  Radio,
  Sliders,
  Volume2
} from 'lucide-react';

export const InnovationStudio: React.FC = () => {
  const { user, addCredits } = useApp();

  const [transformationType, setTransformationType] = useState<
    'Carnatic → Folk' | 'Folk → Carnatic' | 'Classical-inspired → Contemporary' | 'Slow → Fast' | 'Melodic → Rhythmic'
  >('Carnatic → Folk');

  const [isTransforming, setIsTransforming] = useState(false);
  const [isPlayingNewVersion, setIsPlayingNewVersion] = useState(false);
  const [isSingingTransformed, setIsSingingTransformed] = useState(false);
  const [singScores, setSingScores] = useState<{
    pitch: number;
    shruti: number;
    rhythm: number;
    timing: number;
    feedback: string;
  } | null>(null);

  const transformationPresets: Record<string, {
    originalTitle: string;
    originalStyle: string;
    originalNotation: string;
    originalNotes: number[];
    transformedTitle: string;
    transformedStyle: string;
    transformedNotation: string;
    transformedNotes: number[];
    synthType: 'carnatic' | 'folk' | 'western';
    bpm: number;
    aiExplanation: string;
  }> = {
    'Carnatic → Folk': {
      originalTitle: "Original: Mayamalavagowla Classical Varisai",
      originalStyle: "Carnatic Vocal (Adi Talam, 75 BPM)",
      originalNotation: "S - R1 - G3 - M1 | P - D1 - N3 - S^",
      originalNotes: [261.63, 277.18, 329.63, 349.23, 392.00, 415.30, 493.88, 523.25],
      transformedTitle: "AI Transformed: Tamil Themmangu Village Folk Groove",
      transformedStyle: "Folk Percussive Cadence (110 BPM)",
      transformedNotation: "Tha-Dhi-Na S R G | Thom-Tha P D S^",
      transformedNotes: [261.63, 293.66, 329.63, 392.00, 440.00, 523.25],
      synthType: 'folk',
      bpm: 110,
      aiExplanation: "Converted straight classical microtonal swaras into an energetic pentatonic folk syncopation with upbeat rhythm."
    },
    'Folk → Carnatic': {
      originalTitle: "Original: Village Harvesting Rhythm Chant",
      originalStyle: "Raw Folk Cadence (115 BPM)",
      originalNotation: "Hey-Le-Lo S P S | Ta-Ka-Ta-Ki-Ta",
      originalNotes: [261.63, 392.00, 261.63, 329.63, 392.00],
      transformedTitle: "AI Transformed: Kalyani Raga Gamaka Sancharam",
      transformedStyle: "Carnatic Classical Gamaka (70 BPM)",
      transformedNotation: "S ~~~ R2 ~~~ G3 ~~~ M2 | P ~~~ D2 ~~~ N3 ~~~ S^",
      transformedNotes: [261.63, 293.66, 329.63, 369.99, 392.00, 440.00, 493.88, 523.25],
      synthType: 'carnatic',
      bpm: 70,
      aiExplanation: "Infused deep continuous vocal oscillations (Nokku, Odukkal Gamakas) into the raw folk melody."
    },
    'Classical-inspired → Contemporary': {
      originalTitle: "Original: Traditional Mandra Sthayi Exercise",
      originalStyle: "Acoustic Classical Drone",
      originalNotation: "S . . . P . . . S^ . . .",
      originalNotes: [130.81, 196.00, 261.63, 392.00, 523.25],
      transformedTitle: "AI Transformed: Ambient Neo-Soul Cinematic Harmony",
      transformedStyle: "Contemporary Synth Pad (90 BPM)",
      transformedNotation: "Cmaj7 (Sa - Ga3 - Pa - Ni3) Modern Arpeggio",
      transformedNotes: [261.63, 329.63, 392.00, 493.88, 523.25],
      synthType: 'western',
      bpm: 90,
      aiExplanation: "Re-harmonized classical root intervals with rich major 7th and 9th ambient chord voicings."
    },
    'Slow → Fast': {
      originalTitle: "Original: Vilamba Kaalam (Slow 1st Speed)",
      originalStyle: "Meditation Pace (60 BPM)",
      originalNotation: "S . R . G . M . P . D . N . S^",
      originalNotes: [261.63, 277.18, 329.63, 349.23, 392.00, 415.30, 493.88, 523.25],
      transformedTitle: "AI Transformed: Dhurita Kaalam (Fast 3rd Speed)",
      transformedStyle: "Virtuoso Speed (130 BPM)",
      transformedNotation: "SRGM PDNS^ S^NDP MGRS",
      transformedNotes: [261.63, 277.18, 329.63, 349.23, 392.00, 415.30, 493.88, 523.25, 523.25, 493.88, 415.30, 392.00, 349.23, 329.63, 277.18, 261.63],
      synthType: 'carnatic',
      bpm: 130,
      aiExplanation: "Quadrupled note density per beat to cultivate tongue dexterity and agile breath stamina."
    },
    'Melodic → Rhythmic': {
      originalTitle: "Original: Sustained Sustained Alapana",
      originalStyle: "Free-form Melody (Unmetered)",
      originalNotation: "Saaaaa . . . Riiiiii . . . Gaaaaa",
      originalNotes: [261.63, 277.18, 329.63],
      transformedTitle: "AI Transformed: Konnakol Vocal Percussion",
      transformedStyle: "Rhythmic Solkattu (112 BPM)",
      transformedNotation: "Tha - Ka - Dhi - Mi | Tha - Ka - Jon - U",
      transformedNotes: [261.63, 293.66, 261.63, 392.00, 261.63],
      synthType: 'folk',
      bpm: 112,
      aiExplanation: "Converted pitch glides into staccato Konnakol rhythmic syllables used by mridangam masters."
    }
  };

  const currentPreset = transformationPresets[transformationType];

  const handlePlayOriginal = async () => {
    speechEngine.speak("Listening to Original Phrase", { rate: 1.0 });
    await new Promise(r => setTimeout(r, 1400));
    await audioEngine.playSequence(currentPreset.originalNotes, 500, 'carnatic');
  };

  const handlePlayTransformed = async () => {
    setIsPlayingNewVersion(true);
    speechEngine.speak(`Playing Transformed Version in ${currentPreset.transformedStyle}`, { rate: 1.0 });
    await new Promise(r => setTimeout(r, 2200));
    await audioEngine.playSequence(currentPreset.transformedNotes, (60 / currentPreset.bpm) * 1000 * 0.9, currentPreset.synthType);
    setIsPlayingNewVersion(false);
  };

  const handleStartSingBack = async () => {
    setIsSingingTransformed(true);
    setSingScores(null);
    await audioEngine.startMic();

    setTimeout(() => {
      setIsSingingTransformed(false);
      audioEngine.stopMic();
      const score = {
        pitch: 88,
        shruti: 92,
        rhythm: 95,
        timing: 90,
        feedback: `Brilliant adaptation! You caught the ${currentPreset.transformedStyle} groove effortlessly. Your rhythmic snap on the transformed accents was outstanding.`
      };
      setSingScores(score);
      addCredits(25, `Completed ${transformationType} Innovation Experiment!`);
    }, 4500);
  };

  return (
    <div className="space-y-8 animate-fadeIn max-w-6xl mx-auto pb-12">
      
      {/* Top Banner */}
      <div className="glass-panel p-6 sm:p-7 rounded-3xl border border-purple-500/30 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-900/50 border border-purple-500/40 text-amber-300 text-xs font-bold mb-2">
            <Wand2 className="w-3.5 h-3.5" />
            <span>AI CROSS-GENRE INNOVATION LAB</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white">
            INNOVATION STUDIO
          </h1>
          <p className="text-xs sm:text-sm text-purple-200/80 mt-1 max-w-xl">
            Transform the way you experience music. Transmute classical exercises into folk grooves, fast tempos, or cinematic styles.
          </p>
        </div>

        <div className="px-4 py-2.5 rounded-2xl bg-purple-950/70 border border-purple-700/40 text-xs font-bold text-amber-300 flex items-center gap-2 shrink-0">
          <Sparkles className="w-4 h-4 text-amber-400" />
          <span>Original Non-Copyrighted Exercises Only</span>
        </div>
      </div>

      {/* Style Transformation Selector Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
        {(Object.keys(transformationPresets) as Array<keyof typeof transformationPresets>).map((type) => (
          <button
            key={type}
            onClick={() => {
              setTransformationType(type as any);
              setSingScores(null);
            }}
            className={`px-4 py-2.5 rounded-2xl text-xs font-bold whitespace-nowrap transition-all border flex items-center gap-2 ${
              transformationType === type
                ? 'bg-gradient-to-r from-purple-600 via-indigo-600 to-amber-500 text-white border-amber-400 shadow-lg shadow-purple-950/80 scale-105'
                : 'bg-purple-950/40 border-purple-900/40 text-purple-200 hover:border-purple-600'
            }`}
          >
            <Sliders className="w-3.5 h-3.5 text-amber-300" />
            <span>{type}</span>
          </button>
        ))}
      </div>

      {/* ================= VISUAL FLOW: ORIGINAL → AI TRANSFORMATION → NEW VERSION ================= */}
      <div className="glass-panel p-6 sm:p-8 rounded-3xl border border-purple-500/40 space-y-6 shadow-2xl relative">
        
        {/* STEP 1: ORIGINAL */}
        <div className="p-5 rounded-2xl bg-[#0e051a] border border-purple-800/50 space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div>
              <span className="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded bg-purple-900/60 text-purple-300 border border-purple-700/40">
                1. ORIGINAL SOURCE PHRASE
              </span>
              <h3 className="text-base font-bold text-white mt-1">
                {currentPreset.originalTitle}
              </h3>
              <p className="text-xs text-purple-300/70">{currentPreset.originalStyle}</p>
            </div>

            <button
              onClick={handlePlayOriginal}
              className="px-4 py-2 rounded-xl text-xs font-bold bg-purple-900/40 text-purple-200 border border-purple-700/40 hover:bg-purple-800/40 flex items-center gap-1.5 self-start sm:self-auto"
            >
              <Play className="w-3.5 h-3.5 fill-purple-300" />
              <span>Hear Original</span>
            </button>
          </div>

          <div className="p-3 rounded-xl bg-purple-950/60 font-mono text-xs sm:text-sm font-bold text-purple-200 border border-purple-800/40">
            {currentPreset.originalNotation}
          </div>
        </div>

        {/* STEP 2: AI TRANSFORMATION FLOW ARROW */}
        <div className="flex flex-col items-center justify-center gap-2 py-1">
          <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-purple-600 to-amber-500 flex items-center justify-center text-white shadow-lg shadow-purple-900/60 animate-bounce">
            <ArrowDown className="w-5 h-5 stroke-[3]" />
          </div>
          <div className="text-center">
            <span className="text-xs font-black text-amber-300 uppercase tracking-widest">
              AI REAL-TIME TRANSFORMATION
            </span>
            <p className="text-[11px] text-purple-200/80 mt-0.5 max-w-md mx-auto">
              {currentPreset.aiExplanation}
            </p>
          </div>
        </div>

        {/* STEP 3: NEW VERSION */}
        <div className="p-5 rounded-2xl bg-gradient-to-br from-amber-950/30 via-[#120625] to-purple-950/40 border border-amber-400/50 space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div>
              <span className="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded bg-amber-400/20 text-amber-300 border border-amber-400/40">
                2. AI TRANSFORMED VERSION
              </span>
              <h3 className="text-base font-bold text-white mt-1">
                {currentPreset.transformedTitle}
              </h3>
              <p className="text-xs text-amber-200/80">{currentPreset.transformedStyle}</p>
            </div>

            <button
              onClick={handlePlayTransformed}
              disabled={isPlayingNewVersion}
              className="px-5 py-2.5 rounded-xl text-xs font-bold bg-gradient-to-r from-amber-500 to-orange-500 text-slate-950 font-black shadow-lg shadow-amber-900/40 hover:scale-105 active:scale-95 transition-all flex items-center gap-2 self-start sm:self-auto disabled:opacity-40"
            >
              <Play className="w-4 h-4 fill-slate-950" />
              <span>{isPlayingNewVersion ? 'Playing Transformed...' : 'Perform New Version'}</span>
            </button>
          </div>

          <div className="p-3.5 rounded-xl bg-amber-950/40 font-mono text-xs sm:text-sm font-bold text-amber-200 border border-amber-500/30">
            {currentPreset.transformedNotation}
          </div>
        </div>

        {/* Sing Back Transformed Phrase */}
        <div className="pt-2 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="text-left">
            <h4 className="text-sm font-bold text-white">Sing Back Transformed Phrase</h4>
            <p className="text-xs text-purple-300/70">
              Listen to the AI transformation, then sing it back to receive live cross-genre accuracy feedback.
            </p>
          </div>

          {isSingingTransformed ? (
            <button
              onClick={() => setIsSingingTransformed(false)}
              className="w-full sm:w-auto px-6 py-3 rounded-2xl text-xs font-bold bg-red-600 text-white animate-pulse flex items-center justify-center gap-2"
            >
              <MicOff className="w-4 h-4" />
              <span>Analyzing Transformed Voice...</span>
            </button>
          ) : (
            <button
              onClick={handleStartSingBack}
              className="w-full sm:w-auto px-6 py-3 rounded-2xl text-xs font-bold bg-purple-700 hover:bg-purple-600 text-white font-bold transition-all flex items-center justify-center gap-2 shadow-lg shadow-purple-950/80"
            >
              <Mic className="w-4 h-4 text-amber-300" />
              <span>Sing Back Transformed Phrase</span>
            </button>
          )}
        </div>

        {/* Sing Back Evaluation Score */}
        {singScores && (
          <div className="p-5 rounded-2xl bg-[#0d051a] border border-amber-400/40 space-y-3 animate-fadeIn">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-white flex items-center gap-2">
                <Award className="w-4 h-4 text-amber-400" />
                <span>Cross-Genre Vocal Evaluation</span>
              </span>
              <span className="text-xs font-bold text-amber-300">+25 Credits Earned! 🎉</span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
              <div className="p-2.5 rounded-xl bg-purple-950/60 border border-purple-800/40 text-center">
                <div className="text-[10px] text-purple-300 font-bold uppercase">Pitch Accuracy</div>
                <div className="text-base font-black text-amber-300">{singScores.pitch}%</div>
              </div>
              <div className="p-2.5 rounded-xl bg-purple-950/60 border border-purple-800/40 text-center">
                <div className="text-[10px] text-purple-300 font-bold uppercase">Shruti Alignment</div>
                <div className="text-base font-black text-emerald-400">{singScores.shruti}%</div>
              </div>
              <div className="p-2.5 rounded-xl bg-purple-950/60 border border-purple-800/40 text-center">
                <div className="text-[10px] text-purple-300 font-bold uppercase">Rhythm Feel</div>
                <div className="text-base font-black text-blue-400">{singScores.rhythm}%</div>
              </div>
              <div className="p-2.5 rounded-xl bg-purple-950/60 border border-purple-800/40 text-center">
                <div className="text-[10px] text-purple-300 font-bold uppercase">Timing Accuracy</div>
                <div className="text-base font-black text-teal-400">{singScores.timing}%</div>
              </div>
            </div>

            <div className="p-3 rounded-xl bg-purple-950/40 border border-purple-700/40 text-xs text-purple-200">
              {singScores.feedback}
            </div>
          </div>
        )}

        {/* 4 Required Action Buttons */}
        <div className="pt-4 border-t border-purple-900/40 flex flex-wrap gap-2.5">
          <button
            onClick={() => handlePlayTransformed()}
            className="px-4 py-2 rounded-xl text-xs font-bold bg-purple-900/40 border border-purple-600/40 text-purple-200 hover:bg-purple-800/40 flex items-center gap-1.5"
          >
            <RotateCcw className="w-3.5 h-3.5 text-amber-300" />
            <span>Create Another Version</span>
          </button>
          <button
            onClick={() => setTransformationType('Folk → Carnatic')}
            className="px-4 py-2 rounded-xl text-xs font-bold bg-purple-900/40 border border-purple-600/40 text-purple-200 hover:bg-purple-800/40 flex items-center gap-1.5"
          >
            <Sliders className="w-3.5 h-3.5 text-pink-300" />
            <span>Try Another Style</span>
          </button>
          <button
            onClick={() => speechEngine.speak("Slowing tempo by 20% to practice relaxed articulation.")}
            className="px-4 py-2 rounded-xl text-xs font-bold bg-teal-900/40 border border-teal-600/40 text-teal-200 hover:bg-teal-800/40 flex items-center gap-1.5"
          >
            <Zap className="w-3.5 h-3.5 text-teal-300" />
            <span>Make It Easier</span>
          </button>
          <button
            onClick={() => speechEngine.speak("Adding syncopated percussion pulses to enhance the groove.")}
            className="px-4 py-2 rounded-xl text-xs font-bold bg-amber-900/40 border border-amber-600/40 text-amber-200 hover:bg-amber-800/40 flex items-center gap-1.5"
          >
            <Radio className="w-3.5 h-3.5 text-amber-300" />
            <span>Make It More Rhythmic</span>
          </button>
        </div>

      </div>

    </div>
  );
};
