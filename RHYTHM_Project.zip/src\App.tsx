import React, { useState } from 'react';
import { useApp } from './context/AppContext';
import { Navbar } from './components/Navbar';
import { Sidebar } from './components/Sidebar';
import { LandingPage } from './components/LandingPage';
import { PurposeSelection } from './components/PurposeSelection';
import { Dashboard } from './components/Dashboard';
import { LearningModule } from './components/LearningModule';
import { RhymesModule } from './components/RhymesModule';
import { CompetitionModule } from './components/CompetitionModule';
import { MusicClassModule } from './components/MusicClassModule';
import { EntertainmentModule } from './components/EntertainmentModule';
import { InnovationStudio } from './components/InnovationStudio';
import { TestModule } from './components/TestModule';
import { ProgressAndCredits } from './components/ProgressAndCredits';
import { Profile } from './components/Profile';
import { SettingsModal } from './components/SettingsModal';
import { AuthModal } from './components/AuthModal';

export const App: React.FC = () => {
  const { currentView, activeTab } = useApp();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const renderDashboardContent = () => {
    switch (activeTab) {
      case 'home':
        return <Dashboard />;
      case 'learning':
        return <LearningModule />;
      case 'rhymes':
        return <RhymesModule />;
      case 'competition':
        return <CompetitionModule />;
      case 'class':
        return <MusicClassModule />;
      case 'entertainment':
        return <EntertainmentModule />;
      case 'innovation':
        return <InnovationStudio />;
      case 'test':
        return <TestModule />;
      case 'progress':
      case 'credits':
        return <ProgressAndCredits />;
      case 'profile':
        return <Profile />;
      case 'settings':
        return <SettingsModal />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#0c0414] text-slate-100 selection:bg-purple-500 selection:text-white">
      {/* Top Navbar */}
      <Navbar onToggleMobileMenu={() => setIsMobileMenuOpen(!isMobileMenuOpen)} />

      {/* Main View Router */}
      {currentView === 'landing' && <LandingPage />}

      {currentView === 'purpose' && <PurposeSelection />}

      {currentView === 'dashboard' && (
        <div className="flex-1 flex max-w-[1600px] w-full mx-auto">
          {/* 12-Item Sidebar */}
          <Sidebar 
            isOpenMobile={isMobileMenuOpen} 
            onCloseMobile={() => setIsMobileMenuOpen(false)} 
          />

          {/* Main Module Content Area */}
          <main className="flex-1 p-4 sm:p-6 lg:p-8 overflow-y-auto max-w-full">
            {renderDashboardContent()}
          </main>
        </div>
      )}

      {/* Global Auth Modal */}
      <AuthModal />
    </div>
  );
};
