import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { audioEngine } from '../utils/audioEngine';
import { TestQuestion } from '../types';
import { 
  FileQuestion, 
  Sparkles, 
  Play, 
  CheckCircle2, 
  XCircle, 
  Award, 
  RotateCcw, 
  TrendingUp, 
  ArrowRight,
  ShieldCheck,
  AlertTriangle,
  Brain,
  Zap
} from 'lucide-react';

export const TestModule: React.FC = () => {
  const { user, updateUser, addCredits, setActiveTab } = useApp();

  const [testState, setTestState] = useState<'intro' | 'testing' | 'results'>('intro');
  const [activeCategory, setActiveCategory] = useState<string>('All Categories');
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [userAnswers, setUserAnswers] = useState<Record<number, number>>({});
  const [isAudioPromptPlaying, setIsAudioPromptPlaying] = useState(false);

  const sampleQuestions: TestQuestion[] = [
    {
      id: 'q-1',
      category: 'Music Theory',
      question: "Which of the following describes the Carnatic Mayamalavagowla raga's Gandharam and Nishadham?",
      options: [
        "Antara Gandharam (Ga3) and Kakali Nishadham (Ni3)",
        "Sadharana Gandharam (Ga2) and Kaisiki Nishadham (Ni2)",
        "Suddha Gandharam and Suddha Nishadham",
        "Suddha Madhyamam and Prati Madhyamam"
      ],
      correctIndex: 0,
      explanation: "Mayamalavagowla uses S, R1, G3, M1, P, D1, N3, S^ with symmetrically balanced semitone intervals."
    },
    {
      id: 'q-2',
      category: 'Listening',
      question: "Listen to this 3-note audio prompt. What musical interval is demonstrated?",
      options: [
        "Sa - Pa - Sȧ (Fundamental, Perfect 5th, Octave)",
        "Sa - Ri - Ga (Ascending Stepwise)",
        "Sa - Ma - Dha (Tritone Leap)",
        "Dha - Ni - Sa (Descending Leading Note)"
      ],
      audioPromptNotes: [261.63, 392.00, 523.25],
      correctIndex: 0,
      explanation: "The notes are C4 (261.63Hz), G4 (392Hz), and C5 (523.25Hz), representing the core harmonic spine."
    },
    {
      id: 'q-3',
      category: 'Rhythm',
      question: "In Adi Talam (8 beats), what is the finger count pattern for 1 Laghu (Chatusra Jathi)?",
      options: [
        "1 Beat (Clap) followed by 3 Finger Counts (Pinky, Ring, Middle)",
        "2 Claps and 2 Wave of hands",
        "4 continuous Wave of hands",
        "1 Clap and 1 Wave"
      ],
      correctIndex: 0,
      explanation: "Chatusra Jathi Laghu has 4 counts: 1 beat (Tattu) + 3 finger counts (Viral)."
    },
    {
      id: 'q-4',
      category: 'Learning Recall',
      question: "In our AI Educational Mnemonic, what is the rhyme memory trigger for 'Photosynthesis'?",
      options: [
        "Roots take water from the ground, Leaves catch sunlight all around!",
        "Boiling water turns to ice under the moon",
        "Electrons move without any resistance",
        "Planets stop moving when night falls"
      ],
      correctIndex: 0,
      explanation: "The mnemonic connects water intake at roots with photon capture in leaves!"
    },
    {
      id: 'q-5',
      category: 'Rhyme Recall',
      question: "Complete the rhyming phonics pair: 'Mercury is closest to the golden sun, Venus is the hottest one on the ___'",
      options: ["Run", "Sea", "Cloud", "Hill"],
      correctIndex: 0,
      explanation: "'Run' rhymes with 'Sun' to cement planet order in memory."
    }
  ];

  const handlePlayAudioPrompt = async (notes?: number[]) => {
    if (!notes || isAudioPromptPlaying) return;
    setIsAudioPromptPlaying(true);
    await audioEngine.playSequence(notes, 600, 'carnatic');
    setIsAudioPromptPlaying(false);
  };

  const handleSelectOption = (optionIndex: number) => {
    setUserAnswers(prev => ({
      ...prev,
      [currentQuestionIndex]: optionIndex
    }));
  };

  const handleNext = () => {
    if (currentQuestionIndex < sampleQuestions.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
    } else {
      // Complete test & calculate score
      finishTest();
    }
  };

  const finishTest = () => {
    let correctCount = 0;
    sampleQuestions.forEach((q, idx) => {
      if (userAnswers[idx] === q.correctIndex) {
        correctCount++;
      }
    });

    setTestState('results');
    updateUser({ testsCompleted: user.testsCompleted + 1 });
    addCredits(30, 'Completed Comprehensive Music & Learning Assessment');
  };

  const calculateScore = () => {
    let correctCount = 0;
    sampleQuestions.forEach((q, idx) => {
      if (userAnswers[idx] === q.correctIndex) {
        correctCount++;
      }
    });
    const percentage = Math.round((correctCount / sampleQuestions.length) * 100);
    return {
      percentage,
      correct: correctCount,
      incorrect: sampleQuestions.length - correctCount
    };
  };

  const results = calculateScore();

  return (
    <div className="space-y-8 animate-fadeIn max-w-5xl mx-auto pb-12">
      
      {/* Top Banner */}
      <div className="glass-panel p-6 sm:p-7 rounded-3xl border border-yellow-500/30 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-yellow-900/50 border border-yellow-500/40 text-yellow-300 text-xs font-bold mb-2">
            <FileQuestion className="w-3.5 h-3.5" />
            <span>OPTIONAL ADAPTIVE ASSESSMENT</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white">
            Music & Learning Test Module
          </h1>
          <p className="text-xs sm:text-sm text-yellow-200/80 mt-1 max-w-xl">
            Test your knowledge across Music Theory, Listening Ear, Rhythms, and Educational Recall.
          </p>
        </div>

        <div className="px-4 py-2 rounded-2xl bg-yellow-950/60 border border-yellow-700/40 text-xs font-bold text-yellow-300">
          Tests Completed: {user.testsCompleted}
        </div>
      </div>

      {/* ================= INTRO VIEW ================= */}
      {testState === 'intro' && (
        <div className="glass-panel p-8 rounded-3xl border border-purple-800/40 space-y-6 text-center max-w-2xl mx-auto shadow-2xl">
          <div className="w-16 h-16 rounded-3xl bg-yellow-400/20 border border-yellow-400/40 flex items-center justify-center text-yellow-400 mx-auto">
            <Brain className="w-8 h-8" />
          </div>

          <div className="space-y-2">
            <h2 className="text-2xl font-black text-white">Comprehensive 5-Question Quick Diagnostic</h2>
            <p className="text-xs text-purple-200/80 leading-relaxed max-w-md mx-auto">
              This diagnostic evaluates your ear training, swara discernment, rhythmic tala grasp, and mnemonic recall.
            </p>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-left text-xs">
            <div className="p-3 rounded-xl bg-purple-950/60 border border-purple-800/40">
              <span className="font-bold text-yellow-300">Music Theory</span>
              <div className="text-[10px] text-purple-300">Raga structures</div>
            </div>
            <div className="p-3 rounded-xl bg-purple-950/60 border border-purple-800/40">
              <span className="font-bold text-emerald-300">Listening</span>
              <div className="text-[10px] text-purple-300">Audio intervals</div>
            </div>
            <div className="p-3 rounded-xl bg-purple-950/60 border border-purple-800/40">
              <span className="font-bold text-blue-300">Rhythm</span>
              <div className="text-[10px] text-purple-300">Tala counts</div>
            </div>
            <div className="p-3 rounded-xl bg-purple-950/60 border border-purple-800/40">
              <span className="font-bold text-pink-300">Recall</span>
              <div className="text-[10px] text-purple-300">Mnemonic lyrics</div>
            </div>
          </div>

          <button
            onClick={() => {
              setTestState('testing');
              setCurrentQuestionIndex(0);
              setUserAnswers({});
            }}
            className="w-full py-4 rounded-2xl text-sm font-black bg-gradient-to-r from-yellow-500 via-amber-500 to-purple-600 text-slate-950 shadow-xl shadow-yellow-900/40 hover:scale-[1.01] transition-all flex items-center justify-center gap-2"
          >
            <span>Start Adaptive Test (+30 Credits)</span>
            <ArrowRight className="w-4 h-4 stroke-[3]" />
          </button>
        </div>
      )}

      {/* ================= TESTING IN-PROGRESS VIEW ================= */}
      {testState === 'testing' && (
        <div className="glass-panel p-6 sm:p-8 rounded-3xl border border-yellow-400/40 space-y-6 shadow-2xl">
          
          {/* Progress Header */}
          <div className="flex items-center justify-between pb-4 border-b border-purple-900/40">
            <span className="text-xs font-bold text-yellow-300 uppercase tracking-wider px-2.5 py-1 rounded bg-yellow-950/60 border border-yellow-700/40">
              {sampleQuestions[currentQuestionIndex].category}
            </span>
            <span className="text-xs text-purple-300 font-mono">
              Question {currentQuestionIndex + 1} of {sampleQuestions.length}
            </span>
          </div>

          {/* Question Text */}
          <div className="space-y-3">
            <h3 className="text-lg sm:text-xl font-bold text-white leading-relaxed">
              {sampleQuestions[currentQuestionIndex].question}
            </h3>

            {/* If audio prompt question */}
            {sampleQuestions[currentQuestionIndex].audioPromptNotes && (
              <div className="p-4 rounded-2xl bg-yellow-950/30 border border-yellow-500/30 flex items-center justify-between gap-4">
                <span className="text-xs text-yellow-200 font-medium">
                  🎵 Click to listen to the audio prompt:
                </span>
                <button
                  onClick={() => handlePlayAudioPrompt(sampleQuestions[currentQuestionIndex].audioPromptNotes)}
                  disabled={isAudioPromptPlaying}
                  className="px-4 py-2 rounded-xl text-xs font-bold bg-yellow-400 text-slate-950 hover:bg-yellow-300 flex items-center gap-1.5 transition-colors disabled:opacity-40"
                >
                  <Play className="w-3.5 h-3.5 fill-slate-950" />
                  <span>{isAudioPromptPlaying ? 'Playing Tone...' : 'Play Prompt'}</span>
                </button>
              </div>
            )}
          </div>

          {/* Options */}
          <div className="space-y-2.5 pt-2">
            {sampleQuestions[currentQuestionIndex].options.map((option, optIdx) => {
              const isSelected = userAnswers[currentQuestionIndex] === optIdx;
              return (
                <button
                  key={optIdx}
                  onClick={() => handleSelectOption(optIdx)}
                  className={`w-full p-4 rounded-2xl text-xs sm:text-sm font-semibold border text-left transition-all flex items-center justify-between ${
                    isSelected
                      ? 'bg-purple-700/60 border-yellow-400 text-white shadow-lg shadow-purple-950/80 ring-2 ring-yellow-400/50'
                      : 'bg-[#120724] border-purple-800/40 text-slate-200 hover:border-purple-600'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <span className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-black ${
                      isSelected ? 'bg-yellow-400 text-slate-950' : 'bg-purple-900/60 text-purple-300'
                    }`}>
                      {String.fromCharCode(65 + optIdx)}
                    </span>
                    <span>{option}</span>
                  </div>

                  {isSelected && <CheckCircle2 className="w-4 h-4 text-yellow-400" />}
                </button>
              );
            })}
          </div>

          {/* Bottom Navigation */}
          <div className="pt-4 border-t border-purple-900/40 flex items-center justify-between">
            <button
              onClick={() => {
                if (currentQuestionIndex > 0) setCurrentQuestionIndex(currentQuestionIndex - 1);
              }}
              disabled={currentQuestionIndex === 0}
              className="px-4 py-2 rounded-xl text-xs font-semibold text-purple-300 disabled:opacity-30"
            >
              Previous
            </button>

            <button
              onClick={handleNext}
              disabled={userAnswers[currentQuestionIndex] === undefined}
              className="px-6 py-2.5 rounded-xl text-xs font-bold bg-yellow-400 text-slate-950 font-black hover:bg-yellow-300 disabled:opacity-40 transition-colors flex items-center gap-1.5"
            >
              <span>{currentQuestionIndex === sampleQuestions.length - 1 ? 'Finish & View Score' : 'Next Question'}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}

      {/* ================= RESULTS & NEXT PRACTICE PLAN VIEW ================= */}
      {testState === 'results' && (
        <div className="glass-panel p-6 sm:p-8 rounded-3xl border border-yellow-400/40 space-y-6 shadow-2xl animate-fadeIn">
          
          <div className="text-center space-y-2">
            <div className="inline-flex p-3 bg-yellow-400/20 text-yellow-400 rounded-2xl">
              <Award className="w-8 h-8" />
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-white">Diagnostic Scorecard</h2>
            <p className="text-xs text-purple-200/80">
              Here is your performance breakdown across musical theory, ear training, and mnemonic retention.
            </p>
          </div>

          {/* Main Score Box (Score: 86/100, Correct: 17, Incorrect: 3 simulated) */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
            <div className="p-4 rounded-2xl bg-purple-950/60 border border-purple-800/40 text-center">
              <div className="text-xs font-bold text-purple-300 uppercase">Total Score</div>
              <div className="text-3xl font-black text-yellow-300 mt-1">{results.percentage}/100</div>
            </div>
            <div className="p-4 rounded-2xl bg-purple-950/60 border border-purple-800/40 text-center">
              <div className="text-xs font-bold text-purple-300 uppercase">Correct Answers</div>
              <div className="text-3xl font-black text-emerald-400 mt-1">{results.correct}</div>
            </div>
            <div className="p-4 rounded-2xl bg-purple-950/60 border border-purple-800/40 text-center">
              <div className="text-xs font-bold text-purple-300 uppercase">Incorrect / Review</div>
              <div className="text-3xl font-black text-red-400 mt-1">{results.incorrect}</div>
            </div>
          </div>

          {/* Strengths & Weak Areas Analysis */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 rounded-2xl bg-emerald-950/30 border border-emerald-500/30 space-y-2">
              <div className="flex items-center gap-2 text-xs font-bold text-emerald-300">
                <ShieldCheck className="w-4 h-4" />
                <span>Identified Strengths:</span>
              </div>
              <ul className="text-xs text-slate-300 space-y-1">
                <li>• Excellent harmonic interval discrimination (Sa-Pa-Sȧ)</li>
                <li>• Solid grasp of Adi Talam rhythm counts</li>
                <li>• High retention of educational mnemonic songs</li>
              </ul>
            </div>

            <div className="p-4 rounded-2xl bg-amber-950/30 border border-amber-500/30 space-y-2">
              <div className="flex items-center gap-2 text-xs font-bold text-amber-300">
                <AlertTriangle className="w-4 h-4" />
                <span>Recommended Focus Areas:</span>
              </div>
              <ul className="text-xs text-slate-300 space-y-1">
                <li>• Fine-tune Gandharam microtonal pitch on higher octave</li>
                <li>• Practice second speed (Dvitīya Kāla) tempo doubling</li>
              </ul>
            </div>
          </div>

          {/* "Create My Next Practice Plan" Button */}
          <div className="pt-2">
            <button
              onClick={() => {
                setActiveTab('competition');
              }}
              className="w-full py-4 rounded-2xl text-sm font-black bg-gradient-to-r from-yellow-400 via-amber-500 to-purple-600 text-slate-950 shadow-xl shadow-yellow-900/40 hover:scale-[1.01] transition-all flex items-center justify-center gap-2"
            >
              <Sparkles className="w-4 h-4 fill-slate-950" />
              <span>Create My Next Practice Plan</span>
            </button>
          </div>

        </div>
      )}

    </div>
  );
};
