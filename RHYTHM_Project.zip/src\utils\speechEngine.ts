// Web Speech Synthesis & Recognition Utility for RHYTHM

class SpeechEngine {
  private synth: SpeechSynthesis | null = null;
  private isSpeaking = false;

  constructor() {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      this.synth = window.speechSynthesis;
    }
  }

  public speak(
    text: string, 
    options?: { 
      rate?: number; 
      pitch?: number; 
      lang?: string; 
      onEnd?: () => void;
      onStart?: () => void;
    }
  ) {
    if (!this.synth) {
      if (options?.onEnd) options.onEnd();
      return;
    }

    this.stop();

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = options?.rate ?? 0.95;
    utterance.pitch = options?.pitch ?? 1.05;
    utterance.lang = options?.lang ?? 'en-US';

    utterance.onstart = () => {
      this.isSpeaking = true;
      if (options?.onStart) options.onStart();
    };

    utterance.onend = () => {
      this.isSpeaking = false;
      if (options?.onEnd) options.onEnd();
    };

    utterance.onerror = () => {
      this.isSpeaking = false;
      if (options?.onEnd) options.onEnd();
    };

    this.synth.speak(utterance);
  }

  public stop() {
    if (this.synth) {
      this.synth.cancel();
      this.isSpeaking = false;
    }
  }

  public getIsSpeaking() {
    return this.isSpeaking;
  }
}

export const speechEngine = new SpeechEngine();
