import React, { createContext, useContext, useState, useEffect } from 'react';
import { UserProfile, ActiveTab, RhymeItem, PracticeScore, TestQuestion } from '../types';
import confetti from 'canvas-confetti';

interface AppContextType {
  // Navigation & Auth
  currentView: 'landing' | 'purpose' | 'dashboard';
  setCurrentView: (view: 'landing' | 'purpose' | 'dashboard') => void;
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  isAuthModalOpen: boolean;
  setIsAuthModalOpen: (open: boolean) => void;
  authMode: 'login' | 'signup';
  setAuthMode: (mode: 'login' | 'signup') => void;
  
  // User Profile & Gamification
  user: UserProfile;
  updateUser: (updates: Partial<UserProfile>) => void;
  addCredits: (amount: number, reason: string) => void;
  creditNotification: { amount: number; reason: string } | null;
  
  // Rhymes & Custom Creations
  rhymesList: RhymeItem[];
  addCustomRhyme: (rhyme: RhymeItem) => void;
  
  // Competition Roadmap & Practice
  practiceHistory: PracticeScore[];
  addPracticeScore: (score: PracticeScore) => void;
  
  // Global Tanpura status
  isTanpuraActive: boolean;
  setIsTanpuraActive: (active: boolean) => void;
}

const defaultUser: UserProfile = {
  name: 'Ananya Sharma',
  age: 19,
  email: 'ananya.sharma@example.com',
  skillLevel: 'Intermediate',
  preferredLanguage: 'Both',
  selectedPurposes: ['learning', 'rhymes', 'competition', 'class', 'entertainment'],
  learningDays: ['Monday', 'Wednesday', 'Friday', 'Saturday'],
  preferredStyles: ['Carnatic', 'Folk'],
  competitionDate: '2026-11-20',
  competitionType: 'State Youth Classical Vocal Championship',
  credits: 320,
  streak: 5,
  level: 'Music Explorer',
  classesCompleted: 14,
  rhymesLearned: 9,
  testsCompleted: 6,
  innovationsDone: 8,
  competitionPrepProgress: 68
};

const initialRhymes: RhymeItem[] = [
  {
    id: 'rhyme-1',
    title: 'Rainbow Harmony (Colours & Light)',
    category: 'Colors',
    ageGroup: '3 - 8 yrs',
    difficulty: 'Easy',
    duration: '1:20',
    lyrics: [
      'Red is the apple, sweet and round,',
      'Orange is the pumpkin on the ground!',
      'Yellow is the sunshine bright and warm,',
      'Green is the clover in the storm!',
      'Blue is the ocean wide and deep,',
      'Purple the stars before we sleep!'
    ],
    audioNotes: [261.63, 293.66, 329.63, 349.23, 392.00, 440.00, 493.88, 523.25],
    bpm: 100,
    description: 'Learn the primary and secondary colors through joyful pentatonic rhythm.',
    icon: '🎨'
  },
  {
    id: 'rhyme-2',
    title: 'The Solar System Orbit Song',
    category: 'Educational',
    ageGroup: '5 - 12 yrs',
    difficulty: 'Medium',
    duration: '1:45',
    lyrics: [
      'Mercury is closest to the golden sun,',
      'Venus is the hottest one on the run!',
      'Earth is our home with oceans so blue,',
      'Mars is the red rock waiting for you!',
      'Jupiter is giant, Saturn wears a ring,',
      'Uranus and Neptune cold melodies sing!'
    ],
    audioNotes: [261.63, 329.63, 392.00, 523.25, 392.00, 329.63, 261.63],
    bpm: 110,
    description: 'Memorize all eight planets in order with catchy rhythmic cadence.',
    icon: '🪐'
  },
  {
    id: 'rhyme-3',
    title: 'Alphabet Phonics Swara Rhyme',
    category: 'Alphabet',
    ageGroup: '3 - 6 yrs',
    difficulty: 'Easy',
    duration: '1:15',
    lyrics: [
      'A is for Apple, crisp and red, (Sa Ri Ga)',
      'B is for Butterfly over my head! (Ga Ma Pa)',
      'C is for Cat that purrs in tune, (Pa Dha Ni)',
      'D is for Dancing under the moon! (Ni S^)'
    ],
    audioNotes: [261.63, 293.66, 329.63, 349.23, 392.00, 440.00, 493.88, 523.25],
    bpm: 95,
    description: 'Connect phonics to musical intervals for instant memory recall.',
    icon: '🌈'
  },
  {
    id: 'rhyme-4',
    title: 'Counting by Tens with River Beats',
    category: 'Numbers',
    ageGroup: '4 - 8 yrs',
    difficulty: 'Easy',
    duration: '1:10',
    lyrics: [
      'Ten little droplets jump in the stream,',
      'Twenty shiny pebbles softly gleam!',
      'Thirty little fishes swimming fast,',
      'Forty gentle breezes blowing past!',
      'Fifty silver waves arrive at last!'
    ],
    audioNotes: [261.63, 329.63, 392.00, 329.63, 261.63],
    bpm: 105,
    description: 'Master skip counting by 10s with playful river folk cadence.',
    icon: '🔢'
  },
  {
    id: 'rhyme-5',
    title: 'Forest Animals & Their Calls',
    category: 'Animals',
    ageGroup: '3 - 7 yrs',
    difficulty: 'Easy',
    duration: '1:30',
    lyrics: [
      'The elephant stomps with a heavy beat, (Boom Boom!)',
      'The peacock dances on nimble feet! (Ta-Dhi-Na!)',
      'The little deer leaps across the glade,',
      'The koel sings in the mango shade!'
    ],
    audioNotes: [392.00, 349.23, 329.63, 293.66, 261.63],
    bpm: 115,
    description: 'Animal movements and sounds tied to Indian percussion rhythms.',
    icon: '🐶'
  },
  {
    id: 'rhyme-6',
    title: 'Photosynthesis: The Plant Kitchen',
    category: 'Memory',
    ageGroup: '7 - 14 yrs',
    difficulty: 'Playful',
    duration: '1:50',
    lyrics: [
      'Roots take the water from the deep dark ground,',
      'Leaves catch sunlight all around!',
      'Carbon dioxide comes right in,',
      'Glucose and Oxygen let the feast begin!',
      'Photosynthesis is nature\'s rhythm!'
    ],
    audioNotes: [261.63, 293.66, 349.23, 392.00, 440.00, 523.25],
    bpm: 112,
    description: 'High school biology concept converted into an unforgettable mnemonic song.',
    icon: '🌱',
    isOriginal: true
  }
];

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentView, setCurrentView] = useState<'landing' | 'purpose' | 'dashboard'>('landing');
  const [activeTab, setActiveTab] = useState<ActiveTab>('home');
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'signup'>('signup');
  const [user, setUser] = useState<UserProfile>(() => {
    const saved = localStorage.getItem('rhythm_user');
    return saved ? JSON.parse(saved) : defaultUser;
  });
  const [rhymesList, setRhymesList] = useState<RhymeItem[]>(() => {
    const saved = localStorage.getItem('rhythm_rhymes');
    return saved ? JSON.parse(saved) : initialRhymes;
  });
  const [practiceHistory, setPracticeHistory] = useState<PracticeScore[]>([]);
  const [creditNotification, setCreditNotification] = useState<{ amount: number; reason: string } | null>(null);
  const [isTanpuraActive, setIsTanpuraActive] = useState(false);

  useEffect(() => {
    localStorage.setItem('rhythm_user', JSON.stringify(user));
  }, [user]);

  useEffect(() => {
    localStorage.setItem('rhythm_rhymes', JSON.stringify(rhymesList));
  }, [rhymesList]);

  const updateUser = (updates: Partial<UserProfile>) => {
    setUser(prev => {
      const updated = { ...prev, ...updates };
      // Level progression logic
      const credits = updated.credits;
      if (credits >= 1000) updated.level = 'Music Master';
      else if (credits >= 750) updated.level = 'Music Performer';
      else if (credits >= 500) updated.level = 'Music Creator';
      else if (credits >= 250) updated.level = 'Music Explorer';
      else if (credits >= 100) updated.level = 'Learner';
      else updated.level = 'Beginner';
      return updated;
    });
  };

  const addCredits = (amount: number, reason: string) => {
    updateUser({ credits: user.credits + amount });
    setCreditNotification({ amount, reason });
    confetti({
      particleCount: 50,
      spread: 60,
      origin: { y: 0.8 },
      colors: ['#9d60fb', '#f59e0b', '#38bdf8', '#10b981']
    });

    setTimeout(() => {
      setCreditNotification(null);
    }, 4000);
  };

  const addCustomRhyme = (rhyme: RhymeItem) => {
    setRhymesList(prev => [rhyme, ...prev]);
    addCredits(25, 'Created an Original AI Rhyme');
  };

  const addPracticeScore = (score: PracticeScore) => {
    setPracticeHistory(prev => [score, ...prev]);
    addCredits(20, 'Completed Competition Vocal Practice');
  };

  return (
    <AppContext.Provider
      value={{
        currentView,
        setCurrentView,
        activeTab,
        setActiveTab,
        isAuthModalOpen,
        setIsAuthModalOpen,
        authMode,
        setAuthMode,
        user,
        updateUser,
        addCredits,
        creditNotification,
        rhymesList,
        addCustomRhyme,
        practiceHistory,
        addPracticeScore,
        isTanpuraActive,
        setIsTanpuraActive
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
