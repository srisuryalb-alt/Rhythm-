import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  Settings, 
  Volume2, 
  Mic, 
  Globe2, 
  Moon, 
  Sun, 
  Sparkles, 
  ShieldCheck,
  CheckCircle2,
  Sliders
} from 'lucide-react';

export const SettingsModal: React.FC = () => {
  const { user, updateUser, addCredits } = useApp();
  const [tanpuraKey, setTanpuraKey] = useState('C4 (1 Kattai / 261.6Hz)');
  const [synthVolume, setSynthVolume] = useState(80);
  const [micGain, setMicGain] = useState(75);
  const [autoSpeech, setAutoSpeech] = useState(true);
  const [savedToast, setSavedToast] = useState(false);

  const handleSave = () => {
    setSavedToast(true);
    addCredits(5, 'Saved Audio & Experience Preferences');
    setTimeout(() => setSavedToast(false), 3000);
  };

  return (
    <div className="space-y-8 animate-fadeIn max-w-4xl mx-auto pb-12">
      
      {/* Top Banner */}
      <div className="glass-panel p-6 sm:p-7 rounded-3xl border border-purple-500/30 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-900/50 border border-purple-500/40 text-purple-300 text-xs font-bold mb-2">
            <Settings className="w-3.5 h-3.5" />
            <span>PLATFORM CONFIGURATION</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white">
            Audio & App Settings
          </h1>
          <p className="text-xs sm:text-sm text-purple-200/80 mt-1 max-w-xl">
            Configure your Shruti drone base tuning, microphone pitch sensitivity, and speech engine.
          </p>
        </div>

        <button
          onClick={handleSave}
          className="px-6 py-3 rounded-2xl text-xs font-bold bg-amber-400 text-slate-950 hover:bg-amber-300 shadow-md shadow-amber-400/20 transition-all"
        >
          Save All Settings
        </button>
      </div>

      {savedToast && (
        <div className="p-4 rounded-2xl bg-emerald-950/60 border border-emerald-400 text-emerald-200 text-xs font-bold flex items-center gap-2 animate-fadeIn">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>All audio synthesis & vocal tracking preferences saved!</span>
        </div>
      )}

      {/* Settings Options Grid */}
      <div className="glass-panel p-6 sm:p-8 rounded-3xl border border-purple-800/40 space-y-6">
        
        {/* 1. Tanpura Base Pitch */}
        <div className="pb-4 border-b border-purple-900/40 space-y-2">
          <label className="block text-xs font-bold text-white flex items-center gap-2">
            <Volume2 className="w-4 h-4 text-amber-400" />
            <span>Tanpura Drone Base Pitch (Adhara Shadjam)</span>
          </label>
          <select
            value={tanpuraKey}
            onChange={e => setTanpuraKey(e.target.value)}
            className="w-full sm:w-80 bg-[#120724] border border-purple-800/50 rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none focus:border-amber-400"
          >
            <option>C4 (1 Kattai / 261.63 Hz) - Standard Female / Youth</option>
            <option>C#4 (1.5 Kattai / 277.18 Hz)</option>
            <option>D4 (2 Kattai / 293.66 Hz)</option>
            <option>G3 (5 Kattai / 196.00 Hz) - Standard Male Base</option>
            <option>A3 (6 Kattai / 220.00 Hz)</option>
          </select>
          <p className="text-[11px] text-purple-300/70">
            Sets the fundamental harmonic drone tone for live classes, competition grading, and scales.
          </p>
        </div>

        {/* 2. Volume & Sensitivity Sliders */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 pb-4 border-b border-purple-900/40">
          <div className="space-y-2">
            <div className="flex justify-between text-xs font-bold text-white">
              <span className="flex items-center gap-1.5">
                <Sliders className="w-3.5 h-3.5 text-purple-400" />
                <span>Synthesizer Volume</span>
              </span>
              <span className="text-amber-300">{synthVolume}%</span>
            </div>
            <input
              type="range"
              min="0"
              max="100"
              value={synthVolume}
              onChange={e => setSynthVolume(Number(e.target.value))}
              className="w-full accent-amber-400"
            />
          </div>

          <div className="space-y-2">
            <div className="flex justify-between text-xs font-bold text-white">
              <span className="flex items-center gap-1.5">
                <Mic className="w-3.5 h-3.5 text-red-400" />
                <span>Microphone Pitch Sensitivity</span>
              </span>
              <span className="text-amber-300">{micGain}%</span>
            </div>
            <input
              type="range"
              min="0"
              max="100"
              value={micGain}
              onChange={e => setMicGain(Number(e.target.value))}
              className="w-full accent-amber-400"
            />
          </div>
        </div>

        {/* 3. AI Voice Narration */}
        <div className="flex items-center justify-between pb-4 border-b border-purple-900/40">
          <div>
            <h4 className="text-xs font-bold text-white">AI Voice Speech Narration</h4>
            <p className="text-[11px] text-purple-300/70">Enable Web Speech synthesis for AI Teacher & Rhymes.</p>
          </div>
          <button
            onClick={() => setAutoSpeech(!autoSpeech)}
            className={`w-12 h-6 rounded-full transition-colors relative p-0.5 ${autoSpeech ? 'bg-amber-400' : 'bg-purple-950'}`}
          >
            <div className={`w-5 h-5 rounded-full bg-slate-950 transition-transform ${autoSpeech ? 'translate-x-6' : 'translate-x-0'}`} />
          </button>
        </div>

        {/* 4. Language selection */}
        <div className="space-y-2">
          <label className="block text-xs font-bold text-white flex items-center gap-2">
            <Globe2 className="w-4 h-4 text-blue-400" />
            <span>Interface & Guidance Language</span>
          </label>
          <div className="flex gap-3">
            {['English', 'Tamil', 'Both'].map((lang) => (
              <button
                key={lang}
                onClick={() => updateUser({ preferredLanguage: lang as any })}
                className={`px-4 py-2 rounded-xl text-xs font-bold border transition-all ${
                  user.preferredLanguage === lang
                    ? 'bg-purple-700/60 border-amber-400 text-amber-200'
                    : 'bg-[#120724] border-purple-800/40 text-purple-300'
                }`}
              >
                {lang}
              </button>
            ))}
          </div>
        </div>

      </div>

    </div>
  );
};
