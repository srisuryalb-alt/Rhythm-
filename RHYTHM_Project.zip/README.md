# 🎵 RHYTHM — "Your Voice. Your Style. Your Journey."

An AI-powered music and learning web application prototype built with **React**, **TypeScript**, **Tailwind CSS**, and **Web Audio API**.

---

## 🚀 Quick Start Guide

### 1. Prerequisites
Ensure you have **Node.js** (v18 or higher) and **npm** installed on your system.

### 2. Install Dependencies
```bash
npm install
```

### 3. Run the Development Server
```bash
npm run dev
```
Open your browser and navigate to:
```
http://localhost:3000/
```

### 4. Build for Production
```bash
npm run build
```
To preview the production build:
```bash
npm run preview
```

---

## 🌟 Key Features

1. **Landing Page**:
   - Interactive Mayamalavagowla Swara keyboard with real-time Web Audio API sound synthesis.
   - Animated waveform visualizers and full startup showcase.

2. **Account Creation & Personalization**:
   - Onboarding with skill level (*Beginner, Intermediate, Advanced*) and language preference (*English, Tamil, Both*).
   - Purpose selection with 5 core tracks.

3. **5 Distinct Experiences**:
   - 📚 **Learning Module**: Conversational AI transforming educational poems, formulas, and history into musical mnemonics (no pitch evaluation pressure).
   - 🎵 **Rhymes Module**: 8 categories of children's rhymes, interactive karaoke lyrics, AI Rhyme Creator, and "Complete the Rhyme" puzzle game.
   - 🏆 **Music Competition**: Target date countdown, dynamic 6-month preparation roadmap, and live pitch canvas tracking with Shruti/Rhythm/Timing grading.
   - 🎤 **Music Class**: Weekly class scheduler (Carnatic & Folk) with a 4-panel live classroom (Teacher, Lesson Notation, Mic Sing-Along, and Live AI Feedback).
   - 🎧 **Entertainment**: "Let's Talk Music" AI chat, Rhythm & Beat Tapper BPM accuracy game, and Music Trivia challenge.

4. **Innovation Studio**:
   - Cross-genre AI style transformer (*Carnatic ↔ Folk ↔ Contemporary ↔ Rhythmic*) with live sing-back analysis.

5. **Gamification & Progress**:
   - Credit reward system with 6 mastery tiers (*Beginner → Music Master*).
   - Streak counters, progress bars, achievement badges, and comprehensive diagnostic tests.
   - Global **Tanpura Drone ($C_4$)** accessible anytime from the top navigation bar.

---

## 📁 Project Structure

```
├── public/                 # Static assets & favicon
├── src/
│   ├── components/         # UI components & modules
│   │   ├── AuthModal.tsx
│   │   ├── CompetitionModule.tsx
│   │   ├── Dashboard.tsx
│   │   ├── EntertainmentModule.tsx
│   │   ├── InnovationStudio.tsx
│   │   ├── LandingPage.tsx
│   │   ├── LearningModule.tsx
│   │   ├── MusicClassModule.tsx
│   │   ├── Navbar.tsx
│   │   ├── Profile.tsx
│   │   ├── ProgressAndCredits.tsx
│   │   ├── PurposeSelection.tsx
│   │   ├── RhymesModule.tsx
│   │   ├── SettingsModal.tsx
│   │   ├── Sidebar.tsx
│   │   └── TestModule.tsx
│   ├── context/            # Global AppContext & state management
│   ├── utils/              # Web Audio Engine & Web Speech API
│   ├── types.ts            # TypeScript interfaces
│   ├── App.tsx             # Main router & layout
│   ├── index.css           # Tailwind & custom CSS styles
│   └── main.tsx            # Entry point
├── index.html              # HTML template
├── tailwind.config.js      # Tailwind configuration
├── tsconfig.json           # TypeScript configuration
├── vite.config.ts          # Vite configuration
└── package.json            # Project dependencies & scripts
```
