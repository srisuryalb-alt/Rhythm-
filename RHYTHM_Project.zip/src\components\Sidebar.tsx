import React from 'react';
import { useApp } from '../context/AppContext';
import { ActiveTab } from '../types';
import {
  Home,
  BookOpen,
  Music,
  Trophy,
  GraduationCap,
  Headphones,
  Wand2,
  FileQuestion,
  TrendingUp,
  Coins,
  User,
  Settings,
  Sparkles,
  ChevronRight,
  LogOut
} from 'lucide-react';

interface SidebarProps {
  isOpenMobile?: boolean;
  onCloseMobile?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ isOpenMobile, onCloseMobile }) => {
  const { activeTab, setActiveTab, setCurrentView } = useApp();

  const navItems: { id: ActiveTab; label: string; icon: React.ReactNode; badge?: string; color: string }[] = [
    { id: 'home', label: 'Home', icon: <Home className="w-5 h-5" />, color: 'text-purple-400' },
    { id: 'learning', label: 'Learning', icon: <BookOpen className="w-5 h-5" />, badge: 'AI Study', color: 'text-blue-400' },
    { id: 'rhymes', label: 'Rhymes', icon: <Music className="w-5 h-5" />, badge: 'Kids', color: 'text-pink-400' },
    { id: 'competition', label: 'Music Competition', icon: <Trophy className="w-5 h-5" />, badge: 'Pitch AI', color: 'text-amber-400' },
    { id: 'class', label: 'Music Class', icon: <GraduationCap className="w-5 h-5" />, badge: 'Live AI', color: 'text-emerald-400' },
    { id: 'entertainment', label: 'Entertainment', icon: <Headphones className="w-5 h-5" />, color: 'text-cyan-400' },
    { id: 'innovation', label: 'Innovation Studio', icon: <Wand2 className="w-5 h-5" />, badge: 'New', color: 'text-purple-300' },
    { id: 'test', label: 'Test', icon: <FileQuestion className="w-5 h-5" />, color: 'text-yellow-400' },
    { id: 'progress', label: 'Progress', icon: <TrendingUp className="w-5 h-5" />, color: 'text-teal-400' },
    { id: 'credits', label: 'Credits & Badges', icon: <Coins className="w-5 h-5" />, color: 'text-amber-300' },
    { id: 'profile', label: 'Profile', icon: <User className="w-5 h-5" />, color: 'text-slate-300' },
    { id: 'settings', label: 'Settings', icon: <Settings className="w-5 h-5" />, color: 'text-slate-400' },
  ];

  const handleSelect = (tab: ActiveTab) => {
    setActiveTab(tab);
    if (onCloseMobile) onCloseMobile();
  };

  return (
    <>
      {/* Mobile Overlay */}
      {isOpenMobile && (
        <div 
          onClick={onCloseMobile}
          className="fixed inset-0 bg-black/70 backdrop-blur-sm z-40 lg:hidden"
        />
      )}

      <aside className={`
        fixed lg:sticky top-0 lg:top-[61px] left-0 z-40
        w-64 h-[100dvh] lg:h-[calc(100vh-61px)]
        bg-[#110722]/95 lg:bg-[#110722]/70 backdrop-blur-xl
        border-r border-purple-900/30 flex flex-col justify-between
        transition-transform duration-300 ease-in-out p-4
        ${isOpenMobile ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
      `}>
        {/* Navigation list */}
        <div className="overflow-y-auto space-y-1.5 pr-1 py-1">
          <div className="px-3 pb-2 pt-1">
            <span className="text-[11px] uppercase tracking-wider font-bold text-purple-400/70">
              Platform Modules
            </span>
          </div>

          {navItems.map(item => {
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => handleSelect(item.id)}
                className={`
                  w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-semibold
                  transition-all duration-200 group
                  ${isActive 
                    ? 'bg-gradient-to-r from-purple-700/80 to-indigo-700/80 text-white shadow-lg shadow-purple-900/40 border border-purple-500/40' 
                    : 'text-slate-300 hover:text-white hover:bg-purple-950/50 border border-transparent'}
                `}
              >
                <div className="flex items-center gap-3">
                  <span className={`${isActive ? 'text-amber-300' : item.color} group-hover:scale-110 transition-transform`}>
                    {item.icon}
                  </span>
                  <span>{item.label}</span>
                </div>

                <div className="flex items-center gap-1.5">
                  {item.badge && (
                    <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${
                      isActive 
                        ? 'bg-amber-400 text-slate-950' 
                        : 'bg-purple-900/60 text-purple-300 border border-purple-700/30'
                    }`}>
                      {item.badge}
                    </span>
                  )}
                  {isActive && <ChevronRight className="w-3.5 h-3.5 text-amber-300" />}
                </div>
              </button>
            );
          })}
        </div>

        {/* Bottom AI Innovation Card & Exit */}
        <div className="pt-3 border-t border-purple-900/40 space-y-2">
          <div className="p-3 rounded-2xl bg-gradient-to-br from-purple-900/50 via-indigo-950/60 to-purple-950/80 border border-purple-500/30">
            <div className="flex items-center gap-2 mb-1">
              <Sparkles className="w-4 h-4 text-amber-400 animate-pulse" />
              <span className="text-xs font-bold text-slate-100">AI Voice Engine</span>
            </div>
            <p className="text-[11px] text-purple-300/80 leading-relaxed">
              Real-time Swara, Pitch & Shruti analysis active.
            </p>
          </div>

          <button
            onClick={() => setCurrentView('landing')}
            className="w-full flex items-center justify-center gap-2 px-3 py-2 rounded-xl text-xs font-medium text-purple-300/70 hover:text-white hover:bg-purple-950/40 transition-colors"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Landing Page</span>
          </button>
        </div>
      </aside>
    </>
  );
};
