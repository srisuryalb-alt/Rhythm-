import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { audioEngine } from '../utils/audioEngine';
import { speechEngine } from '../utils/speechEngine';
import { ChatMessage } from '../types';
import { 
  BookOpen, 
  Mic, 
  Send, 
  Play, 
  Volume2, 
  VolumeX, 
  RotateCcw, 
  Sparkles, 
  HelpCircle, 
  Zap, 
  CheckCircle, 
  FastForward, 
  Smile,
  Info,
  Layers,
  StopCircle
} from 'lucide-react';

export const LearningModule: React.FC = () => {
  const { addCredits } = useApp();
  const [inputPrompt, setInputPrompt] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [isPlayingSong, setIsPlayingSong] = useState(false);
  const [activeNote, setActiveNote] = useState<string | null>(null);

  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'msg-1',
      sender: 'ai',
      text: "Hello! I am your AI Educational Music Tutor. Give me any poem, formula, science concept, or history date you need to memorize, and I will compose an original catchy song to help you memorize and understand it effortlessly!",
      timestamp: 'Just now',
      actions: ["Sing Again", "Make It Easier", "Slow It Down", "Repeat This Line", "Quiz Me", "Explain This"]
    },
    {
      id: 'msg-2',
      sender: 'user',
      text: "I have a poem to learn and I have a test tomorrow. Teach it to me as a song.",
      timestamp: 'Just now'
    },
    {
      id: 'msg-3',
      sender: 'ai',
      text: "Awesome! Let's turn your study material into an original musical mnemonic. Here is our 4-step memory song for the 'Water Cycle':\n\n🎶 [Verse 1 - Evaporation]:\nSun shines hot, water turns to steam,\nRising up like a misty dream! (Sa Ri Ga)\n\n☁️ [Verse 2 - Condensation]:\nCold air touches the vapor high,\nClouds are forming in the sky! (Ga Ma Pa)\n\n🌧️ [Chorus - Precipitation]:\nHeavy drops falling down in rain,\nRivers rushing back home again! (Pa Dha Ni S^)\n\nLet's practice line by line! Remember: You don't need perfect pitch here — our goal is 100% memorization and fun!",
      timestamp: 'Just now',
      musicalSnippet: {
        notes: ['S', 'R2', 'G3', 'M1', 'P', 'D2', 'N3', 'S^'],
        style: 'Mnemonic Cadence',
        tempo: 105
      },
      actions: ["Sing Again", "Make It Easier", "Slow It Down", "Repeat This Line", "Quiz Me", "Explain This"],
      quiz: {
        question: "In our song, what happens when 'Cold air touches the vapor high'?",
        options: [
          "Clouds are forming in the sky (Condensation)",
          "Water turns into heavy steam (Evaporation)",
          "Rivers freeze into ice",
          "Sun goes to sleep"
        ],
        correctIndex: 0,
        explanation: "Correct! That is Condensation where gas turns back into liquid cloud droplets!"
      }
    }
  ]);

  const [quizAnswered, setQuizAnswered] = useState<number | null>(null);

  const samplePrompts = [
    "I have a poem to learn and I have a test tomorrow. Teach it to me as a song.",
    "Teach Newton's 3 Laws of Motion as an energetic mnemonic rhyme.",
    "Help me memorize the first 10 elements of the Periodic Table.",
    "Convert the Indian Constitutional Preamble into a rhythmic song."
  ];

  const handleSendMessage = (textToSend?: string) => {
    const text = textToSend || inputPrompt;
    if (!text.trim()) return;

    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      sender: 'user',
      text,
      timestamp: 'Just now'
    };

    setMessages(prev => [...prev, userMsg]);
    setInputPrompt('');

    // Simulate AI Educational Song Breakdown
    setTimeout(() => {
      let aiResponseText = '';
      let notes = ['S', 'R2', 'G3', 'P', 'D2', 'S^'];

      if (text.toLowerCase().includes('newton')) {
        aiResponseText = "Here is your Newton's Laws Mnemonic Beat:\n\n1️⃣ Law 1 (Inertia): An object at rest stays fast asleep, unless an outside force takes a leap!\n2️⃣ Law 2 (F = ma): Force is mass times acceleration, push with power across the nation!\n3️⃣ Law 3 (Reaction): Every action has an equal reaction, push the wall and feel the counter-action!";
      } else if (text.toLowerCase().includes('periodic') || text.toLowerCase().includes('element')) {
        aiResponseText = "Here is your Periodic Elements Rhyme:\n\nHydrogen one, Helium two in the sun!\nLithium, Beryllium, Boron on the run!\nCarbon, Nitrogen, Oxygen we breathe,\nFluorine and Neon glowing beneath!";
      } else {
        aiResponseText = `Here is your custom memory song for: "${text}"\n\n🎶 [Part 1 - Understanding]:\nEvery key concept has a rhythm inside,\nBreak it in pieces with rhythm as guide!\n\n🎵 [Part 2 - Memory Hook]:\nRepeat twice daily before you rest,\nTomorrow morning you will ace your test!`;
      }

      const aiMsg: ChatMessage = {
        id: `ai-${Date.now()}`,
        sender: 'ai',
        text: aiResponseText,
        timestamp: 'Just now',
        musicalSnippet: {
          notes,
          style: 'Educational Mnemonic',
          tempo: 100
        },
        actions: ["Sing Again", "Make It Easier", "Slow It Down", "Repeat This Line", "Quiz Me", "Explain This"],
        quiz: {
          question: "Which learning technique makes this song stick in long-term memory?",
          options: [
            "Rhythmic chunking & melodic repetition",
            "Reading once silently without rhythm",
            "Memorizing backwards",
            "Skipping difficult words"
          ],
          correctIndex: 0,
          explanation: "Melodic cadence engages auditory memory and mnemonic association!"
        }
      };

      setMessages(prev => [...prev, aiMsg]);
      addCredits(10, 'Generated AI Educational Memory Song');
    }, 700);
  };

  const handleActionClick = async (action: string) => {
    if (action === 'Sing Again') {
      setIsPlayingSong(true);
      const songSnippet = ['S', 'R2', 'G3', 'M1', 'P', 'D2', 'N3', 'S^'];
      speechEngine.speak("Sing along with the notes!", { pitch: 1.1, rate: 1.0 });
      for (const note of songSnippet) {
        setActiveNote(note);
        audioEngine.playTone(note, 0.45, 'carnatic');
        await new Promise(r => setTimeout(r, 450));
      }
      setActiveNote(null);
      setIsPlayingSong(false);
    } else if (action === 'Slow It Down') {
      setIsPlayingSong(true);
      speechEngine.speak("Slowing down tempo to 60 BPM for easy practice.", { rate: 0.8 });
      const songSnippet = ['S', 'R2', 'G3', 'M1'];
      for (const note of songSnippet) {
        setActiveNote(note);
        audioEngine.playTone(note, 0.8, 'carnatic');
        await new Promise(r => setTimeout(r, 800));
      }
      setActiveNote(null);
      setIsPlayingSong(false);
    } else if (action === 'Make It Easier') {
      handleSendMessage("Can you make the words simpler and shorter for me?");
    } else if (action === 'Repeat This Line') {
      audioEngine.playSequence(['S', 'G3', 'P', 'G3', 'S'], 400, 'carnatic');
      speechEngine.speak("Sun shines hot, water turns to steam!", { pitch: 1.2 });
    } else if (action === 'Explain This') {
      handleSendMessage("Explain the deep concept behind this simply like I am five.");
    } else if (action === 'Quiz Me') {
      setQuizAnswered(null);
      const targetQuiz = document.getElementById('active-quiz-section');
      if (targetQuiz) {
        targetQuiz.scrollIntoView({ behavior: 'smooth' });
      }
    }
  };

  const handleVoiceToggle = () => {
    if (!isRecording) {
      setIsRecording(true);
      // Simulate speech-to-text recording
      setTimeout(() => {
        setIsRecording(false);
        handleSendMessage("I have a poem about planets to memorize for science test.");
      }, 3000);
    } else {
      setIsRecording(false);
    }
  };

  return (
    <div className="space-y-6 animate-fadeIn max-w-5xl mx-auto pb-12">
      
      {/* Header Banner */}
      <div className="glass-panel p-6 sm:p-7 rounded-3xl border border-blue-500/30 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-900/50 border border-blue-500/40 text-blue-300 text-xs font-bold mb-2">
            <BookOpen className="w-3.5 h-3.5" />
            <span>AI EDUCATIONAL LEARNING MODULE</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white">
            What do you want to learn?
          </h1>
          <p className="text-xs sm:text-sm text-blue-200/80 mt-1 max-w-2xl">
            Type any poem, chapter concept, or formula. The AI transforms it into an original musical mnemonic.
          </p>
        </div>

        {/* Focus Banner (No Pitch Pressure) */}
        <div className="p-3.5 rounded-2xl bg-blue-950/70 border border-blue-700/40 flex items-center gap-3 shrink-0">
          <div className="w-9 h-9 rounded-xl bg-blue-500/20 flex items-center justify-center text-blue-400">
            <Smile className="w-5 h-5" />
          </div>
          <div className="text-left">
            <div className="text-xs font-bold text-blue-200">No Pitch Grading</div>
            <div className="text-[10px] text-blue-300/70">Focus on Memorization & Fun</div>
          </div>
        </div>
      </div>

      {/* Suggested Quick Prompts */}
      <div className="space-y-2">
        <span className="text-xs font-semibold text-purple-300/80">Try asking:</span>
        <div className="flex flex-wrap gap-2">
          {samplePrompts.map((p, idx) => (
            <button
              key={idx}
              onClick={() => handleSendMessage(p)}
              className="text-xs px-3.5 py-2 rounded-xl bg-purple-950/50 hover:bg-purple-900/60 border border-purple-800/40 text-purple-200 hover:text-white transition-all text-left truncate max-w-md"
            >
              💡 "{p}"
            </button>
          ))}
        </div>
      </div>

      {/* Chat Messages Log */}
      <div className="space-y-4">
        {messages.map((msg) => {
          const isAI = msg.sender === 'ai';
          return (
            <div
              key={msg.id}
              className={`flex flex-col ${isAI ? 'items-start' : 'items-end'}`}
            >
              <div
                className={`max-w-3xl rounded-3xl p-5 sm:p-6 transition-all ${
                  isAI
                    ? 'glass-panel border-blue-500/30 text-slate-100 shadow-xl'
                    : 'bg-gradient-to-r from-purple-700 to-indigo-700 text-white shadow-lg shadow-purple-950/60'
                }`}
              >
                <div className="flex items-center justify-between gap-4 mb-2 pb-2 border-b border-purple-900/30">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-amber-300">
                      {isAI ? '🎵 RHYTHM AI Learning Companion' : 'You'}
                    </span>
                    {isAI && (
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-blue-900/60 text-blue-300 border border-blue-700/40">
                        Mnemonic Tutor
                      </span>
                    )}
                  </div>
                  <span className="text-[10px] text-purple-300/60">{msg.timestamp}</span>
                </div>

                <div className="text-xs sm:text-sm whitespace-pre-wrap leading-relaxed">
                  {msg.text}
                </div>

                {/* Swara note melody player if present */}
                {msg.musicalSnippet && (
                  <div className="mt-4 p-3.5 rounded-2xl bg-[#0c051a] border border-blue-800/40 flex flex-col sm:flex-row items-center justify-between gap-3">
                    <div className="flex items-center gap-2">
                      <Zap className="w-4 h-4 text-amber-400" />
                      <span className="text-xs font-semibold text-purple-200">
                        Mnemonic Melody ({msg.musicalSnippet.style} • {msg.musicalSnippet.tempo} BPM)
                      </span>
                    </div>

                    <div className="flex items-center gap-1.5">
                      {msg.musicalSnippet.notes.map((n, i) => (
                        <button
                          key={i}
                          onClick={() => {
                            setActiveNote(n);
                            audioEngine.playTone(n, 0.4, 'carnatic');
                            setTimeout(() => setActiveNote(null), 400);
                          }}
                          className={`w-7 h-7 rounded-lg text-xs font-bold border transition-all ${
                            activeNote === n 
                              ? 'bg-amber-400 text-slate-950 border-amber-300 scale-110 shadow-md' 
                              : 'bg-purple-900/50 border-purple-700/50 text-purple-200 hover:border-amber-400'
                          }`}
                        >
                          {n}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* 6 Required AI Learning Action Buttons */}
                {msg.actions && (
                  <div className="mt-4 pt-3 border-t border-purple-900/40 flex flex-wrap gap-2">
                    {msg.actions.map((act) => (
                      <button
                        key={act}
                        onClick={() => handleActionClick(act)}
                        className="px-3 py-1.5 rounded-xl text-xs font-semibold bg-purple-950/70 hover:bg-blue-600/30 border border-blue-500/30 text-blue-200 hover:text-white transition-all flex items-center gap-1.5"
                      >
                        {act === 'Sing Again' && <Play className="w-3 h-3 fill-blue-300" />}
                        {act === 'Make It Easier' && <Smile className="w-3 h-3 text-amber-300" />}
                        {act === 'Slow It Down' && <RotateCcw className="w-3 h-3 text-teal-300" />}
                        {act === 'Repeat This Line' && <Volume2 className="w-3 h-3 text-pink-300" />}
                        {act === 'Quiz Me' && <HelpCircle className="w-3 h-3 text-yellow-300" />}
                        {act === 'Explain This' && <Info className="w-3 h-3 text-indigo-300" />}
                        <span>{act}</span>
                      </button>
                    ))}
                  </div>
                )}

                {/* Interactive Concept Quiz */}
                {msg.quiz && (
                  <div id="active-quiz-section" className="mt-4 p-4 rounded-2xl bg-indigo-950/40 border border-blue-400/40 space-y-3">
                    <div className="flex items-center gap-2">
                      <HelpCircle className="w-4 h-4 text-amber-400" />
                      <span className="text-xs font-bold text-white">Recall Quiz:</span>
                    </div>
                    <p className="text-xs font-medium text-purple-200">{msg.quiz.question}</p>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {msg.quiz.options.map((opt, oIdx) => {
                        const isSelected = quizAnswered === oIdx;
                        const isCorrect = oIdx === msg.quiz?.correctIndex;
                        return (
                          <button
                            key={oIdx}
                            onClick={() => {
                              setQuizAnswered(oIdx);
                              if (isCorrect) addCredits(15, 'Passed Educational Recall Quiz!');
                            }}
                            className={`p-2.5 rounded-xl text-xs text-left border transition-all ${
                              quizAnswered !== null
                                ? isCorrect
                                  ? 'bg-emerald-600/30 border-emerald-400 text-emerald-200 font-bold'
                                  : isSelected
                                    ? 'bg-red-600/30 border-red-400 text-red-200'
                                    : 'bg-purple-950/40 border-purple-900/40 opacity-50'
                                : 'bg-purple-900/30 border-purple-700/40 hover:border-blue-400 text-slate-200'
                            }`}
                          >
                            <span className="font-bold mr-1.5">{String.fromCharCode(65 + oIdx)}.</span>
                            {opt}
                          </button>
                        );
                      })}
                    </div>
                    {quizAnswered !== null && (
                      <div className="text-xs text-amber-300 font-semibold pt-1">
                        {quizAnswered === msg.quiz.correctIndex ? '🎉 Perfect! ' : '💡 '}
                        {msg.quiz.explanation}
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Input / Microphone Bar */}
      <div className="sticky bottom-4 glass-panel p-3.5 rounded-2xl border border-blue-500/40 shadow-2xl flex items-center gap-3">
        <button
          onClick={handleVoiceToggle}
          className={`p-3 rounded-xl border transition-all ${
            isRecording 
              ? 'bg-red-600 text-white border-red-400 animate-pulse shadow-lg shadow-red-600/50' 
              : 'bg-purple-950/60 text-purple-300 border-purple-700/40 hover:bg-purple-900/60'
          }`}
          title={isRecording ? "Listening... Speak your poem" : "Voice Input (Microphone)"}
        >
          <Mic className="w-5 h-5" />
        </button>

        <input
          type="text"
          value={inputPrompt}
          onChange={e => setInputPrompt(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && handleSendMessage()}
          placeholder={isRecording ? "Listening to your voice..." : "Type a poem, formula, or topic to learn (e.g. 'Photosynthesis song')..."}
          className="flex-1 bg-transparent border-none text-xs sm:text-sm text-white placeholder-purple-400/40 focus:outline-none"
        />

        <button
          onClick={() => handleSendMessage()}
          disabled={!inputPrompt.trim()}
          className="p-3 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 text-white font-bold disabled:opacity-40 hover:scale-105 active:scale-95 transition-all"
        >
          <Send className="w-4 h-4" />
        </button>
      </div>

    </div>
  );
};
