import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { ActiveTab } from '../types';
import { 
  BookOpen, 
  Music, 
  Trophy, 
  GraduationCap, 
  Headphones, 
  Sparkles, 
  Check, 
  ArrowRight,
  Zap
} from 'lucide-react';

export const PurposeSelection: React.FC = () => {
  const { user, updateUser, setCurrentView, setActiveTab, addCredits } = useApp();
  const [selected, setSelected] = useState<string[]>(user.selectedPurposes || ['learning', 'class']);

  const purposeCards = [
    {
      id: 'learning',
      tab: 'learning' as ActiveTab,
      number: 'CARD 1',
      title: 'LEARNING',
      icon: <BookOpen className="w-8 h-8 text-blue-400" />,
      tagline: 'Learn educational content through music.',
      highlights: ['Mnemonic memorization songs', 'Formula & poem tutor', 'Fun concept quizzes'],
      badge: 'Study Boost',
      gradient: 'from-blue-600/20 via-indigo-900/30 to-purple-950/40',
      borderActive: 'border-blue-400'
    },
    {
      id: 'rhymes',
      tab: 'rhymes' as ActiveTab,
      number: 'CARD 2',
      title: 'RHYMES',
      icon: <Music className="w-8 h-8 text-pink-400" />,
      tagline: 'Learn fun and memorable rhymes through music.',
      highlights: ['Child-friendly animated lyrics', 'AI Rhyme Creator', 'Complete-the-Rhyme game'],
      badge: 'Kids & Early Learning',
      gradient: 'from-pink-600/20 via-purple-900/30 to-purple-950/40',
      borderActive: 'border-pink-400'
    },
    {
      id: 'competition',
      tab: 'competition' as ActiveTab,
      number: 'CARD 3',
      title: 'MUSIC COMPETITION',
      icon: <Trophy className="w-8 h-8 text-amber-400" />,
      tagline: 'Prepare for your upcoming music competition.',
      highlights: ['Target-date preparation roadmap', 'Live Pitch & Shruti analyzer', 'Stability & timing metrics'],
      badge: 'Vocal Performance',
      gradient: 'from-amber-600/20 via-orange-900/30 to-purple-950/40',
      borderActive: 'border-amber-400'
    },
    {
      id: 'class',
      tab: 'class' as ActiveTab,
      number: 'CARD 4',
      title: 'MUSIC CLASS',
      icon: <GraduationCap className="w-8 h-8 text-emerald-400" />,
      tagline: 'Learn music through personalized AI-guided classes.',
      highlights: ['Carnatic & Folk curriculum', '4-Panel interactive AI classroom', 'Live singing feedback'],
      badge: 'Structured Classes',
      gradient: 'from-emerald-600/20 via-teal-900/30 to-purple-950/40',
      borderActive: 'border-emerald-400'
    },
    {
      id: 'entertainment',
      tab: 'entertainment' as ActiveTab,
      number: 'CARD 5',
      title: 'ENTERTAINMENT',
      icon: <Headphones className="w-8 h-8 text-cyan-400" />,
      tagline: 'Chat, explore and enjoy music.',
      highlights: ['Casual AI music chatbot', 'Rhythm Tapper & Music Trivia', 'Genre discovery & voice fun'],
      badge: 'Explore & Play',
      gradient: 'from-cyan-600/20 via-blue-900/30 to-purple-950/40',
      borderActive: 'border-cyan-400'
    }
  ];

  const toggleSelect = (id: string) => {
    if (selected.includes(id)) {
      if (selected.length > 1) {
        setSelected(selected.filter(item => item !== id));
      }
    } else {
      setSelected([...selected, id]);
    }
  };

  const handleContinue = () => {
    updateUser({ selectedPurposes: selected });
    addCredits(15, 'Personalized Your RHYTHM Experience');
    // If one primary selected, switch to that tab, else home
    if (selected.length === 1) {
      const match = purposeCards.find(c => c.id === selected[0]);
      if (match) setActiveTab(match.tab);
      else setActiveTab('home');
    } else {
      setActiveTab('home');
    }
    setCurrentView('dashboard');
  };

  return (
    <div className="min-h-screen py-12 px-4 sm:px-6 lg:px-8 flex flex-col justify-center items-center relative overflow-hidden">
      {/* Ambient background glows */}
      <div className="absolute top-10 left-1/4 w-96 h-96 bg-purple-600/20 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute bottom-10 right-1/4 w-96 h-96 bg-amber-500/15 rounded-full blur-[120px] pointer-events-none" />

      <div className="max-w-5xl w-full relative z-10 space-y-8">
        
        {/* Header */}
        <div className="text-center space-y-3">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-purple-900/50 border border-purple-500/40 text-amber-300 text-xs font-bold">
            <Sparkles className="w-4 h-4 text-amber-400" />
            <span>STEP 2: PURPOSE SELECTION</span>
          </div>
          <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight text-white">
            What do you want to do today?
          </h1>
          <p className="text-sm sm:text-base text-purple-200/80 max-w-2xl mx-auto">
            Select one or multiple goals. RHYTHM adapts its AI intelligence, practice modules, and roadmap to fit your unique journey.
          </p>
        </div>

        {/* 5 Purpose Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {purposeCards.map((card, idx) => {
            const isChosen = selected.includes(card.id);
            const isWide = idx === 4; // Center the 5th card nicely

            return (
              <div
                key={card.id}
                onClick={() => toggleSelect(card.id)}
                className={`
                  cursor-pointer group relative rounded-3xl p-6 transition-all duration-300
                  bg-gradient-to-br ${card.gradient}
                  border backdrop-blur-xl flex flex-col justify-between
                  hover:scale-[1.02] hover:shadow-2xl
                  ${isChosen 
                    ? `${card.borderActive} shadow-xl shadow-purple-950/80 ring-2 ring-purple-400/40` 
                    : 'border-purple-900/40 opacity-80 hover:opacity-100'}
                  ${isWide ? 'md:col-span-2 lg:col-span-1' : ''}
                `}
              >
                {/* Selected Checkmark Badge */}
                <div className="flex items-center justify-between mb-4">
                  <span className="text-[11px] font-extrabold tracking-wider text-purple-300 uppercase px-2 py-0.5 rounded bg-purple-950/70 border border-purple-800/50">
                    {card.number}
                  </span>
                  
                  <div className={`w-7 h-7 rounded-full flex items-center justify-center transition-all ${
                    isChosen 
                      ? 'bg-amber-400 text-slate-950 font-bold shadow-md shadow-amber-400/50' 
                      : 'border border-purple-700/50 text-transparent group-hover:border-purple-400'
                  }`}>
                    <Check className="w-4 h-4 stroke-[3]" />
                  </div>
                </div>

                {/* Card Main Info */}
                <div className="space-y-3">
                  <div className="p-3 w-fit rounded-2xl bg-[#0d0517] border border-purple-800/40 shadow-inner group-hover:scale-110 transition-transform">
                    {card.icon}
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-white group-hover:text-amber-300 transition-colors">
                      {card.title}
                    </h3>
                    <p className="text-xs text-purple-200/90 font-medium mt-1 leading-relaxed">
                      "{card.tagline}"
                    </p>
                  </div>

                  <ul className="space-y-1.5 pt-2 border-t border-purple-900/40">
                    {card.highlights.map((h, i) => (
                      <li key={i} className="flex items-center gap-2 text-[11px] text-slate-300">
                        <Zap className="w-3 h-3 text-amber-400 shrink-0" />
                        <span>{h}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Bottom Pill */}
                <div className="mt-5 pt-3 flex items-center justify-between text-[11px] font-semibold text-purple-300">
                  <span className="px-2.5 py-1 rounded-full bg-purple-900/50 border border-purple-700/40">
                    {card.badge}
                  </span>
                  <span className="text-amber-300/80 group-hover:translate-x-1 transition-transform flex items-center gap-1">
                    Select <ArrowRight className="w-3 h-3" />
                  </span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Bottom CTA Bar */}
        <div className="glass-panel rounded-2xl p-4 sm:p-5 flex flex-col sm:flex-row items-center justify-between gap-4 border border-purple-500/30">
          <div className="text-center sm:text-left">
            <div className="text-sm font-bold text-white">
              {selected.length} Experience{selected.length > 1 ? 's' : ''} Selected
            </div>
            <p className="text-xs text-purple-300/80">
              You can switch between any module at any time from your dashboard sidebar.
            </p>
          </div>

          <button
            onClick={handleContinue}
            className="w-full sm:w-auto px-8 py-3.5 rounded-xl font-bold text-sm bg-gradient-to-r from-purple-600 via-indigo-600 to-amber-500 text-white shadow-lg shadow-purple-900/50 hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center justify-center gap-2"
          >
            <span>Open Main Dashboard</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
