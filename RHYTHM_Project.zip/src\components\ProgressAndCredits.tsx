import React from 'react';
import { useApp } from '../context/AppContext';
import { 
  TrendingUp, 
  Coins, 
  Flame, 
  Award, 
  Sparkles, 
  CheckCircle2, 
  BookOpen, 
  Music, 
  Trophy, 
  GraduationCap, 
  Wand2, 
  ShieldCheck,
  Zap,
  ArrowUpRight
} from 'lucide-react';

export const ProgressAndCredits: React.FC = () => {
  const { user, addCredits } = useApp();

  const tiers = [
    { name: 'Beginner', minCredits: 0, maxCredits: 99, perk: 'Basic AI Lessons & Rhymes' },
    { name: 'Learner', minCredits: 100, maxCredits: 249, perk: 'Weekly Class Generator Unlocked' },
    { name: 'Music Explorer', minCredits: 250, maxCredits: 499, perk: 'Innovation Studio & Raga Cross-Genre' },
    { name: 'Music Creator', minCredits: 500, maxCredits: 749, perk: 'Custom AI Rhyme Synthesizer' },
    { name: 'Music Performer', minCredits: 750, maxCredits: 999, perk: 'AI Competition Live Mock Panels' },
    { name: 'Music Master', minCredits: 1000, maxCredits: 5000, perk: 'All Access Guru Masterclasses' },
  ];

  const currentTierIndex = tiers.findIndex(t => t.name === user.level) !== -1 
    ? tiers.findIndex(t => t.name === user.level) 
    : 2;

  const nextTier = tiers[Math.min(tiers.length - 1, currentTierIndex + 1)];
  const currentTier = tiers[currentTierIndex];
  const progressToNextTier = Math.min(100, Math.round(((user.credits - currentTier.minCredits) / (nextTier.minCredits - currentTier.minCredits)) * 100));

  const creditEarningRules = [
    { action: "Completing AI Educational Learning", reward: "+10 Credits", icon: <BookOpen className="w-4 h-4 text-blue-400" /> },
    { action: "Completing Children's Rhyme Session", reward: "+10 Credits", icon: <Music className="w-4 h-4 text-pink-400" /> },
    { action: "Completing Diagnostic Test", reward: "+15 Credits", icon: <Award className="w-4 h-4 text-yellow-400" /> },
    { action: "Live AI Music Class Exercise", reward: "+20 Credits", icon: <GraduationCap className="w-4 h-4 text-emerald-400" /> },
    { action: "Competition Practice Session", reward: "+20 Credits", icon: <Trophy className="w-4 h-4 text-amber-400" /> },
    { action: "Cross-Genre Innovation Activity", reward: "+25 Credits", icon: <Wand2 className="w-4 h-4 text-purple-400" /> },
    { action: "Maintaining 7-Day Practice Streak", reward: "+50 Credits", icon: <Flame className="w-4 h-4 text-orange-400" /> },
  ];

  const progressMetrics = [
    { label: "AI Educational Learning", value: 90, bar: "█████████░ 90%", color: "bg-blue-500", text: "text-blue-300" },
    { label: "Children's Rhymes Progress", value: 70, bar: "███████░░░ 70%", color: "bg-pink-500", text: "text-pink-300" },
    { label: "Competition Preparation", value: user.competitionPrepProgress, bar: "██████░░░░ 68%", color: "bg-amber-500", text: "text-amber-300" },
    { label: "Overall Diagnostic Score", value: 86, bar: "████████░░ 86%", color: "bg-yellow-500", text: "text-yellow-300" },
  ];

  return (
    <div className="space-y-8 animate-fadeIn max-w-6xl mx-auto pb-12">
      
      {/* Top Banner */}
      <div className="glass-panel p-6 sm:p-7 rounded-3xl border border-purple-500/30 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-900/50 border border-purple-500/40 text-amber-300 text-xs font-bold mb-2">
            <Coins className="w-3.5 h-3.5" />
            <span>GAMIFICATION & ANALYTICS</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white">
            Progress & Credits Dashboard
          </h1>
          <p className="text-xs sm:text-sm text-purple-200/80 mt-1 max-w-xl">
            Track your multi-track learning growth, streak milestones, and tier level achievements.
          </p>
        </div>

        {/* Current Balance Card */}
        <div className="p-4 rounded-2xl bg-gradient-to-r from-purple-900/60 to-amber-900/40 border border-amber-400/40 flex items-center gap-4 shrink-0">
          <div className="w-12 h-12 rounded-2xl bg-amber-400/20 flex items-center justify-center text-amber-400">
            <Coins className="w-7 h-7" />
          </div>
          <div>
            <div className="text-2xl font-black text-amber-300">{user.credits} Credits</div>
            <div className="text-xs text-purple-200 font-semibold">Tier: {user.level}</div>
          </div>
        </div>
      </div>

      {/* ================= TIER LEVEL LADDER ================= */}
      <div className="glass-panel p-6 sm:p-8 rounded-3xl border border-purple-800/40 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h2 className="text-lg font-bold text-white flex items-center gap-2">
              <Award className="w-5 h-5 text-amber-400" />
              <span>RHYTHM Mastery Ladder</span>
            </h2>
            <p className="text-xs text-purple-300/70">
              Advance from Beginner to Music Master by practicing daily.
            </p>
          </div>

          <div className="text-xs text-amber-300 font-bold">
            {nextTier.minCredits - user.credits} pts to reach {nextTier.name}
          </div>
        </div>

        {/* Progress Bar to next tier */}
        <div className="space-y-1.5">
          <div className="flex justify-between text-xs text-purple-300 font-semibold">
            <span>{currentTier.name} ({currentTier.minCredits} pts)</span>
            <span>{nextTier.name} ({nextTier.minCredits} pts)</span>
          </div>
          <div className="w-full h-3 bg-purple-950 rounded-full overflow-hidden border border-purple-800/40 p-[2px]">
            <div 
              className="h-full bg-gradient-to-r from-purple-500 via-indigo-500 to-amber-400 rounded-full transition-all duration-500"
              style={{ width: `${progressToNextTier}%` }}
            />
          </div>
        </div>

        {/* All Tiers Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 pt-2">
          {tiers.map((t, idx) => {
            const isUnlocked = user.credits >= t.minCredits;
            const isCurrent = user.level === t.name;

            return (
              <div
                key={t.name}
                className={`p-4 rounded-2xl border transition-all flex flex-col justify-between ${
                  isCurrent
                    ? 'bg-purple-700/50 border-amber-400 shadow-lg shadow-purple-950/80 ring-1 ring-amber-400/60'
                    : isUnlocked
                      ? 'bg-purple-950/40 border-purple-700/40 opacity-90'
                      : 'bg-[#0f071a]/60 border-purple-900/30 opacity-40'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-[10px] font-extrabold uppercase text-amber-300">{t.minCredits}+ pts</span>
                    {isUnlocked && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />}
                  </div>
                  <div className="text-xs font-bold text-white">{t.name}</div>
                  <p className="text-[10px] text-purple-300/80 mt-1 leading-tight">{t.perk}</p>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* ================= VISUAL PROGRESS CHARTS & METRICS ================= */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Module Progress Bars */}
        <div className="lg:col-span-7 glass-panel p-6 sm:p-7 rounded-3xl border border-purple-800/40 space-y-5">
          <div className="flex items-center justify-between pb-3 border-b border-purple-900/40">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-teal-400" />
              <span>Multi-Track Module Progress</span>
            </h3>
            <span className="text-xs text-purple-300">Updated Live</span>
          </div>

          <div className="space-y-4">
            {progressMetrics.map((item, idx) => (
              <div key={idx} className="space-y-1.5">
                <div className="flex items-center justify-between text-xs font-semibold">
                  <span className="text-slate-200">{item.label}</span>
                  <span className={item.text}>{item.value}%</span>
                </div>
                <div className="w-full h-2.5 bg-purple-950 rounded-full overflow-hidden">
                  <div 
                    className={`h-full ${item.color} rounded-full transition-all duration-700`}
                    style={{ width: `${item.value}%` }}
                  />
                </div>
                <div className="font-mono text-[10px] text-purple-400/60">
                  {item.bar}
                </div>
              </div>
            ))}
          </div>

          {/* Improvement This Month Box */}
          <div className="p-4 rounded-2xl bg-teal-950/30 border border-teal-500/30 space-y-2 mt-4">
            <div className="text-xs font-bold text-teal-300 flex items-center gap-1.5">
              <Sparkles className="w-4 h-4" />
              <span>Your Improvement This Month</span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              • Pitch stability on Mandra Sthayi increased by <strong>+18%</strong><br />
              • Memorization recall time reduced by <strong>35%</strong> using melodic mnemonics<br />
              • Completed <strong>14</strong> weekly classes and <strong>9</strong> children rhymes
            </p>
          </div>
        </div>

        {/* Earning Opportunities Rulebook */}
        <div className="lg:col-span-5 glass-panel p-6 sm:p-7 rounded-3xl border border-purple-800/40 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-purple-900/40">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Coins className="w-4 h-4 text-amber-400" />
              <span>How to Earn Credits</span>
            </h3>
          </div>

          <div className="space-y-2.5">
            {creditEarningRules.map((rule, idx) => (
              <div
                key={idx}
                className="p-3 rounded-2xl bg-purple-950/40 border border-purple-900/40 flex items-center justify-between text-xs"
              >
                <div className="flex items-center gap-2.5">
                  <div className="p-1.5 rounded-lg bg-purple-900/60">
                    {rule.icon}
                  </div>
                  <span className="text-slate-200">{rule.action}</span>
                </div>
                <span className="font-bold text-amber-300 shrink-0">{rule.reward}</span>
              </div>
            ))}
          </div>
        </div>

      </div>

    </div>
  );
};
