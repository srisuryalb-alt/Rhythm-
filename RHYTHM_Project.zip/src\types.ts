export type SkillLevel = 'Beginner' | 'Intermediate' | 'Advanced';
export type Language = 'English' | 'Tamil' | 'Both';
export type MusicStyle = 'Carnatic' | 'Folk' | 'Hindustani' | 'Western Vocal' | 'Other';

export interface UserProfile {
  name: string;
  age: number;
  email: string;
  skillLevel: SkillLevel;
  preferredLanguage: Language;
  selectedPurposes: string[];
  learningDays: string[];
  preferredStyles: MusicStyle[];
  competitionDate?: string;
  competitionType?: string;
  credits: number;
  streak: number;
  level: string;
  classesCompleted: number;
  rhymesLearned: number;
  testsCompleted: number;
  innovationsDone: number;
  competitionPrepProgress: number;
}

export type ActiveTab = 
  | 'home'
  | 'learning'
  | 'rhymes'
  | 'competition'
  | 'class'
  | 'entertainment'
  | 'innovation'
  | 'test'
  | 'progress'
  | 'credits'
  | 'profile'
  | 'settings';

export interface RhymeItem {
  id: string;
  title: string;
  category: 'Alphabet' | 'Numbers' | 'Colors' | 'Animals' | 'Nature' | 'Educational' | 'Memory' | 'Original';
  ageGroup: string;
  difficulty: 'Easy' | 'Medium' | 'Playful';
  duration: string;
  lyrics: string[];
  audioNotes?: number[];
  bpm?: number;
  description: string;
  icon: string;
  isOriginal?: boolean;
}

export interface PracticeScore {
  pitch: number;
  shruti: number;
  rhythm: number;
  timing: number;
  stability: number;
  feedback: string;
  timestamp: string;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'ai';
  text: string;
  timestamp: string;
  musicalSnippet?: {
    notes: string[];
    style: string;
    tempo: number;
  };
  actions?: string[];
  quiz?: {
    question: string;
    options: string[];
    correctIndex: number;
    explanation: string;
  };
}

export interface TestQuestion {
  id: string;
  category: 'Music Knowledge' | 'Music Theory' | 'Listening' | 'Rhythm' | 'Learning Recall' | 'Rhyme Recall' | 'Performance';
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
  audioPromptNotes?: number[];
}
