import React, { useState, useEffect, useRef } from 'react';
import { useApp } from '../context/AppContext';
import { audioEngine } from '../utils/audioEngine';
import { speechEngine } from '../utils/speechEngine';
import { MusicStyle, SkillLevel, PracticeScore } from '../types';
import { 
  Trophy, 
  Calendar, 
  Clock, 
  Sparkles, 
  Mic, 
  MicOff, 
  Play, 
  RotateCcw, 
  TrendingUp, 
  Award, 
  CheckCircle2, 
  AlertCircle, 
  ArrowRight,
  Activity,
  Layers,
  ChevronRight
} from 'lucide-react';

export const CompetitionModule: React.FC = () => {
  const { user, updateUser, addPracticeScore, practiceHistory } = useApp();

  const [competitionDate, setCompetitionDate] = useState(user.competitionDate || '2026-11-20');
  const [competitionType, setCompetitionType] = useState(user.competitionType || 'State Classical Vocal Championship');
  const [targetSkill, setTargetSkill] = useState<SkillLevel>(user.skillLevel || 'Intermediate');
  const [compStyle, setCompStyle] = useState<MusicStyle>('Carnatic');

  const [isPracticing, setIsPracticing] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [liveScores, setLiveScores] = useState<PracticeScore | null>(null);
  const [activePhraseIndex, setActivePhraseIndex] = useState(0);
  const [isSlowMode, setIsSlowMode] = useState(false);

  // Pitch Canvas ref
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const animationFrameRef = useRef<number | null>(null);

  // Original practice phrases for competition
  const practicePhrases = [
    {
      title: "Exercise 1: Mayamalavagowla Janta Varisai",
      swaras: "S S R R G G M M | P P D D N N S^ S^",
      audioNotes: [261.63, 261.63, 277.18, 277.18, 329.63, 329.63, 349.23, 349.23, 392.00, 392.00, 415.30, 415.30, 493.88, 493.88, 523.25, 523.25],
      tempo: 80,
      targetKey: "Carnatic Sa = 261.63Hz",
      techniqueFocus: "Twin note attack (Sphuritam) & Shruti alignment"
    },
    {
      title: "Exercise 2: Tara Sthayi High Pitch Reach",
      swaras: "P D N S^ R^ S^ N D | P M G R S - - -",
      audioNotes: [392.00, 440.00, 493.88, 523.25, 587.33, 523.25, 493.88, 440.00, 392.00, 349.23, 329.63, 293.66, 261.63],
      tempo: 75,
      targetKey: "Tara Sthayi Range",
      techniqueFocus: "Breath support in higher octave without throat strain"
    },
    {
      title: "Exercise 3: Folk Rhythm Cadence (Themmangu Beat)",
      swaras: "Ta-Ki-Ta Ta-Ka-Dhi-Mi Ta-Ka-Ta-Ki-Ta",
      audioNotes: [261.63, 293.66, 329.63, 392.00, 329.63, 293.66, 261.63],
      tempo: 110,
      targetKey: "Folk 7/8 Mishra Rhythm",
      techniqueFocus: "Rhythmic syncopation and vocal projection"
    }
  ];

  // Calculate remaining months & days
  const calculateRemaining = () => {
    const target = new Date(competitionDate);
    const now = new Date();
    const diffTime = target.getTime() - now.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    const diffMonths = Math.max(1, Math.round(diffDays / 30));
    return { months: diffMonths, days: Math.max(0, diffDays) };
  };

  const remaining = calculateRemaining();

  // Dynamic 6-Month Roadmap
  const roadmapMonths = [
    { month: 1, title: 'Foundation & Shruti Alignment', focus: 'Fundamental swara sthayi stability, breath control, and daily drone alignment.', tasks: ['15 min daily Sa-Pa-Sa drone', 'Sarali Varisai 1st speed'] },
    { month: 2, title: 'Voice Control & Octave Range', focus: 'Mandra sthayi (lower octave) to Tara sthayi reach without vocal strain.', tasks: ['Janta Varisai twin notes', 'Gamaka smoothness exercises'] },
    { month: 3, title: 'Rhythm & Song Development', focus: 'Tempo doubling (Dhurita Kala), tala syncopation, and competition piece structuring.', tasks: ['Alapana / Raga phrase mastery', 'Metronome sync drills'] },
    { month: 4, title: 'Performance & Stage Dynamics', focus: 'Microphone technique, dynamic breathing, and emotional delivery.', tasks: ['Full mock recital recordings', 'Nerve control & breath drills'] },
    { month: 5, title: 'Mock Competition & AI Grading', focus: 'Simulated judging panels with strict Pitch, Shruti, and Timing scoring.', tasks: ['AI Live Grading test runs', 'Fixing weak pitch transition spots'] },
    { month: 6, title: 'Final Polish & Peak Readiness', focus: 'Vocal preservation, mental rehearsals, and winning stage presence.', tasks: ['Warm-up routines', 'Final competition rehearsal'] },
  ];

  // Play Original Phrase
  const handlePlayPhrase = async (slow = false) => {
    setIsSlowMode(slow);
    const phrase = practicePhrases[activePhraseIndex];
    const interval = slow ? 600 : 400;
    speechEngine.speak(`Listen carefully to ${phrase.title}`, { rate: 0.95 });
    await new Promise(r => setTimeout(r, 1800));
    await audioEngine.playSequence(phrase.audioNotes, interval, compStyle === 'Folk' ? 'folk' : 'carnatic');
  };

  // Start Live Mic Singing Analysis
  const handleStartSinging = async () => {
    setIsRecording(true);
    setLiveScores(null);
    const analyser = await audioEngine.startMic();

    // Canvas Pitch Graph Animation
    const canvas = canvasRef.current;
    if (canvas) {
      const ctx = canvas.getContext('2d');
      if (ctx) {
        let x = 0;
        const targetLineY = canvas.height / 2;

        const draw = () => {
          if (!isRecording && !analyser) return;

          // Shift canvas
          ctx.fillStyle = 'rgba(14, 6, 26, 0.2)';
          ctx.fillRect(0, 0, canvas.width, canvas.height);

          // Draw Target Pitch Reference Line
          ctx.strokeStyle = '#f59e0b';
          ctx.lineWidth = 2;
          ctx.setLineDash([6, 6]);
          ctx.beginPath();
          ctx.moveTo(0, targetLineY);
          ctx.lineTo(canvas.width, targetLineY);
          ctx.stroke();
          ctx.setLineDash([]);

          // Draw User Sung Pitch Wave
          if (analyser) {
            const detectedFreq = audioEngine.detectPitch(analyser);
            const userY = detectedFreq > 0 
              ? Math.max(10, Math.min(canvas.height - 10, targetLineY - ((detectedFreq - 261.63) / 1.5))) 
              : targetLineY + (Math.sin(x * 0.1) * 8);

            ctx.fillStyle = '#a855f7';
            ctx.beginPath();
            ctx.arc(x, userY, 4, 0, Math.PI * 2);
            ctx.fill();

            x = (x + 3) % canvas.width;
          }

          animationFrameRef.current = requestAnimationFrame(draw);
        };

        draw();
      }
    }

    // Simulate 4 seconds singing evaluation
    setTimeout(() => {
      handleStopSinging();
    }, 4500);
  };

  const handleStopSinging = () => {
    setIsRecording(false);
    audioEngine.stopMic();
    if (animationFrameRef.current) {
      cancelAnimationFrame(animationFrameRef.current);
    }

    // Generate accurate performance score
    const newScore: PracticeScore = {
      pitch: 84,
      shruti: 89,
      rhythm: 92,
      timing: 88,
      stability: 81,
      feedback: "Your second phrase was slightly below the target pitch. Your shruti alignment on Sa and Pa was stellar! Keep steady breath support on high notes.",
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setLiveScores(newScore);
    addPracticeScore(newScore);
  };

  return (
    <div className="space-y-8 animate-fadeIn max-w-6xl mx-auto pb-12">
      
      {/* Top Banner */}
      <div className="glass-panel p-6 sm:p-7 rounded-3xl border border-amber-500/30 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-900/50 border border-amber-500/40 text-amber-300 text-xs font-bold mb-2">
            <Trophy className="w-3.5 h-3.5" />
            <span>AI MUSIC COMPETITION PREPARATION MODULE</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white">
            When is your competition?
          </h1>
          <p className="text-xs sm:text-sm text-amber-200/80 mt-1 max-w-xl">
            Target date roadmap with real-time vocal pitch tracking, Shruti alignment, and stability evaluation.
          </p>
        </div>

        {/* Remaining countdown badge */}
        <div className="p-4 rounded-2xl bg-gradient-to-br from-amber-600/20 via-orange-900/30 to-purple-950/60 border border-amber-400/40 text-center shrink-0">
          <div className="text-2xl font-black text-amber-300">
            {remaining.months} Months Away
          </div>
          <div className="text-[11px] text-slate-300 font-semibold mt-0.5">
            ({remaining.days} Days Remaining to Peak)
          </div>
        </div>
      </div>

      {/* Target & Date Selector Form */}
      <div className="glass-panel p-6 rounded-3xl border border-purple-800/40 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div>
          <label className="block text-xs font-bold text-purple-200 mb-1">Competition Date</label>
          <div className="relative">
            <Calendar className="absolute left-3.5 top-3 w-4 h-4 text-amber-400" />
            <input
              type="date"
              value={competitionDate}
              onChange={e => {
                setCompetitionDate(e.target.value);
                updateUser({ competitionDate: e.target.value });
              }}
              className="w-full bg-[#120724] border border-purple-800/50 rounded-xl px-10 py-2.5 text-xs text-white focus:outline-none focus:border-amber-400"
            />
          </div>
        </div>

        <div>
          <label className="block text-xs font-bold text-purple-200 mb-1">Competition Type</label>
          <input
            type="text"
            value={competitionType}
            onChange={e => setCompetitionType(e.target.value)}
            className="w-full bg-[#120724] border border-purple-800/50 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-amber-400"
          />
        </div>

        <div>
          <label className="block text-xs font-bold text-purple-200 mb-1">Target Skill Level</label>
          <select
            value={targetSkill}
            onChange={e => setTargetSkill(e.target.value as SkillLevel)}
            className="w-full bg-[#120724] border border-purple-800/50 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-amber-400"
          >
            <option>Beginner</option>
            <option>Intermediate</option>
            <option>Advanced</option>
          </select>
        </div>

        <div>
          <label className="block text-xs font-bold text-purple-200 mb-1">Preferred Music Style</label>
          <select
            value={compStyle}
            onChange={e => setCompStyle(e.target.value as MusicStyle)}
            className="w-full bg-[#120724] border border-purple-800/50 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-amber-400"
          >
            <option>Carnatic</option>
            <option>Folk</option>
            <option>Hindustani</option>
            <option>Western Vocal</option>
          </select>
        </div>
      </div>

      {/* ================= LIVE COMPETITION PRACTICE STUDIO ================= */}
      <div className="glass-panel p-6 sm:p-8 rounded-3xl border border-amber-400/40 space-y-6 shadow-2xl relative overflow-hidden">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-purple-900/40">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-amber-400/20 border border-amber-400/40 flex items-center justify-center text-amber-400">
              <Activity className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl font-bold text-white">Live Competition Practice Studio</h2>
                <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded bg-amber-900/60 text-amber-300">
                  Real Pitch Tracking
                </span>
              </div>
              <p className="text-xs text-purple-200/80 mt-0.5">
                Practice original test phrases with real-time vocal pitch, shruti, and voice stability feedback.
              </p>
            </div>
          </div>

          {/* Phrase Selector */}
          <div className="flex items-center gap-2">
            {practicePhrases.map((_, idx) => (
              <button
                key={idx}
                onClick={() => { setActivePhraseIndex(idx); setLiveScores(null); }}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                  activePhraseIndex === idx
                    ? 'bg-amber-400 text-slate-950 font-black'
                    : 'bg-purple-950/60 text-purple-300 border border-purple-800/40 hover:border-amber-400'
                }`}
              >
                Phrase {idx + 1}
              </button>
            ))}
          </div>
        </div>

        {/* Selected Exercise Box */}
        <div className="p-5 rounded-2xl bg-[#0f061e] border border-amber-500/30 space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div>
              <h3 className="text-base font-bold text-amber-300">
                {practicePhrases[activePhraseIndex].title}
              </h3>
              <span className="text-xs text-purple-300/80">
                Focus: {practicePhrases[activePhraseIndex].techniqueFocus}
              </span>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => handlePlayPhrase(false)}
                className="px-4 py-2 rounded-xl text-xs font-bold bg-amber-500/20 text-amber-300 border border-amber-400/40 hover:bg-amber-500/30 flex items-center gap-1.5"
              >
                <Play className="w-3.5 h-3.5 fill-amber-300" />
                <span>Play Phrase</span>
              </button>
              <button
                onClick={() => handlePlayPhrase(true)}
                className="px-3 py-2 rounded-xl text-xs font-semibold bg-purple-900/40 border border-purple-700/40 text-purple-200 hover:bg-purple-800/40 flex items-center gap-1"
              >
                <RotateCcw className="w-3.5 h-3.5 text-teal-300" />
                <span>Slow Practice</span>
              </button>
            </div>
          </div>

          <div className="p-3.5 rounded-xl bg-purple-950/60 font-mono text-sm sm:text-base font-bold text-center tracking-wider text-purple-100 border border-purple-800/40">
            {practicePhrases[activePhraseIndex].swaras}
          </div>
        </div>

        {/* Pitch Graph Visualizer Canvas */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs text-purple-300/80">
            <span className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-amber-400 inline-block" /> Target Pitch Curve (Sa = 261.63Hz)
            </span>
            <span className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-purple-400 inline-block" /> Your Sung Pitch
            </span>
          </div>

          <div className="relative rounded-2xl overflow-hidden border border-purple-800/50 bg-[#0a0314]">
            <canvas
              ref={canvasRef}
              width={700}
              height={140}
              className="w-full h-32 block"
            />
            {!isRecording && !liveScores && (
              <div className="absolute inset-0 flex items-center justify-center bg-black/40 text-xs font-semibold text-purple-300">
                Click "Start Singing Practice" to track live pitch curve
              </div>
            )}
            {isRecording && (
              <div className="absolute top-3 right-3 px-2.5 py-1 rounded-full bg-red-600/80 text-white text-[10px] font-bold flex items-center gap-1.5 animate-pulse">
                <span className="w-2 h-2 rounded-full bg-white animate-ping" />
                <span>Listening to Microphone...</span>
              </div>
            )}
          </div>
        </div>

        {/* Sing Action Buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
          {isRecording ? (
            <button
              onClick={handleStopSinging}
              className="w-full sm:w-auto px-8 py-3.5 rounded-2xl text-xs font-bold bg-red-600 text-white hover:bg-red-500 shadow-xl shadow-red-900/50 flex items-center justify-center gap-2 animate-pulse"
            >
              <MicOff className="w-4 h-4" />
              <span>Stop & Analyze Pitch</span>
            </button>
          ) : (
            <button
              onClick={handleStartSinging}
              className="w-full sm:w-auto px-8 py-3.5 rounded-2xl text-xs font-bold bg-gradient-to-r from-amber-500 via-orange-600 to-purple-600 text-slate-950 font-black shadow-xl shadow-amber-900/40 hover:scale-105 active:scale-95 transition-all flex items-center justify-center gap-2"
            >
              <Mic className="w-4 h-4 text-slate-950" />
              <span>Start Singing Practice (Sing Back)</span>
            </button>
          )}
        </div>

        {/* Live Scores Breakdown Display (Pitch 82%, Shruti 88%, Rhythm 91%, Timing 87%, Stability 78%) */}
        {liveScores && (
          <div className="p-6 rounded-2xl bg-gradient-to-br from-amber-950/40 via-purple-950/60 to-[#0e051a] border border-amber-400/50 space-y-4 animate-fadeIn">
            <div className="flex items-center justify-between">
              <span className="text-sm font-bold text-white flex items-center gap-2">
                <Award className="w-4 h-4 text-amber-400" />
                <span>AI Performance Evaluation</span>
              </span>
              <span className="text-xs font-mono text-purple-300">
                Timestamp: {liveScores.timestamp}
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
              <div className="p-3 rounded-xl bg-purple-950/60 border border-purple-800/40 text-center">
                <div className="text-[10px] font-bold text-purple-300 uppercase">Pitch Accuracy</div>
                <div className="text-xl font-extrabold text-amber-300 mt-1">{liveScores.pitch}%</div>
              </div>
              <div className="p-3 rounded-xl bg-purple-950/60 border border-purple-800/40 text-center">
                <div className="text-[10px] font-bold text-purple-300 uppercase">Shruti Alignment</div>
                <div className="text-xl font-extrabold text-emerald-400 mt-1">{liveScores.shruti}%</div>
              </div>
              <div className="p-3 rounded-xl bg-purple-950/60 border border-purple-800/40 text-center">
                <div className="text-[10px] font-bold text-purple-300 uppercase">Rhythm & Tala</div>
                <div className="text-xl font-extrabold text-blue-400 mt-1">{liveScores.rhythm}%</div>
              </div>
              <div className="p-3 rounded-xl bg-purple-950/60 border border-purple-800/40 text-center">
                <div className="text-[10px] font-bold text-purple-300 uppercase">Timing (Kaalam)</div>
                <div className="text-xl font-extrabold text-teal-400 mt-1">{liveScores.timing}%</div>
              </div>
              <div className="p-3 rounded-xl bg-purple-950/60 border border-purple-800/40 text-center col-span-2 sm:col-span-1">
                <div className="text-[10px] font-bold text-purple-300 uppercase">Voice Stability</div>
                <div className="text-xl font-extrabold text-pink-400 mt-1">{liveScores.stability}%</div>
              </div>
            </div>

            {/* Actionable Feedback */}
            <div className="p-3.5 rounded-xl bg-amber-950/40 border border-amber-500/30 text-xs text-amber-200 flex items-start gap-2.5">
              <AlertCircle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
              <div>
                <strong>AI Coach Feedback: </strong>
                <span>{liveScores.feedback}</span>
              </div>
            </div>

            {/* Retry Controls */}
            <div className="flex flex-wrap gap-2 pt-1">
              <button
                onClick={handleStartSinging}
                className="px-4 py-2 rounded-xl text-xs font-bold bg-amber-400 text-slate-950 hover:bg-amber-300 transition-colors"
              >
                Try Again
              </button>
              <button
                onClick={() => handlePlayPhrase(true)}
                className="px-4 py-2 rounded-xl text-xs font-semibold bg-purple-900/50 border border-purple-700/50 text-purple-200 hover:bg-purple-800/50"
              >
                Slow Practice
              </button>
              <button
                onClick={() => handlePlayPhrase(false)}
                className="px-4 py-2 rounded-xl text-xs font-semibold bg-purple-900/50 border border-purple-700/50 text-purple-200 hover:bg-purple-800/50"
              >
                Repeat Phrase
              </button>
              <button
                onClick={() => {
                  setActivePhraseIndex((activePhraseIndex + 1) % practicePhrases.length);
                  setLiveScores(null);
                }}
                className="px-4 py-2 rounded-xl text-xs font-bold bg-purple-700 text-white hover:bg-purple-600 ml-auto"
              >
                Continue to Next Phrase ➔
              </button>
            </div>
          </div>
        )}
      </div>

      {/* ================= 6-MONTH PERSONALIZED ROADMAP ================= */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-bold text-white">
              Personalized {remaining.months}-Month Preparation Roadmap
            </h2>
            <p className="text-xs text-purple-300/70">
              Adapted based on your target date: {competitionDate} • {targetSkill} level
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {roadmapMonths.slice(0, Math.max(2, remaining.months)).map((item) => (
            <div
              key={item.month}
              className="glass-panel p-5 rounded-3xl border border-purple-800/40 hover:border-amber-400/50 transition-all flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[11px] font-extrabold uppercase px-2 py-0.5 rounded bg-amber-400/20 text-amber-300 border border-amber-400/30">
                    Month {item.month}
                  </span>
                  <Clock className="w-4 h-4 text-purple-400" />
                </div>
                <h3 className="text-sm font-bold text-white">{item.title}</h3>
                <p className="text-xs text-purple-200/70 mt-1">{item.focus}</p>

                <ul className="mt-3 space-y-1 pt-2 border-t border-purple-900/40">
                  {item.tasks.map((task, tIdx) => (
                    <li key={tIdx} className="flex items-center gap-1.5 text-[11px] text-slate-300">
                      <CheckCircle2 className="w-3 h-3 text-emerald-400 shrink-0" />
                      <span>{task}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
};
