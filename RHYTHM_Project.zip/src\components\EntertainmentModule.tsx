import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { audioEngine } from '../utils/audioEngine';
import { speechEngine } from '../utils/speechEngine';
import { 
  Headphones, 
  Sparkles, 
  Send, 
  Play, 
  Gamepad2, 
  HelpCircle, 
  Flame, 
  Volume2, 
  Award, 
  Activity, 
  MessageSquare,
  Music,
  Radio,
  Zap
} from 'lucide-react';

export const EntertainmentModule: React.FC = () => {
  const { addCredits } = useApp();
  const [activeSubTab, setActiveSubTab] = useState<'chat' | 'tapper' | 'trivia' | 'guess'>('chat');
  const [chatInput, setChatInput] = useState('');
  
  // Chat History
  const [messages, setMessages] = useState<Array<{ sender: 'ai' | 'user'; text: string; time: string }>>([
    {
      sender: 'ai',
      text: "Welcome to RHYTHM Entertainment! 🎧 I'm your musical companion. Ask me anything about song concepts, Indian and Western music theory, movie song analysis, or play a rhythm game!",
      time: 'Just now'
    }
  ]);

  // Rhythm Tapper Game State
  const [tapperBpm, setTapperBpm] = useState(100);
  const [isTappingGameActive, setIsTappingGameActive] = useState(false);
  const [tapTimes, setTapTimes] = useState<number[]>([]);
  const [tapAccuracy, setTapAccuracy] = useState<number | null>(null);

  // Trivia State
  const [triviaIndex, setTriviaIndex] = useState(0);
  const [selectedTriviaOption, setSelectedTriviaOption] = useState<number | null>(null);

  const entertainmentPrompts = [
    "Recommend music for relaxation and focus.",
    "Tell me about Carnatic music raga systems.",
    "Give me a fun music quiz.",
    "Teach me a simple daily singing warm-up exercise.",
    "I want to learn how cinema composers blend folk and classical music."
  ];

  const triviaQuestions = [
    {
      q: "How many Melakarta (parent) ragas exist in the Carnatic music system?",
      options: ["36", "72", "108", "54"],
      correct: 1,
      fact: "The 72 Melakarta system was systematized by Venkatamakhin in his treatise Chaturdandi Prakasika."
    },
    {
      q: "What is the primary rhythm cycle (Talam) with 8 beats called in South Indian music?",
      options: ["Rupaka Talam", "Adi Talam", "Mishra Chapu", "Jhampa Talam"],
      correct: 1,
      fact: "Adi Talam is the most common Carnatic rhythmic cycle, structured as 1 Laghu (4 counts) and 2 Dhrithams (2 + 2 counts)."
    },
    {
      q: "Which note in Western solfege corresponds to 'Panchamam' (Pa) in Indian classical music?",
      options: ["Do", "Fa", "Sol (So)", "La"],
      correct: 2,
      fact: "Panchamam (Pa) is the perfect fifth interval, corresponding to 'Sol' in Western solfege!"
    }
  ];

  // Send AI Music Chat
  const handleSendChat = (presetText?: string) => {
    const text = presetText || chatInput;
    if (!text.trim()) return;

    setMessages(prev => [...prev, { sender: 'user', text, time: 'Just now' }]);
    setChatInput('');

    setTimeout(() => {
      let reply = '';
      if (text.toLowerCase().includes('carnatic')) {
        reply = "Carnatic music is built on two core pillars: Raga (melodic framework) and Tala (rhythmic cycle). It uses microtones called 'Srutis' and expressive vocal oscillations called 'Gamakas'. Would you like to hear a sample Mayamalavagowla or Kalyani scale?";
      } else if (text.toLowerCase().includes('cinema')) {
        reply = "Cinema music composers (like Ilaiyaraaja, A.R. Rahman, and Anirudh) masterfully blend traditional Indian ragas with Western harmonic progressions and modern synthesizers! For example, folk Themmangu rhythms often form the pulse of upbeat film songs.";
      } else if (text.toLowerCase().includes('recommend')) {
        reply = "For deep focus, I recommend ragas like 'Mohanam' (pentatonic harmony) or ambient sitar & flute in 432Hz. For uplifting energy, try dynamic folk percussions in Mishra Chapu!";
      } else {
        reply = `That is a wonderful musical question! In music acoustics, every tone consists of a fundamental frequency and a series of harmonic overtones that give each human voice its unique acoustic fingerprint. Keep exploring your vocal timbre!`;
      }

      setMessages(prev => [...prev, { sender: 'ai', text: reply, time: 'Just now' }]);
      addCredits(5, 'Engaged in AI Music Chat');
    }, 600);
  };

  // Rhythm Tapper Tap Action
  const handleUserTap = () => {
    if (!isTappingGameActive) {
      setIsTappingGameActive(true);
      setTapTimes([Date.now()]);
      audioEngine.playClick(true);
      return;
    }

    const now = Date.now();
    const last = tapTimes[tapTimes.length - 1];
    const diff = now - last;
    const targetInterval = (60 / tapperBpm) * 1000;
    const error = Math.abs(diff - targetInterval);
    const accuracyPercent = Math.max(20, Math.round(100 - (error / targetInterval) * 100));

    audioEngine.playClick(false);
    setTapTimes([...tapTimes, now]);
    setTapAccuracy(accuracyPercent);

    if (accuracyPercent > 85) {
      addCredits(10, 'Achieved 85%+ Beat Accuracy in Rhythm Tapper!');
    }
  };

  return (
    <div className="space-y-6 animate-fadeIn max-w-5xl mx-auto pb-12">
      
      {/* Top Banner */}
      <div className="glass-panel p-6 sm:p-7 rounded-3xl border border-cyan-500/30 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-900/50 border border-cyan-500/40 text-cyan-300 text-xs font-bold mb-2">
            <Headphones className="w-3.5 h-3.5" />
            <span>AI MUSIC ENTERTAINMENT & GAMES</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white">
            Let's Talk Music
          </h1>
          <p className="text-xs sm:text-sm text-cyan-200/80 mt-1 max-w-xl">
            Chat casually with AI about music theory, cinema compositions, or play rhythm mini-games.
          </p>
        </div>

        {/* Sub-tabs switch */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setActiveSubTab('chat')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all ${
              activeSubTab === 'chat'
                ? 'bg-cyan-500 text-slate-950 font-black shadow-md'
                : 'bg-purple-950/60 text-purple-300 border border-purple-800/40'
            }`}
          >
            Music Chat
          </button>
          <button
            onClick={() => setActiveSubTab('tapper')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all ${
              activeSubTab === 'tapper'
                ? 'bg-cyan-500 text-slate-950 font-black shadow-md'
                : 'bg-purple-950/60 text-purple-300 border border-purple-800/40'
            }`}
          >
            Rhythm Tapper
          </button>
          <button
            onClick={() => setActiveSubTab('trivia')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all ${
              activeSubTab === 'trivia'
                ? 'bg-cyan-500 text-slate-950 font-black shadow-md'
                : 'bg-purple-950/60 text-purple-300 border border-purple-800/40'
            }`}
          >
            Music Trivia
          </button>
        </div>
      </div>

      {/* ================= CHAT SUB-TAB ================= */}
      {activeSubTab === 'chat' && (
        <div className="space-y-4">
          
          {/* Preset Prompts */}
          <div className="flex flex-wrap gap-2">
            {entertainmentPrompts.map((p, i) => (
              <button
                key={i}
                onClick={() => handleSendChat(p)}
                className="text-xs px-3.5 py-1.5 rounded-xl bg-purple-950/60 hover:bg-cyan-900/40 border border-purple-800/40 text-purple-200 hover:text-white transition-all text-left"
              >
                💬 "{p}"
              </button>
            ))}
          </div>

          {/* Messages */}
          <div className="space-y-3 min-h-[280px]">
            {messages.map((m, idx) => {
              const isAI = m.sender === 'ai';
              return (
                <div key={idx} className={`flex flex-col ${isAI ? 'items-start' : 'items-end'}`}>
                  <div className={`max-w-2xl rounded-2xl p-4 text-xs sm:text-sm leading-relaxed ${
                    isAI 
                      ? 'glass-panel border-cyan-500/30 text-slate-100' 
                      : 'bg-gradient-to-r from-cyan-600 to-blue-600 text-white shadow-lg'
                  }`}>
                    <div className="text-[10px] font-bold text-cyan-300 mb-1">
                      {isAI ? '🎧 RHYTHM AI Music Companion' : 'You'}
                    </div>
                    {m.text}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Chat Input */}
          <div className="sticky bottom-4 glass-panel p-3 rounded-2xl border border-cyan-500/40 flex items-center gap-3">
            <input
              type="text"
              value={chatInput}
              onChange={e => setChatInput(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && handleSendChat()}
              placeholder="Ask about ragas, cinema music, rhythm, instruments, or recommendations..."
              className="flex-1 bg-transparent border-none text-xs sm:text-sm text-white placeholder-purple-400/40 focus:outline-none"
            />
            <button
              onClick={() => handleSendChat()}
              disabled={!chatInput.trim()}
              className="p-3 rounded-xl bg-cyan-500 text-slate-950 font-bold hover:bg-cyan-400 disabled:opacity-40 transition-all"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* ================= RHYTHM TAPPER SUB-TAB ================= */}
      {activeSubTab === 'tapper' && (
        <div className="glass-panel p-8 rounded-3xl border border-cyan-500/40 text-center space-y-6 shadow-2xl">
          <div className="max-w-md mx-auto space-y-2">
            <div className="w-12 h-12 mx-auto rounded-2xl bg-cyan-500/20 text-cyan-300 flex items-center justify-center">
              <Activity className="w-6 h-6 animate-pulse" />
            </div>
            <h2 className="text-xl font-bold text-white">Rhythm & Beat Tapper</h2>
            <p className="text-xs text-purple-200/80">
              Tap the large pad in sync with the {tapperBpm} BPM tempo to test your rhythmic timing accuracy!
            </p>
          </div>

          <div className="flex items-center justify-center gap-3">
            <span className="text-xs text-purple-300 font-semibold">Target Tempo:</span>
            {[80, 100, 120].map(bpm => (
              <button
                key={bpm}
                onClick={() => { setTapperBpm(bpm); setTapAccuracy(null); setTapTimes([]); }}
                className={`px-3 py-1 rounded-xl text-xs font-bold border transition-all ${
                  tapperBpm === bpm 
                    ? 'bg-cyan-400 text-slate-950 border-cyan-300 font-black' 
                    : 'bg-purple-950/60 border-purple-800/40 text-purple-200'
                }`}
              >
                {bpm} BPM
              </button>
            ))}
          </div>

          {/* Giant Interactive Tap Pad */}
          <div className="py-4">
            <button
              onClick={handleUserTap}
              className="w-44 h-44 rounded-full bg-gradient-to-tr from-cyan-600 via-blue-600 to-purple-600 border-4 border-cyan-400/60 shadow-2xl shadow-cyan-900/60 hover:scale-105 active:scale-95 transition-transform flex flex-col items-center justify-center gap-2 text-white mx-auto cursor-pointer"
            >
              <Zap className="w-8 h-8 text-amber-300 animate-bounce" />
              <span className="text-sm font-black tracking-widest uppercase">
                {isTappingGameActive ? 'TAP THE BEAT!' : 'START TAP'}
              </span>
              <span className="text-[10px] text-cyan-200">{tapperBpm} BPM</span>
            </button>
          </div>

          {tapAccuracy !== null && (
            <div className="p-4 rounded-2xl bg-cyan-950/50 border border-cyan-400/40 max-w-sm mx-auto animate-fadeIn">
              <div className="text-2xl font-black text-amber-300">{tapAccuracy}% Accuracy</div>
              <p className="text-xs text-cyan-200 mt-1">
                {tapAccuracy >= 85 ? '🌟 Flawless rhythmic precision! Great Tala sense.' : 'Good try! Keep steady tempo intervals.'}
              </p>
            </div>
          )}
        </div>
      )}

      {/* ================= MUSIC TRIVIA SUB-TAB ================= */}
      {activeSubTab === 'trivia' && (
        <div className="glass-panel p-8 rounded-3xl border border-cyan-500/40 space-y-6 max-w-xl mx-auto text-center shadow-2xl">
          <div className="flex items-center justify-between pb-3 border-b border-purple-900/40">
            <span className="text-xs font-bold text-amber-300">Music Trivia Challenge</span>
            <span className="text-xs text-purple-300">Question {triviaIndex + 1} of {triviaQuestions.length}</span>
          </div>

          <h3 className="text-lg font-bold text-white leading-relaxed">
            {triviaQuestions[triviaIndex].q}
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
            {triviaQuestions[triviaIndex].options.map((opt, oIdx) => {
              const isSelected = selectedTriviaOption === oIdx;
              const isCorrect = oIdx === triviaQuestions[triviaIndex].correct;
              return (
                <button
                  key={oIdx}
                  onClick={() => {
                    setSelectedTriviaOption(oIdx);
                    if (isCorrect) addCredits(10, 'Answered Music Trivia correctly!');
                  }}
                  className={`p-3.5 rounded-2xl text-xs font-bold border transition-all text-left ${
                    selectedTriviaOption !== null
                      ? isCorrect
                        ? 'bg-emerald-600/30 border-emerald-400 text-emerald-200'
                        : isSelected
                          ? 'bg-red-600/30 border-red-400 text-red-200'
                          : 'bg-purple-950/40 border-purple-900/40 opacity-40'
                      : 'bg-[#120724] border-purple-800/40 text-white hover:border-cyan-400'
                  }`}
                >
                  <span className="font-extrabold mr-2">{String.fromCharCode(65 + oIdx)}.</span>
                  {opt}
                </button>
              );
            })}
          </div>

          {selectedTriviaOption !== null && (
            <div className="p-4 rounded-2xl bg-purple-900/40 border border-purple-700/40 space-y-3 animate-fadeIn">
              <div className="text-xs font-bold text-amber-300">
                {selectedTriviaOption === triviaQuestions[triviaIndex].correct ? '🎉 Correct!' : '💡 Music Fact:'}
              </div>
              <p className="text-xs text-purple-200 leading-relaxed">
                {triviaQuestions[triviaIndex].fact}
              </p>
              <button
                onClick={() => {
                  setSelectedTriviaOption(null);
                  setTriviaIndex((triviaIndex + 1) % triviaQuestions.length);
                }}
                className="px-5 py-2 rounded-xl text-xs font-bold bg-cyan-400 text-slate-950 hover:bg-cyan-300"
              >
                Next Trivia Question ➔
              </button>
            </div>
          )}
        </div>
      )}

    </div>
  );
};
