import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { MusicStyle } from '../types';
import { audioEngine } from '../utils/audioEngine';
import { speechEngine } from '../utils/speechEngine';
import { 
  GraduationCap, 
  Calendar, 
  Sparkles, 
  Play, 
  Pause, 
  Mic, 
  MicOff, 
  CheckCircle2, 
  RotateCcw, 
  User, 
  Volume2, 
  Award, 
  ArrowRight,
  Activity,
  Layers,
  HelpCircle,
  Clock
} from 'lucide-react';

export const MusicClassModule: React.FC = () => {
  const { user, updateUser, addCredits } = useApp();

  // Class Builder State
  const [daysCount, setDaysCount] = useState<number>(user.learningDays?.length || 4);
  const [selectedDays, setSelectedDays] = useState<string[]>(user.learningDays || ['Monday', 'Wednesday', 'Friday', 'Saturday']);
  const [selectedStyle, setSelectedStyle] = useState<MusicStyle>('Carnatic');
  const [isClassActive, setIsClassActive] = useState(false);

  // Live AI Class 4-Panel State
  const [teacherState, setTeacherState] = useState<'idle' | 'demonstrating' | 'listening' | 'evaluating'>('idle');
  const [activeStep, setActiveStep] = useState(0);
  const [isSinging, setIsSinging] = useState(false);
  const [classScores, setClassScores] = useState<{
    pitch: 'Good' | 'Excellent' | 'Needs Work';
    shruti: 'Slightly Sharp' | 'Perfect' | 'Flat';
    rhythm: 'Excellent' | 'Good' | 'Fair';
    timing: string;
    stability: string;
    feedback: string;
  } | null>(null);

  const daysOfWeek = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

  const classCurriculum = [
    {
      title: "Sarali Varisai - Lesson 1 (Basic Arohana & Avarohana)",
      raga: "Mayamalavagowla (Raga 15)",
      talam: "Adi Talam (8 Beats / 1 Laghu 2 Dhritham)",
      tempo: 80,
      notation: [
        { swara: "S", label: "Sa", freq: 261.63 },
        { swara: "R1", label: "Ri", freq: 277.18 },
        { swara: "G3", label: "Ga", freq: 329.63 },
        { swara: "M1", label: "Ma", freq: 349.23 },
        { swara: "P", label: "Pa", freq: 392.00 },
        { swara: "D1", label: "Dha", freq: 415.30 },
        { swara: "N3", label: "Ni", freq: 493.88 },
        { swara: "S^", label: "Sȧ", freq: 523.25 }
      ],
      instructions: "Keep your spine upright. Sing from your naval with steady breath support on 'Sa' and 'Pa'."
    },
    {
      title: "Sarali Varisai - Lesson 2 (Double Swara Jumps)",
      raga: "Mayamalavagowla",
      talam: "Adi Talam",
      tempo: 90,
      notation: [
        { swara: "S", label: "Sa", freq: 261.63 },
        { swara: "R1", label: "Ri", freq: 277.18 },
        { swara: "S", label: "Sa", freq: 261.63 },
        { swara: "R1", label: "Ri", freq: 277.18 },
        { swara: "S", label: "Sa", freq: 261.63 },
        { swara: "R1", label: "Ri", freq: 277.18 },
        { swara: "G3", label: "Ga", freq: 329.63 },
        { swara: "M1", label: "Ma", freq: 349.23 }
      ],
      instructions: "Emphasize clean articulation between Shadjam and Rishabham."
    },
    {
      title: "Tamil Folk Themmangu Melody Rhythm Exercise",
      raga: "Folk Khamas Mode",
      talam: "Chatusra Eka Talam",
      tempo: 105,
      notation: [
        { swara: "S", label: "Tha", freq: 261.63 },
        { swara: "R2", label: "Dhi", freq: 293.66 },
        { swara: "G3", label: "Na", freq: 329.63 },
        { swara: "P", label: "Thom", freq: 392.00 },
        { swara: "G3", label: "Na", freq: 329.63 },
        { swara: "R2", label: "Dhi", freq: 293.66 },
        { swara: "S", label: "Tha", freq: 261.63 }
      ],
      instructions: "Feel the earthy folk groove. Crisp consonants with relaxed open vowels."
    }
  ];

  const currentLesson = classCurriculum[activeStep % classCurriculum.length];

  const toggleDay = (day: string) => {
    if (selectedDays.includes(day)) {
      if (selectedDays.length > 1) {
        setSelectedDays(selectedDays.filter(d => d !== day));
      }
    } else {
      setSelectedDays([...selectedDays, day]);
    }
  };

  // AI Teacher Demonstrates
  const handleTeacherDemonstrate = async () => {
    setTeacherState('demonstrating');
    speechEngine.speak(`Hello ${user.name}! Let's begin our live session on ${currentLesson.title}. Listen to me sing the phrase first.`, {
      pitch: 1.05,
      rate: 0.95
    });

    await new Promise(r => setTimeout(r, 4500));

    // Play synthesized swara notes
    for (const note of currentLesson.notation) {
      audioEngine.playTone(note.freq, 0.45, selectedStyle === 'Folk' ? 'folk' : 'carnatic');
      await new Promise(r => setTimeout(r, 480));
    }

    speechEngine.speak("Now your turn! Click 'Start Singing' and sing the swaras back with steady breath.", {
      pitch: 1.05,
      rate: 0.95
    });

    setTeacherState('idle');
  };

  // User Sings & AI Analyzes
  const handleStartUserSinging = async () => {
    setIsSinging(true);
    setTeacherState('listening');
    setClassScores(null);
    await audioEngine.startMic();

    // 4.5 seconds sing duration
    setTimeout(() => {
      handleStopUserSinging();
    }, 4500);
  };

  const handleStopUserSinging = () => {
    setIsSinging(false);
    audioEngine.stopMic();
    setTeacherState('evaluating');

    setTimeout(() => {
      const evaluation = {
        pitch: 'Good' as const,
        shruti: 'Slightly Sharp' as const,
        rhythm: 'Excellent' as const,
        timing: '92% in beat',
        stability: '86% steady',
        feedback: `Great attempt, ${user.name}! Your rhythm and tempo alignment are spot on. Notice how 'Ga' was slightly sharp against the C4 drone — gently relax your jaw on Antara Gandharam.`
      };

      setClassScores(evaluation);
      setTeacherState('idle');
      addCredits(20, 'Completed Live AI Music Class Exercise');
      speechEngine.speak(evaluation.feedback, { pitch: 1.05, rate: 0.95 });
    }, 800);
  };

  return (
    <div className="space-y-8 animate-fadeIn max-w-6xl mx-auto pb-12">
      
      {/* Top Banner */}
      <div className="glass-panel p-6 sm:p-7 rounded-3xl border border-emerald-500/30 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-900/50 border border-emerald-500/40 text-emerald-300 text-xs font-bold mb-2">
            <GraduationCap className="w-3.5 h-3.5" />
            <span>AI MUSIC CLASS MODULE</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white">
            Build Your Weekly Music Class
          </h1>
          <p className="text-xs sm:text-sm text-emerald-200/80 mt-1 max-w-xl">
            Structured weekly classes with real-time AI teacher singing demonstrations and 4-panel live feedback.
          </p>
        </div>

        <button
          onClick={() => setIsClassActive(!isClassActive)}
          className={`px-5 py-3 rounded-2xl text-xs font-bold transition-all flex items-center gap-2 ${
            isClassActive 
              ? 'bg-purple-900/60 text-purple-300 border border-purple-700/50' 
              : 'bg-gradient-to-r from-emerald-500 to-teal-600 text-slate-950 font-black shadow-lg shadow-emerald-900/40 hover:scale-105'
          }`}
        >
          {isClassActive ? <RotateCcw className="w-4 h-4" /> : <Play className="w-4 h-4 fill-slate-950" />}
          <span>{isClassActive ? 'Edit Class Schedule' : 'Enter Live AI Classroom'}</span>
        </button>
      </div>

      {/* ================= BUILDER VIEW: SCHEDULE & STYLE ================= */}
      {!isClassActive && (
        <div className="space-y-6">
          <div className="glass-panel p-6 rounded-3xl border border-purple-800/40 space-y-6">
            
            {/* 1. Days per week */}
            <div>
              <label className="block text-xs font-bold text-white mb-2">
                How many days a week would you like to learn?
              </label>
              <div className="flex flex-wrap gap-2">
                {[1, 2, 3, 4, 5, 6, 7].map((num) => (
                  <button
                    key={num}
                    onClick={() => setDaysCount(num)}
                    className={`w-12 h-10 rounded-xl text-xs font-bold border transition-all ${
                      daysCount === num
                        ? 'bg-emerald-500 text-slate-950 border-emerald-400 font-black shadow-md shadow-emerald-500/40'
                        : 'bg-[#120724] border-purple-800/50 text-purple-200 hover:border-purple-600'
                    }`}
                  >
                    {num} {num === 1 ? 'day' : 'days'}
                  </button>
                ))}
              </div>
            </div>

            {/* 2. Select Preferred Days */}
            <div>
              <label className="block text-xs font-bold text-white mb-2">
                Select your preferred learning days:
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2">
                {daysOfWeek.map((day) => {
                  const isSelected = selectedDays.includes(day);
                  return (
                    <button
                      key={day}
                      onClick={() => toggleDay(day)}
                      className={`p-3 rounded-2xl text-xs font-bold border transition-all flex flex-col items-center gap-1 ${
                        isSelected
                          ? 'bg-emerald-950/70 border-emerald-400 text-emerald-200 shadow-md'
                          : 'bg-[#120724] border-purple-900/50 text-slate-400 hover:border-purple-700'
                      }`}
                    >
                      <span>{day.slice(0, 3)}</span>
                      <span className="text-[10px] text-purple-300/60 font-normal">{day}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* 3. Style selector */}
            <div>
              <label className="block text-xs font-bold text-white mb-2">
                What style would you like to learn? (MVP focus: Carnatic & Folk)
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                {(['Carnatic', 'Folk', 'Hindustani', 'Western Vocal'] as MusicStyle[]).map((st) => (
                  <button
                    key={st}
                    onClick={() => setSelectedStyle(st)}
                    className={`p-3.5 rounded-2xl text-xs font-bold border text-left transition-all ${
                      selectedStyle === st
                        ? 'bg-gradient-to-r from-emerald-600/30 to-teal-600/30 border-emerald-400 text-emerald-200 font-extrabold shadow-lg shadow-emerald-950/60'
                        : 'bg-[#120724] border-purple-900/50 text-slate-300 hover:border-purple-700'
                    }`}
                  >
                    <div className="text-sm font-bold text-white">{st}</div>
                    <div className="text-[10px] text-purple-300/70 mt-0.5">
                      {st === 'Carnatic' && 'Swaras, Ragas, Gamakas & Talam'}
                      {st === 'Folk' && 'Earthy rhythms, Themmangu & Percussion'}
                      {st === 'Hindustani' && 'Khyal, Alap & Thaat systems'}
                      {st === 'Western Vocal' && 'Solfege, Intervals & Harmony'}
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Generated Weekly Schedule Overview */}
            <div className="p-4 rounded-2xl bg-purple-950/50 border border-purple-800/40 space-y-2">
              <div className="text-xs font-bold text-amber-300 flex items-center gap-2">
                <Calendar className="w-4 h-4" />
                <span>Your Generated Weekly Schedule ({selectedStyle})</span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2 pt-1">
                {selectedDays.slice(0, 4).map((day, idx) => {
                  const types = ['Warm-up & Sarali', 'New Lesson & Gamaka', 'Speed Practice', 'Weekly Revision'];
                  return (
                    <div key={day} className="p-2.5 rounded-xl bg-[#0e051a] border border-purple-800/40 text-xs">
                      <span className="font-bold text-emerald-300">{day}:</span>
                      <div className="text-slate-300 text-[11px] mt-0.5">{types[idx % types.length]}</div>
                    </div>
                  );
                })}
              </div>
            </div>

            <button
              onClick={() => {
                updateUser({ learningDays: selectedDays });
                setIsClassActive(true);
              }}
              className="w-full py-3.5 rounded-2xl text-xs sm:text-sm font-bold bg-gradient-to-r from-emerald-500 via-teal-500 to-amber-500 text-slate-950 font-black shadow-xl shadow-emerald-900/40 hover:scale-[1.01] transition-transform flex items-center justify-center gap-2"
            >
              <span>Save Schedule & Enter Live Classroom</span>
              <ArrowRight className="w-4 h-4 stroke-[3]" />
            </button>
          </div>
        </div>
      )}

      {/* ================= 4-PANEL LIVE AI MUSIC CLASS ================= */}
      {isClassActive && (
        <div className="space-y-6">
          
          {/* Main 4-Panel Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
            
            {/* PANEL 1 (LEFT): AI Music Teacher */}
            <div className="lg:col-span-4 glass-panel p-6 rounded-3xl border border-emerald-500/30 flex flex-col justify-between space-y-4">
              <div>
                <div className="flex items-center gap-2 text-[11px] font-bold uppercase text-emerald-300 mb-3">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                  <span>AI Music Guru (Carnatic/Folk Master)</span>
                </div>

                {/* Teacher Avatar Card */}
                <div className="relative p-6 rounded-2xl bg-gradient-to-b from-purple-950 via-[#130728] to-purple-950 border border-purple-700/40 text-center space-y-3">
                  <div className="w-20 h-20 mx-auto rounded-3xl bg-gradient-to-tr from-emerald-500 via-teal-400 to-amber-400 p-[2px] shadow-xl shadow-emerald-950/80">
                    <div className="w-full h-full bg-[#0d041a] rounded-[22px] flex items-center justify-center">
                      <GraduationCap className={`w-10 h-10 text-emerald-400 ${teacherState === 'demonstrating' ? 'animate-bounce' : ''}`} />
                    </div>
                  </div>

                  <div>
                    <h3 className="text-base font-bold text-white">Vidwan AI Teacher</h3>
                    <p className="text-[11px] text-purple-300/70">
                      {teacherState === 'demonstrating' && '🎵 Singing Swaras Demonstration...'}
                      {teacherState === 'listening' && '🎙️ Listening to your voice...'}
                      {teacherState === 'evaluating' && '✨ Analyzing Shruti & Pitch...'}
                      {teacherState === 'idle' && 'Ready for Lesson Demonstration'}
                    </p>
                  </div>
                </div>

                <div className="mt-4 p-3 rounded-xl bg-purple-950/60 border border-purple-800/40 text-xs text-purple-200 leading-relaxed">
                  💡 <strong>Guru Tip:</strong> {currentLesson.instructions}
                </div>
              </div>

              <button
                onClick={handleTeacherDemonstrate}
                disabled={teacherState === 'demonstrating' || isSinging}
                className="w-full py-3 rounded-xl text-xs font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-400/40 hover:bg-emerald-500/30 disabled:opacity-40 transition-all flex items-center justify-center gap-2"
              >
                <Volume2 className="w-4 h-4" />
                <span>{teacherState === 'demonstrating' ? 'Teacher Singing...' : '1. Demonstrate Lesson'}</span>
              </button>
            </div>

            {/* PANEL 2 (CENTER): Live Lesson & Notation */}
            <div className="lg:col-span-8 glass-panel p-6 sm:p-7 rounded-3xl border border-purple-800/40 space-y-6 flex flex-col justify-between">
              <div>
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-purple-900/40">
                  <div>
                    <span className="text-[10px] uppercase font-bold text-amber-300 px-2 py-0.5 rounded bg-amber-400/15">
                      {currentLesson.raga} • {currentLesson.talam}
                    </span>
                    <h3 className="text-lg sm:text-xl font-black text-white mt-1">
                      {currentLesson.title}
                    </h3>
                  </div>

                  <div className="flex items-center gap-1.5">
                    {classCurriculum.map((_, i) => (
                      <button
                        key={i}
                        onClick={() => { setActiveStep(i); setClassScores(null); }}
                        className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all ${
                          activeStep === i
                            ? 'bg-emerald-400 text-slate-950'
                            : 'bg-purple-950/70 text-purple-300 border border-purple-800/40'
                        }`}
                      >
                        Lesson {i + 1}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Swara Notation Tiles */}
                <div className="mt-5 space-y-2">
                  <span className="text-xs font-bold text-purple-300 uppercase tracking-wider">
                    Interactive Swara Guide (Click to Hear)
                  </span>
                  <div className="grid grid-cols-4 sm:grid-cols-8 gap-2">
                    {currentLesson.notation.map((item, idx) => (
                      <button
                        key={idx}
                        onClick={() => audioEngine.playTone(item.freq, 0.45, selectedStyle === 'Folk' ? 'folk' : 'carnatic')}
                        className="py-4 px-2 rounded-2xl bg-[#0d051a] border border-purple-800/40 hover:border-emerald-400 hover:scale-105 transition-all text-center flex flex-col items-center gap-1 group"
                      >
                        <span className="text-base font-extrabold text-white group-hover:text-emerald-300">
                          {item.label}
                        </span>
                        <span className="text-[10px] text-purple-400 group-hover:text-amber-300 font-mono">
                          {item.swara}
                        </span>
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* PANEL 3 (BOTTOM): Microphone Sing-Along Bar */}
              <div className="pt-4 border-t border-purple-900/40">
                <div className="p-4 rounded-2xl bg-[#0d051a] border border-emerald-500/30 flex flex-col sm:flex-row items-center justify-between gap-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-purple-900/60 flex items-center justify-center text-emerald-400">
                      <Mic className={`w-5 h-5 ${isSinging ? 'animate-bounce text-red-400' : ''}`} />
                    </div>
                    <div>
                      <div className="text-xs font-bold text-white">
                        {isSinging ? 'Listening to your singing...' : '2. Sing Back with Tanpura'}
                      </div>
                      <div className="text-[10px] text-purple-300/70">
                        Match the swara notes and rhythm
                      </div>
                    </div>
                  </div>

                  {isSinging ? (
                    <button
                      onClick={handleStopUserSinging}
                      className="px-6 py-2.5 rounded-xl text-xs font-bold bg-red-600 text-white hover:bg-red-500 flex items-center gap-2 animate-pulse"
                    >
                      <MicOff className="w-4 h-4" />
                      <span>Stop & Evaluate</span>
                    </button>
                  ) : (
                    <button
                      onClick={handleStartUserSinging}
                      className="px-6 py-2.5 rounded-xl text-xs font-bold bg-gradient-to-r from-emerald-500 to-teal-600 text-slate-950 font-black hover:scale-105 active:scale-95 transition-all flex items-center gap-2 shadow-lg shadow-emerald-950/80"
                    >
                      <Mic className="w-4 h-4 text-slate-950" />
                      <span>Start Singing</span>
                    </button>
                  )}
                </div>
              </div>

            </div>

          </div>

          {/* PANEL 4 (RIGHT / BOTTOM): Live AI Feedback Panel */}
          {classScores && (
            <div className="glass-panel p-6 rounded-3xl border border-emerald-400/40 bg-gradient-to-br from-emerald-950/30 via-purple-950/50 to-[#0c0414] space-y-4 animate-fadeIn">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Award className="w-5 h-5 text-amber-400" />
                  <span className="text-sm font-bold text-white">3. Live AI Teacher Feedback</span>
                </div>
                <span className="text-xs font-bold text-emerald-300">+20 Credits Earned! 🎉</span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
                <div className="p-3 rounded-xl bg-purple-950/70 border border-purple-800/40 text-center">
                  <span className="text-[10px] font-bold text-purple-300 uppercase">Pitch Accuracy</span>
                  <div className="text-sm sm:text-base font-extrabold text-amber-300 mt-0.5">{classScores.pitch}</div>
                </div>
                <div className="p-3 rounded-xl bg-purple-950/70 border border-purple-800/40 text-center">
                  <span className="text-[10px] font-bold text-purple-300 uppercase">Shruti Alignment</span>
                  <div className="text-sm sm:text-base font-extrabold text-emerald-400 mt-0.5">{classScores.shruti}</div>
                </div>
                <div className="p-3 rounded-xl bg-purple-950/70 border border-purple-800/40 text-center">
                  <span className="text-[10px] font-bold text-purple-300 uppercase">Rhythm / Tala</span>
                  <div className="text-sm sm:text-base font-extrabold text-blue-400 mt-0.5">{classScores.rhythm}</div>
                </div>
                <div className="p-3 rounded-xl bg-purple-950/70 border border-purple-800/40 text-center">
                  <span className="text-[10px] font-bold text-purple-300 uppercase">Timing (Kaalam)</span>
                  <div className="text-sm sm:text-base font-extrabold text-teal-400 mt-0.5">{classScores.timing}</div>
                </div>
                <div className="p-3 rounded-xl bg-purple-950/70 border border-purple-800/40 text-center col-span-2 sm:col-span-1">
                  <span className="text-[10px] font-bold text-purple-300 uppercase">Voice Stability</span>
                  <div className="text-sm sm:text-base font-extrabold text-pink-400 mt-0.5">{classScores.stability}</div>
                </div>
              </div>

              <div className="p-4 rounded-xl bg-emerald-950/40 border border-emerald-500/30 text-xs text-emerald-100 leading-relaxed">
                {classScores.feedback}
              </div>

              <div className="flex items-center gap-2 pt-1">
                <button
                  onClick={handleStartUserSinging}
                  className="px-4 py-2 rounded-xl text-xs font-bold bg-emerald-400 text-slate-950 hover:bg-emerald-300 transition-colors"
                >
                  Repeat Lesson
                </button>
                <button
                  onClick={() => {
                    setActiveStep((activeStep + 1) % classCurriculum.length);
                    setClassScores(null);
                  }}
                  className="px-4 py-2 rounded-xl text-xs font-bold bg-purple-700 text-white hover:bg-purple-600 transition-colors ml-auto"
                >
                  Next Class Exercise ➔
                </button>
              </div>
            </div>
          )}

        </div>
      )}

    </div>
  );
};
