import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { SkillLevel, Language } from '../types';
import { X, Sparkles, Music, CheckCircle2, User, Mail, Lock, Globe2 } from 'lucide-react';

export const AuthModal: React.FC = () => {
  const { 
    isAuthModalOpen, 
    setIsAuthModalOpen, 
    authMode, 
    setAuthMode, 
    user, 
    updateUser, 
    setCurrentView 
  } = useApp();

  const [formData, setFormData] = useState({
    name: user.name,
    age: user.age,
    email: user.email,
    password: '••••••••',
    preferredLanguage: user.preferredLanguage,
    skillLevel: user.skillLevel
  });

  if (!isAuthModalOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateUser({
      name: formData.name,
      age: Number(formData.age),
      email: formData.email,
      preferredLanguage: formData.preferredLanguage as Language,
      skillLevel: formData.skillLevel as SkillLevel
    });
    setIsAuthModalOpen(false);
    // After account creation or login, take user to Purpose Selection
    setCurrentView('purpose');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-lg glass-panel rounded-3xl p-6 sm:p-8 border border-purple-500/30 shadow-2xl shadow-purple-950/90 overflow-hidden">
        
        {/* Glow effect */}
        <div className="absolute -top-24 -right-24 w-48 h-48 bg-purple-600/30 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 -left-24 w-48 h-48 bg-amber-500/20 rounded-full blur-3xl pointer-events-none" />

        {/* Close button */}
        <button
          onClick={() => setIsAuthModalOpen(false)}
          className="absolute top-5 right-5 p-2 rounded-full text-slate-400 hover:text-white hover:bg-purple-900/50 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="text-center mb-6">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-900/50 border border-purple-500/30 text-amber-300 text-xs font-semibold mb-2">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Join the AI Music Revolution</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            {authMode === 'signup' ? 'Create Your RHYTHM Account' : 'Welcome Back to RHYTHM'}
          </h2>
          <p className="text-xs sm:text-sm text-purple-200/70 mt-1">
            {authMode === 'signup' 
              ? 'Personalize your vocal & educational journey with AI.' 
              : 'Sign in to resume your music classes, rhymes & competition prep.'}
          </p>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          {authMode === 'signup' && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-purple-200 mb-1">Full Name</label>
                <div className="relative">
                  <User className="absolute left-3.5 top-3 w-4 h-4 text-purple-400" />
                  <input
                    type="text"
                    required
                    value={formData.name}
                    onChange={e => setFormData({ ...formData, name: e.target.value })}
                    placeholder="Ananya Sharma"
                    className="w-full bg-[#120724] border border-purple-800/50 rounded-xl px-10 py-2.5 text-xs text-white placeholder-purple-400/40 focus:outline-none focus:border-amber-400 focus:ring-1 focus:ring-amber-400 transition-all"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-purple-200 mb-1">Age</label>
                <input
                  type="number"
                  required
                  min={3}
                  max={99}
                  value={formData.age}
                  onChange={e => setFormData({ ...formData, age: parseInt(e.target.value) || 18 })}
                  className="w-full bg-[#120724] border border-purple-800/50 rounded-xl px-4 py-2.5 text-xs text-white placeholder-purple-400/40 focus:outline-none focus:border-amber-400 focus:ring-1 focus:ring-amber-400 transition-all"
                />
              </div>
            </div>
          )}

          <div>
            <label className="block text-xs font-semibold text-purple-200 mb-1">Email Address</label>
            <div className="relative">
              <Mail className="absolute left-3.5 top-3 w-4 h-4 text-purple-400" />
              <input
                type="email"
                required
                value={formData.email}
                onChange={e => setFormData({ ...formData, email: e.target.value })}
                placeholder="you@example.com"
                className="w-full bg-[#120724] border border-purple-800/50 rounded-xl px-10 py-2.5 text-xs text-white placeholder-purple-400/40 focus:outline-none focus:border-amber-400 focus:ring-1 focus:ring-amber-400 transition-all"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-purple-200 mb-1">Password</label>
            <div className="relative">
              <Lock className="absolute left-3.5 top-3 w-4 h-4 text-purple-400" />
              <input
                type="password"
                required
                value={formData.password}
                onChange={e => setFormData({ ...formData, password: e.target.value })}
                className="w-full bg-[#120724] border border-purple-800/50 rounded-xl px-10 py-2.5 text-xs text-white placeholder-purple-400/40 focus:outline-none focus:border-amber-400 focus:ring-1 focus:ring-amber-400 transition-all"
              />
            </div>
          </div>

          {authMode === 'signup' && (
            <>
              {/* Preferred Language */}
              <div>
                <label className="block text-xs font-semibold text-purple-200 mb-1">
                  Preferred Language
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {(['English', 'Tamil', 'Both'] as Language[]).map(lang => (
                    <button
                      type="button"
                      key={lang}
                      onClick={() => setFormData({ ...formData, preferredLanguage: lang })}
                      className={`py-2 px-3 rounded-xl text-xs font-medium border transition-all ${
                        formData.preferredLanguage === lang
                          ? 'bg-purple-700/60 border-amber-400 text-amber-200 font-bold shadow-md shadow-purple-900/40'
                          : 'bg-[#120724] border-purple-900/50 text-slate-300 hover:border-purple-600'
                      }`}
                    >
                      {lang}
                    </button>
                  ))}
                </div>
              </div>

              {/* Skill Level */}
              <div>
                <label className="block text-xs font-semibold text-purple-200 mb-1">
                  Music Skill Level
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {(['Beginner', 'Intermediate', 'Advanced'] as SkillLevel[]).map(lvl => (
                    <button
                      type="button"
                      key={lvl}
                      onClick={() => setFormData({ ...formData, skillLevel: lvl })}
                      className={`py-2 px-3 rounded-xl text-xs font-medium border transition-all ${
                        formData.skillLevel === lvl
                          ? 'bg-purple-700/60 border-amber-400 text-amber-200 font-bold shadow-md shadow-purple-900/40'
                          : 'bg-[#120724] border-purple-900/50 text-slate-300 hover:border-purple-600'
                      }`}
                    >
                      {lvl}
                    </button>
                  ))}
                </div>
              </div>
            </>
          )}

          {/* Submit Button */}
          <button
            type="submit"
            className="w-full mt-2 py-3 rounded-xl text-sm font-bold bg-gradient-to-r from-purple-600 via-indigo-600 to-amber-500 text-white shadow-lg shadow-purple-900/50 hover:opacity-95 hover:scale-[1.01] active:scale-[0.99] transition-all"
          >
            {authMode === 'signup' ? 'Create Account & Personalize' : 'Login to Dashboard'}
          </button>
        </form>

        {/* Switch mode */}
        <div className="mt-5 text-center">
          <button
            type="button"
            onClick={() => setAuthMode(authMode === 'signup' ? 'login' : 'signup')}
            className="text-xs text-purple-300 hover:text-amber-300 transition-colors font-medium"
          >
            {authMode === 'signup' 
              ? 'Already have an account? Login' 
              : "Don't have an account yet? Create Account"}
          </button>
        </div>
      </div>
    </div>
  );
};
