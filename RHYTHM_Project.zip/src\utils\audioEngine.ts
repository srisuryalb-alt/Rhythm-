// Web Audio API Engine for RHYTHM
// Provides zero-latency real synthesis for Swaras, Tanpura Drone, Melodies, Metronomes, and Pitch Detection

class AudioEngine {
  private ctx: AudioContext | null = null;
  private tanpuraOscs: OscillatorNode[] = [];
  private tanpuraGain: GainNode | null = null;
  private isTanpuraPlaying = false;
  private micStream: MediaStream | null = null;
  private micAnalyser: AnalyserNode | null = null;
  private micSource: MediaStreamAudioSourceNode | null = null;

  // Swara base frequencies (C4 = 261.63 Hz as base Sa / 1 Kattai)
  public readonly swaraFreqs: Record<string, number> = {
    'S': 261.63,     // Shadjam (Sa) - C4
    'R1': 277.18,    // Suddha Rishabham (Ri1) - C#4
    'R2': 293.66,    // Chatusruti Rishabham (Ri2) - D4
    'G2': 311.13,    // Sadharana Gandharam (Ga2) - Eb4
    'G3': 329.63,    // Antara Gandharam (Ga3) - E4
    'M1': 349.23,    // Suddha Madhyamam (Ma1) - F4
    'M2': 369.99,    // Prati Madhyamam (Ma2) - F#4
    'P': 392.00,     // Panchamam (Pa) - G4
    'D1': 415.30,    // Suddha Dhaivatam (Dha1) - G#4
    'D2': 440.00,    // Chatusruti Dhaivatam (Dha2) - A4
    'N2': 466.16,    // Kaisiki Nishadham (Ni2) - Bb4
    'N3': 493.88,    // Kakali Nishadham (Ni3) - B4
    'S^': 523.25,    // Tara Sthayi Shadjam (Higher Sa) - C5
    // Folk Pentatonic / Western mapping
    'C4': 261.63,
    'D4': 293.66,
    'E4': 329.63,
    'F4': 349.23,
    'G4': 392.00,
    'A4': 440.00,
    'B4': 493.88,
    'C5': 523.25
  };

  private getContext(): AudioContext {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AudioCtx();
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
    return this.ctx;
  }

  // Play a single note/swara with rich timbre (instrument simulation)
  public playTone(freqOrNote: number | string, duration = 0.6, type: 'carnatic' | 'folk' | 'western' | 'bell' = 'carnatic') {
    const ctx = this.getContext();
    const freq = typeof freqOrNote === 'number' ? freqOrNote : (this.swaraFreqs[freqOrNote] || 261.63);

    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    if (type === 'carnatic') {
      // Warm sawtooth filtered with gentle harmonic resonance for flute/veena warmth
      osc.type = 'sawtooth';
      const filter = ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(freq * 3, now);
      filter.Q.setValueAtTime(2, now);

      osc.frequency.setValueAtTime(freq, now);
      // Gentle gamaka / micro-vibrato
      osc.frequency.linearRampToValueAtTime(freq * 1.01, now + 0.1);
      osc.frequency.linearRampToValueAtTime(freq, now + 0.25);

      gain.gain.setValueAtTime(0.001, now);
      gain.gain.exponentialRampToValueAtTime(0.28, now + 0.05);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + duration);

      osc.connect(filter);
      filter.connect(gain);
      gain.connect(ctx.destination);
    } else if (type === 'folk') {
      // Crisp folk reed / harmonium style with slight tremolo
      osc.type = 'square';
      const filter = ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(freq * 2.2, now);

      osc.frequency.setValueAtTime(freq, now);

      gain.gain.setValueAtTime(0.001, now);
      gain.gain.exponentialRampToValueAtTime(0.2, now + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + duration);

      osc.connect(filter);
      filter.connect(gain);
      gain.connect(ctx.destination);
    } else if (type === 'bell') {
      // Bright bell/rhyme tone
      osc.type = 'sine';
      const harm = ctx.createOscillator();
      harm.type = 'sine';
      harm.frequency.setValueAtTime(freq * 2, now);

      const harmGain = ctx.createGain();
      harmGain.gain.setValueAtTime(0.1, now);
      harmGain.gain.exponentialRampToValueAtTime(0.001, now + duration * 0.8);

      osc.frequency.setValueAtTime(freq, now);
      gain.gain.setValueAtTime(0.3, now);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + duration);

      harm.connect(harmGain);
      harmGain.connect(ctx.destination);
      osc.connect(gain);
      gain.connect(ctx.destination);

      harm.start(now);
      harm.stop(now + duration);
    } else {
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, now);
      gain.gain.setValueAtTime(0.25, now);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + duration);
      osc.connect(gain);
      gain.connect(ctx.destination);
    }

    osc.start(now);
    osc.stop(now + duration);
  }

  // Play a sequence of notes
  public async playSequence(notes: (string | number)[], intervalMs = 450, type: 'carnatic' | 'folk' | 'western' | 'bell' = 'carnatic'): Promise<void> {
    for (const note of notes) {
      this.playTone(note, (intervalMs / 1000) * 0.9, type);
      await new Promise(res => setTimeout(res, intervalMs));
    }
  }

  // Tanpura / Shruti Box Drone Simulator (Fundamental Sa + Pa + Sa^ + Pa harmonics)
  public toggleTanpura(pitchHz = 261.63, onStateChange?: (playing: boolean) => void) {
    const ctx = this.getContext();
    if (this.isTanpuraPlaying) {
      this.stopTanpura();
      if (onStateChange) onStateChange(false);
      return false;
    }

    this.tanpuraGain = ctx.createGain();
    this.tanpuraGain.gain.setValueAtTime(0.12, ctx.currentTime);
    this.tanpuraGain.connect(ctx.destination);

    // Drone strings: Pa (392Hz/196Hz), Sa (261.63Hz), Sa (261.63Hz), Lower Sa (130.81Hz)
    const pitches = [pitchHz * 0.75, pitchHz, pitchHz * 1.002, pitchHz * 0.5];

    this.tanpuraOscs = pitches.map((f, i) => {
      const osc = ctx.createOscillator();
      osc.type = i === 3 ? 'triangle' : 'sawtooth';
      osc.frequency.setValueAtTime(f, ctx.currentTime);

      const filter = ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(f * 2.5, ctx.currentTime);

      osc.connect(filter);
      if (this.tanpuraGain) {
        filter.connect(this.tanpuraGain);
      }
      osc.start();
      return osc;
    });

    this.isTanpuraPlaying = true;
    if (onStateChange) onStateChange(true);
    return true;
  }

  public stopTanpura() {
    if (this.tanpuraGain && this.ctx) {
      try {
        this.tanpuraGain.gain.exponentialRampToValueAtTime(0.0001, this.ctx.currentTime + 0.3);
      } catch (e) {
        // ignore
      }
    }
    setTimeout(() => {
      this.tanpuraOscs.forEach(o => {
        try { o.stop(); o.disconnect(); } catch (e) { /* ignore */ }
      });
      this.tanpuraOscs = [];
      this.isTanpuraPlaying = false;
    }, 350);
  }

  public getIsTanpuraPlaying() {
    return this.isTanpuraPlaying;
  }

  // Metronome click
  public playClick(high = false) {
    const ctx = this.getContext();
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(high ? 1200 : 800, now);
    gain.gain.setValueAtTime(0.3, now);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.04);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.04);
  }

  // Start Mic Pitch & Waveform Analyser
  public async startMic(): Promise<AnalyserNode | null> {
    try {
      const ctx = this.getContext();
      if (!this.micStream) {
        this.micStream = await navigator.mediaDevices.getUserMedia({ audio: true });
      }
      this.micSource = ctx.createMediaStreamSource(this.micStream);
      this.micAnalyser = ctx.createAnalyser();
      this.micAnalyser.fftSize = 2048;
      this.micSource.connect(this.micAnalyser);
      return this.micAnalyser;
    } catch (err) {
      console.warn("Microphone access not granted or not available", err);
      return null;
    }
  }

  public stopMic() {
    if (this.micStream) {
      this.micStream.getTracks().forEach(track => track.stop());
      this.micStream = null;
    }
    if (this.micSource) {
      try { this.micSource.disconnect(); } catch (e) { /* ignore */ }
      this.micSource = null;
    }
    this.micAnalyser = null;
  }

  // Pitch detection via Autocorrelation algorithm
  public detectPitch(analyser: AnalyserNode, sampleRate = 44100): number {
    const buffer = new Float32Array(analyser.fftSize);
    analyser.getFloatTimeDomainData(buffer);

    let sum = 0;
    for (let i = 0; i < buffer.length; i++) {
      sum += buffer[i] * buffer[i];
    }
    const rms = Math.sqrt(sum / buffer.length);
    if (rms < 0.015) return -1; // too quiet

    let r1 = 0, r2 = buffer.length - 1;
    const thres = 0.2;
    for (let i = 0; i < buffer.length / 2; i++) {
      if (Math.abs(buffer[i]) < thres) { r1 = i; break; }
    }
    for (let i = 1; i < buffer.length / 2; i++) {
      if (Math.abs(buffer[buffer.length - i]) < thres) { r2 = buffer.length - i; break; }
    }

    const trimmed = buffer.slice(r1, r2);
    const c = new Float32Array(trimmed.length);
    for (let i = 0; i < trimmed.length; i++) {
      for (let j = 0; j < trimmed.length - i; j++) {
        c[i] = c[i] + trimmed[j] * trimmed[j + i];
      }
    }

    let d = 0;
    while (c[d] > c[d + 1]) d++;
    let maxval = -1, maxpos = -1;
    for (let i = d; i < trimmed.length; i++) {
      if (c[i] > maxval) {
        maxval = c[i];
        maxpos = i;
      }
    }

    let T0 = maxpos;
    if (T0 > 0) {
      return sampleRate / T0;
    }
    return -1;
  }
}

export const audioEngine = new AudioEngine();
