import React from 'react';
import { useApp } from '../context/AppContext';
import { ActiveTab } from '../types';
import { 
  Flame, 
  Coins, 
  BookOpen, 
  Music, 
  Trophy, 
  GraduationCap, 
  Wand2, 
  FileQuestion, 
  ArrowRight, 
  Play, 
  Calendar, 
  Sparkles, 
  CheckCircle2, 
  TrendingUp,
  Clock,
  Award
} from 'lucide-react';

export const Dashboard: React.FC = () => {
  const { user, setActiveTab } = useApp();

  // Dynamic greeting based on time of day
  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Good morning';
    if (hour < 17) return 'Good afternoon';
    return 'Good evening';
  };

  const statItems = [
    { label: 'Learning Streak', value: `${user.streak} Days`, icon: <Flame className="w-5 h-5 text-orange-400" />, bg: 'from-orange-500/15 to-amber-500/10', border: 'border-orange-500/30' },
    { label: 'Classes Completed', value: user.classesCompleted, icon: <GraduationCap className="w-5 h-5 text-emerald-400" />, bg: 'from-emerald-500/15 to-teal-500/10', border: 'border-emerald-500/30' },
    { label: 'Rhymes Learned', value: user.rhymesLearned, icon: <Music className="w-5 h-5 text-pink-400" />, bg: 'from-pink-500/15 to-purple-500/10', border: 'border-pink-500/30' },
    { label: 'Competition Prep', value: `${user.competitionPrepProgress}%`, icon: <Trophy className="w-5 h-5 text-amber-400" />, bg: 'from-amber-500/15 to-yellow-500/10', border: 'border-amber-500/30' },
    { label: 'Tests Completed', value: user.testsCompleted, icon: <FileQuestion className="w-5 h-5 text-blue-400" />, bg: 'from-blue-500/15 to-indigo-500/10', border: 'border-blue-500/30' },
    { label: 'RHYTHM Credits', value: `${user.credits} pts`, icon: <Coins className="w-5 h-5 text-amber-300" />, bg: 'from-purple-500/15 to-indigo-500/10', border: 'border-purple-500/30' },
  ];

  const dashboardCards = [
    {
      title: 'Continue Learning',
      category: 'AI Study Mnemonic',
      description: 'Resume "Photosynthesis Melody" & high school science poem memory booster.',
      actionLabel: 'Resume Learning',
      tab: 'learning' as ActiveTab,
      icon: <BookOpen className="w-6 h-6 text-blue-400" />,
      color: 'blue',
      progress: 75
    },
    {
      title: 'Rhymes Practice',
      category: 'Kids & Early Learning',
      description: 'Practice "Alphabet Phonics Swara Rhyme" with step-by-step repetition.',
      actionLabel: 'Open Rhymes',
      tab: 'rhymes' as ActiveTab,
      icon: <Music className="w-6 h-6 text-pink-400" />,
      color: 'pink',
      progress: 60
    },
    {
      title: 'Competition Progress',
      category: 'Target: Nov 2026',
      description: 'Month 2: Voice Control & Mayamalavagowla Janta Varisai pitch stability.',
      actionLabel: 'Practice Live Pitch',
      tab: 'competition' as ActiveTab,
      icon: <Trophy className="w-6 h-6 text-amber-400" />,
      color: 'amber',
      progress: user.competitionPrepProgress
    },
    {
      title: "Today's Music Class",
      category: 'Carnatic Vocal Lesson 5',
      description: 'Sarali Varisai in 3 speeds (Tristhayi) with live Pitch & Shruti AI analysis.',
      actionLabel: 'Join Live AI Class',
      tab: 'class' as ActiveTab,
      icon: <GraduationCap className="w-6 h-6 text-emerald-400" />,
      color: 'emerald',
      progress: 40
    },
    {
      title: 'Innovation Studio',
      category: 'Cross-Genre Transformation',
      description: 'Experiment transforming classical Carnatic raga phrases into Folk rhythms.',
      actionLabel: 'Open Innovation Lab',
      tab: 'innovation' as ActiveTab,
      icon: <Wand2 className="w-6 h-6 text-purple-400" />,
      color: 'purple',
      progress: 85
    },
    {
      title: 'Upcoming Test',
      category: 'Adaptive Assessment',
      description: 'Comprehensive test: Carnatic Swaras, Folk beats, and educational recall.',
      actionLabel: 'Take Assessment',
      tab: 'test' as ActiveTab,
      icon: <FileQuestion className="w-6 h-6 text-yellow-400" />,
      color: 'yellow',
      progress: 50
    }
  ];

  return (
    <div className="space-y-8 animate-fadeIn pb-12">
      
      {/* Top Welcome Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 glass-panel p-6 sm:p-8 rounded-3xl border border-purple-500/30">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-900/60 border border-purple-500/40 text-amber-300 text-xs font-bold mb-2">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Level: {user.level}</span>
          </div>
          <h1 className="text-2xl sm:text-4xl font-extrabold text-white tracking-tight">
            {getGreeting()}, <span className="text-amber-300">{user.name}</span>
          </h1>
          <p className="text-xs sm:text-sm text-purple-200/80 mt-1 max-w-xl">
            Welcome to your unified AI music ecosystem. Your personalized lessons and practice roadmap are ready.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => setActiveTab('class')}
            className="px-5 py-3 rounded-2xl text-xs font-bold bg-gradient-to-r from-purple-600 via-indigo-600 to-amber-500 text-white shadow-lg shadow-purple-900/40 hover:scale-105 active:scale-95 transition-all flex items-center gap-2"
          >
            <Play className="w-4 h-4 fill-white" />
            <span>Start Today's Session</span>
          </button>
        </div>
      </div>

      {/* 6 Key Statistics Counters */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3.5">
        {statItems.map((stat, idx) => (
          <div
            key={idx}
            className={`p-4 rounded-2xl bg-gradient-to-b ${stat.bg} border ${stat.border} backdrop-blur-md flex flex-col justify-between`}
          >
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-semibold text-slate-300 truncate">{stat.label}</span>
              {stat.icon}
            </div>
            <div className="mt-2 text-lg sm:text-xl font-extrabold text-white">
              {stat.value}
            </div>
          </div>
        ))}
      </div>

      {/* 6 Personalized Action Cards */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-bold text-white flex items-center gap-2">
            <span>Personalized Daily Recommendations</span>
          </h2>
          <span className="text-xs text-purple-300/70">
            Tailored for {user.skillLevel} level • {user.preferredLanguage}
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {dashboardCards.map((card, idx) => (
            <div
              key={idx}
              className="glass-panel rounded-3xl p-5 sm:p-6 border border-purple-800/40 hover:border-purple-400/60 transition-all flex flex-col justify-between group hover:shadow-xl hover:shadow-purple-950/60"
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <div className="p-2.5 rounded-2xl bg-[#0e051a] border border-purple-800/40 group-hover:scale-110 transition-transform">
                    {card.icon}
                  </div>
                  <span className="text-[10.5px] uppercase font-bold px-2 py-0.5 rounded-full bg-purple-900/60 text-purple-300 border border-purple-700/30">
                    {card.category}
                  </span>
                </div>

                <h3 className="text-base font-bold text-white group-hover:text-amber-300 transition-colors">
                  {card.title}
                </h3>
                <p className="text-xs text-purple-200/70 mt-1.5 leading-relaxed font-normal">
                  {card.description}
                </p>

                {/* Progress bar */}
                <div className="mt-4">
                  <div className="flex items-center justify-between text-[11px] text-purple-300/70 mb-1">
                    <span>Progress</span>
                    <span className="font-semibold">{card.progress}%</span>
                  </div>
                  <div className="w-full h-1.5 bg-purple-950 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-gradient-to-r from-purple-500 to-amber-400 rounded-full" 
                      style={{ width: `${card.progress}%` }} 
                    />
                  </div>
                </div>
              </div>

              <div className="mt-5 pt-3 border-t border-purple-900/40">
                <button
                  onClick={() => setActiveTab(card.tab)}
                  className="w-full py-2.5 px-4 rounded-xl text-xs font-bold bg-[#170929] hover:bg-purple-800/60 border border-purple-700/40 text-purple-200 hover:text-white flex items-center justify-between transition-all group-hover:border-amber-400/50"
                >
                  <span>{card.actionLabel}</span>
                  <ArrowRight className="w-3.5 h-3.5 text-amber-300 group-hover:translate-x-1 transition-transform" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Quick Launch Roadmap & Daily Streak Banner */}
      <div className="glass-panel p-6 rounded-3xl border border-amber-400/30 bg-gradient-to-r from-purple-950/60 via-indigo-950/40 to-amber-950/30 flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-amber-400/20 border border-amber-400/40 flex items-center justify-center text-amber-400 shrink-0">
            <Award className="w-7 h-7" />
          </div>
          <div>
            <div className="text-sm font-bold text-amber-300 flex items-center gap-2">
              <span>Next Milestone: Music Creator (500 pts)</span>
              <span className="text-[10px] px-2 py-0.5 rounded bg-amber-400/20 text-amber-200">
                {500 - user.credits} pts to level up
              </span>
            </div>
            <p className="text-xs text-purple-200/80 mt-0.5">
              Complete your weekly music class and 1 innovation transformation today to earn +45 credits!
            </p>
          </div>
        </div>

        <button
          onClick={() => setActiveTab('progress')}
          className="px-6 py-3 rounded-xl text-xs font-bold bg-amber-400 text-slate-950 hover:bg-amber-300 shadow-md shadow-amber-400/20 transition-all shrink-0"
        >
          View Full Analytics
        </button>
      </div>

    </div>
  );
};
