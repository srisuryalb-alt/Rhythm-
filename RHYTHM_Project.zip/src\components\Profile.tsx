import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { SkillLevel, Language, MusicStyle } from '../types';
import { 
  User, 
  Sparkles, 
  Coins, 
  Flame, 
  Award, 
  Calendar, 
  Globe2, 
  CheckCircle2, 
  Edit3, 
  Save, 
  Trophy, 
  ShieldCheck,
  Music,
  BookOpen
} from 'lucide-react';

export const Profile: React.FC = () => {
  const { user, updateUser, addCredits } = useApp();
  const [isEditing, setIsEditing] = useState(false);

  const [formData, setFormData] = useState({
    name: user.name,
    age: user.age,
    email: user.email,
    skillLevel: user.skillLevel,
    preferredLanguage: user.preferredLanguage,
    competitionDate: user.competitionDate || '2026-11-20',
    competitionType: user.competitionType || 'State Youth Classical Vocal Championship'
  });

  const achievements = [
    { title: "First Raga Explorer", desc: "Mastered Sarali Varisai Lesson 1", icon: "🎵", date: "Unlocked Sep 2026" },
    { title: "Mnemonic Master", desc: "Memorized 5 Science & History Songs", icon: "🧠", date: "Unlocked Sep 2026" },
    { title: "Rhyme Creator", desc: "Composed an Original AI Planet Rhyme", icon: "✨", date: "Unlocked Sep 2026" },
    { title: "Pitch Precision 90%+", desc: "Achieved 92% Shruti Accuracy in Practice", icon: "🎯", date: "Unlocked Sep 2026" },
    { title: "7-Day Vocal Streak", desc: "Logged in and practiced 7 days consecutively", icon: "🔥", date: "Unlocked Sep 2026" },
    { title: "Cross-Genre Innovator", desc: "Transformed Carnatic Varisai into Folk groove", icon: "🪄", date: "Unlocked Sep 2026" }
  ];

  const handleSave = () => {
    updateUser({
      name: formData.name,
      age: Number(formData.age),
      email: formData.email,
      skillLevel: formData.skillLevel as SkillLevel,
      preferredLanguage: formData.preferredLanguage as Language,
      competitionDate: formData.competitionDate,
      competitionType: formData.competitionType
    });
    setIsEditing(false);
    addCredits(10, 'Updated Profile Preferences');
  };

  return (
    <div className="space-y-8 animate-fadeIn max-w-5xl mx-auto pb-12">
      
      {/* Profile Header Hero */}
      <div className="glass-panel p-6 sm:p-8 rounded-3xl border border-purple-500/30 flex flex-col sm:flex-row items-center justify-between gap-6 shadow-2xl relative overflow-hidden">
        <div className="flex flex-col sm:flex-row items-center gap-5 text-center sm:text-left">
          <div className="w-24 h-24 rounded-3xl bg-gradient-to-tr from-purple-600 via-indigo-600 to-amber-400 p-[3px] shadow-xl shadow-purple-950/80 shrink-0">
            <div className="w-full h-full bg-[#0d041a] rounded-[21px] flex items-center justify-center text-3xl font-black text-amber-300">
              {user.name.charAt(0)}
            </div>
          </div>

          <div className="space-y-1">
            <div className="flex items-center justify-center sm:justify-start gap-2">
              <h1 className="text-2xl sm:text-3xl font-black text-white">{user.name}</h1>
              <span className="text-xs px-2.5 py-0.5 rounded-full bg-amber-400/20 text-amber-300 font-bold border border-amber-400/40">
                {user.level}
              </span>
            </div>
            <p className="text-xs text-purple-200/80">{user.email} • {user.age} Years Old</p>
            <div className="flex items-center justify-center sm:justify-start gap-3 pt-1 text-xs text-purple-300">
              <span>🗣️ {user.preferredLanguage}</span> • <span>🎯 {user.skillLevel}</span> • <span>🔥 {user.streak}d Streak</span>
            </div>
          </div>
        </div>

        <button
          onClick={() => {
            if (isEditing) handleSave();
            else setIsEditing(true);
          }}
          className="px-6 py-3 rounded-2xl text-xs font-bold bg-gradient-to-r from-purple-600 to-amber-500 text-white shadow-lg shadow-purple-900/50 hover:opacity-95 transition-all flex items-center gap-2"
        >
          {isEditing ? <Save className="w-4 h-4" /> : <Edit3 className="w-4 h-4" />}
          <span>{isEditing ? 'Save Profile' : 'Edit Profile'}</span>
        </button>
      </div>

      {/* Profile Details Form / View */}
      <div className="glass-panel p-6 sm:p-8 rounded-3xl border border-purple-800/40 space-y-6">
        <h2 className="text-base font-bold text-white flex items-center gap-2">
          <User className="w-4 h-4 text-amber-400" />
          <span>User Learning Preferences</span>
        </h2>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-bold text-purple-200 mb-1">Full Name</label>
            <input
              type="text"
              disabled={!isEditing}
              value={formData.name}
              onChange={e => setFormData({ ...formData, name: e.target.value })}
              className="w-full bg-[#120724] border border-purple-800/50 rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none focus:border-amber-400 disabled:opacity-70"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-purple-200 mb-1">Age</label>
            <input
              type="number"
              disabled={!isEditing}
              value={formData.age}
              onChange={e => setFormData({ ...formData, age: Number(e.target.value) })}
              className="w-full bg-[#120724] border border-purple-800/50 rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none focus:border-amber-400 disabled:opacity-70"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-purple-200 mb-1">Skill Level</label>
            <select
              disabled={!isEditing}
              value={formData.skillLevel}
              onChange={e => setFormData({ ...formData, skillLevel: e.target.value as SkillLevel })}
              className="w-full bg-[#120724] border border-purple-800/50 rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none focus:border-amber-400 disabled:opacity-70"
            >
              <option>Beginner</option>
              <option>Intermediate</option>
              <option>Advanced</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-bold text-purple-200 mb-1">Preferred Language</label>
            <select
              disabled={!isEditing}
              value={formData.preferredLanguage}
              onChange={e => setFormData({ ...formData, preferredLanguage: e.target.value as Language })}
              className="w-full bg-[#120724] border border-purple-800/50 rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none focus:border-amber-400 disabled:opacity-70"
            >
              <option>English</option>
              <option>Tamil</option>
              <option>Both</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-bold text-purple-200 mb-1">Target Competition Date</label>
            <input
              type="date"
              disabled={!isEditing}
              value={formData.competitionDate}
              onChange={e => setFormData({ ...formData, competitionDate: e.target.value })}
              className="w-full bg-[#120724] border border-purple-800/50 rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none focus:border-amber-400 disabled:opacity-70"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-purple-200 mb-1">Competition Title</label>
            <input
              type="text"
              disabled={!isEditing}
              value={formData.competitionType}
              onChange={e => setFormData({ ...formData, competitionType: e.target.value })}
              className="w-full bg-[#120724] border border-purple-800/50 rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none focus:border-amber-400 disabled:opacity-70"
            />
          </div>
        </div>

        {isEditing && (
          <div className="pt-2 flex justify-end">
            <button
              onClick={handleSave}
              className="px-6 py-2.5 rounded-xl text-xs font-bold bg-amber-400 text-slate-950 hover:bg-amber-300 transition-colors"
            >
              Save Preferences
            </button>
          </div>
        )}
      </div>

      {/* Badges & Achievements Grid */}
      <div className="glass-panel p-6 sm:p-8 rounded-3xl border border-purple-800/40 space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-purple-900/40">
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <Award className="w-4 h-4 text-amber-400" />
            <span>Unlocked Badges & Achievements</span>
          </h2>
          <span className="text-xs text-purple-300 font-bold">{achievements.length} Badges</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
          {achievements.map((ach, idx) => (
            <div
              key={idx}
              className="p-4 rounded-2xl bg-[#110622] border border-purple-800/40 flex items-start gap-3.5 hover:border-amber-400/50 transition-colors"
            >
              <span className="text-3xl p-2 rounded-xl bg-purple-950/60 border border-purple-800/50 shrink-0">
                {ach.icon}
              </span>
              <div>
                <h4 className="text-xs font-bold text-white">{ach.title}</h4>
                <p className="text-[11px] text-purple-200/70 mt-0.5">{ach.desc}</p>
                <div className="text-[10px] text-amber-300/80 font-mono mt-1">{ach.date}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
};
